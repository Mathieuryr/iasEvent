"""Lecture des exports d'audit TANGO et des enveloppes JSON Avro de sortie.

Les noms de champs et les valeurs ne sont jamais corrigés pendant la lecture.
Les noms de types Avro admis sont explicites ; un objet à une seule clé n'est
pas, à lui seul, une raison de supprimer ce niveau de l'objet.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

import fastavro

import controle_mapping as cm


# Correspondances de noms de types observées dans l'export fourni le 25/10/2026.
# Le Swagger décrit le corps logique, pas le schéma Avro de ce transport.
RECORD_ALIASES = {
    "IssAuthorFullAcquirerPostalAddress": {"AcquirerPostalAddress"},
    "IssAuthorFullAmountAndCurrency": {"CashAmount"},
    "IssAuthorFullAmount": {"FeeAmount"},
    "IssAuthorFullPaymentTokenAddress": {"PaymentTokenAddress"},
    "IssAuthorFullPostalAddress": {"PostalAddress"},
    "IssAuthorFullTerminalAcceptanceSysComponent": {"TerminalAcceptanceSysComponent"},
    "IssAuthorFullTransactionIdentification": {"TransactionIdentification"},
    "IssAuthorFullTransactionBillingAmount": {"BillingAmount"},
    "IssAuthorFullTransactionContext": {"TransactionContext"},
    "IssAuthorFullTransactionEMV": {"TransactionEMV"},
    "IssAuthorFullTransactionIssuerProcessingData": {"IssuerProcessingData"},
    "IssAuthorFullTransactionThreeDs": {"TransactionThreeDs"},
    "IssAuthorFullTransactionTotalAmount": {"TotalAmount"},
    "IssAuthorFullTransactionResponse": {"TransactionResponse"},
    "IssAuthorFullTransactionAdditionalResponseData": {"AdditionalResponseData"},
}
ENUM_WRAPPERS = {
    "card.accountNature": "CardAccountNature",
    "card.application": "CardApplication",
    "card.emvImplementationCode": "CardEmvImplementationCode",
    "card.usageCurrentValueList[].code": "UsageCurrentValueCode",
    "card.usageCurrentValueList[].category": "UsageCurrentValueCategory",
    "pointOfServiceContext.pinEntryCapability": "PinEntryCapability",
    "transaction.context.geographicalOrigin": "GeographicalOrigin",
    "transaction.context.issuerAcquirerRelation": "IssuerAcquirerRelation",
    "transaction.context.panEntryMode": "PanEntryMode",
    "transaction.context.pointOfServiceConditionCode": "PointOfServiceConditionCode",
    "transaction.context.transactionNature": "TransactionNature",
    "transaction.additionalResponseData.uniqueTransactionIdNetwork": "UniqueTransactionIdNetwork",
}


@dataclass
class Occurrence:
    name: str
    fields: dict = field(default_factory=dict)


def parse_audit_text(text, source_catalog):
    """Parser intégralement un seul bloc « Audit data: » ; refuser toute perte."""
    rows = text.lstrip("\ufeff").splitlines()
    if not rows or rows[0].strip() != "Audit data:":
        raise cm.ConfigurationError("L'export TANGO doit commencer par 'Audit data:'")
    root = {}
    # indentation, objet, nom, genre
    stack = [(-1, root, "", "dict")]
    child_indents = {}
    types = Counter()
    sequence = 0
    pattern = re.compile(r"^(\s*)(?:(\d+)\.\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*?)\s*$")
    for line_number, row in enumerate(rows[1:], 2):
        if not row.strip():
            continue
        match = pattern.fullmatch(row)
        if not match or "\t" in match[1]:
            raise cm.ConfigurationError(f"Audit TANGO : ligne {line_number} non reconnue")
        whitespace, number, name, content = match.groups()
        indent = len(whitespace)
        if number is not None:
            sequence += 1
            if int(number) != sequence:
                raise cm.ConfigurationError(f"Audit TANGO : numérotation non continue à la ligne {line_number}")
            indent = 0
        elif indent == 0:
            raise cm.ConfigurationError(f"Audit TANGO : indentation manquante à la ligne {line_number}")
        while stack[-1][0] >= indent:
            stack.pop()
        parent_indent, parent, parent_name, kind = stack[-1]
        # Les enfants d'un même conteneur doivent avoir la même indentation.
        if isinstance(parent, dict):
            child_indent = child_indents.setdefault(id(parent), indent)
            if child_indent != indent:
                raise cm.ConfigurationError(f"Audit TANGO : indentation ambiguë à la ligne {line_number}")
        if content == "occurrence":
            if kind != "array" or name != parent_name:
                raise cm.ConfigurationError(f"Audit TANGO : occurrence sans tableau correspondant, ligne {line_number}")
            value = Occurrence(name)
            parent.append(value)
            stack.append((indent, value.fields, name, "dict"))
            types["occurrences"] += 1
            continue
        if not isinstance(parent, dict) or name in parent:
            raise cm.ConfigurationError(f"Audit TANGO : champ dupliqué ou conteneur invalide, ligne {line_number} ({name})")
        if content in {"dict", "array"}:
            value = {} if content == "dict" else []
            parent[name] = value
            stack.append((indent, value, name, content))
            types[content] += 1
            continue
        scalar = re.fullmatch(r"(tg::String|number) <(.*)>", content)
        if not scalar:
            raise cm.ConfigurationError(f"Audit TANGO : type ou valeur non pris en charge, ligne {line_number}")
        scalar_type, value = scalar.groups()
        if scalar_type == "number":
            if not re.fullmatch(r"[+-]?[0-9]+", value):
                raise cm.ConfigurationError(f"Audit TANGO : entier attendu à la ligne {line_number}")
            value = int(value, 10)
        parent[name] = value
        types[scalar_type] += 1
    if not root:
        raise cm.ConfigurationError("L'export TANGO ne contient aucun champ")

    def materialize(value, path=""):
        if isinstance(value, dict):
            return {name: materialize(item, f"{path}.{name}".lstrip(".")) for name, item in value.items()}
        if isinstance(value, list):
            item_path = path + "[]"
            item_types = source_catalog.get(item_path, cm.Field()).types - {"null"}
            result = []
            for item in value:
                if not isinstance(item, Occurrence):
                    raise cm.ConfigurationError(f"Audit TANGO : occurrence non reconnue à {path}")
                if item_types and not item_types & {"object", "array"}:
                    if set(item.fields) != {item.name} or isinstance(item.fields[item.name], (dict, list)):
                        raise cm.ConfigurationError(f"Audit TANGO : occurrence scalaire ambiguë à {item_path}")
                    result.append(item.fields[item.name])
                else:
                    result.append(materialize(item.fields, item_path))
            return result
        return value

    return materialize(root), {"format": "audit-texte", "lignes_lues": len(rows), "champs_racine": len(root), "elements": dict(types)}


def read_input(path: Path, schema, source_catalog, mode="auto"):
    if path.suffix.lower() == ".avro" and mode in {"auto", "json"}:
        return cm.read_input(path, schema), {"format": "avro-conteneur"}
    text = path.read_text(encoding="utf-8-sig")
    if mode == "auto":
        mode = "audit-texte" if text.lstrip().startswith("Audit data:") else "json"
    if mode == "audit-texte":
        # Ne pas retirer l'indentation d'une ligne après l'en-tête.
        return parse_audit_text(text.lstrip(), source_catalog)
    if mode == "avro-json":
        with path.open(encoding="utf-8-sig") as stream:
            records = iter(fastavro.json_reader(stream, schema))
            incoming = next(records, cm.MISSING)
            if incoming is cm.MISSING or next(records, cm.MISSING) is not cm.MISSING:
                raise cm.ConfigurationError("Un seul événement est attendu")
        return incoming, {"format": "avro-json"}
    return cm.strict_json(text), {"format": "json"}


def normalize_output(value, document, selected, mode="auto"):
    """Retirer uniquement les enveloppes typées connues au chemin attendu.

    Ceci ne valide pas l'Avro de sortie : ce schéma n'a pas été fourni.
    La validation Swagger porte ensuite sur le corps logique obtenu.
    """
    if mode == "json":
        return value, {"format": "json", "enveloppes_retirees": 0}
    changes = []

    def visit(item, node, path=""):
        if not isinstance(node, dict):
            return item
        allowed = set()
        refs = set()
        while "$ref" in node:
            ref = node["$ref"]
            if ref in refs:
                raise cm.ConfigurationError(f"Référence circulaire de format à {path}")
            refs.add(ref)
            name = ref.rsplit("/", 1)[-1]
            allowed.add(name)
            allowed.update(RECORD_ALIASES.get(name, set()))
            node = cm.pointer(document, ref)
        kind = node.get("type")
        types = set(kind if isinstance(kind, list) else [kind])
        properties = node.get("properties", {})
        if "string" in types:
            allowed.add("string")
            if "enum" in node and path in ENUM_WRAPPERS:
                allowed.add(ENUM_WRAPPERS[path])
        if "array" in types:
            allowed.add("array")
        if "boolean" in types:
            allowed.add("boolean")
        if "integer" in types:
            allowed.update({"int", "long"})
        if "number" in types:
            allowed.update({"int", "long", "float", "double"})
        if isinstance(item, dict) and len(item) == 1:
            key = next(iter(item))
            if key in allowed and key not in properties:
                changes.append({"chemin": path, "type_export": key})
                item = item[key]
        if isinstance(item, dict):
            return {name: visit(child, properties[name], f"{path}.{name}".lstrip(".")) if name in properties else child
                    for name, child in item.items()}
        if isinstance(item, list) and "array" in types:
            return [visit(child, node.get("items", {}), path + "[]") for child in item]
        return item

    result = visit(value, selected)
    return result, {"format": "avro-json" if changes else "json", "enveloppes_retirees": len(changes),
                    "detail": changes, "validation_transport_avro": "non_effectuee_schema_avro_sortie_non_fourni" if changes else "non_applicable"}


def unknown_input_paths(value, catalog, path=""):
    """Repérer les données d'audit sans chemin correspondant dans le contrat."""
    result = []
    if isinstance(value, dict):
        for name, child in value.items():
            current = f"{path}.{name}".lstrip(".")
            if current not in catalog:
                result.append(current)
            else:
                result.extend(unknown_input_paths(child, catalog, current))
    elif isinstance(value, list):
        for child in value:
            result.extend(unknown_input_paths(child, catalog, path + "[]"))
    return sorted(set(result))
