@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" goto installation_absente
if not exist "demo_v2.py" goto incomplet
".venv\Scripts\python.exe" -c "import fastavro, openpyxl, yaml, openapi_schema_validator, jsonschema, referencing" >nul 2>&1
if errorlevel 1 goto installation_absente

echo Demo locale TANGO V2
echo L'interface va s'ouvrir dans le navigateur.
echo Garder cette fenetre ouverte pendant l'utilisation.
echo Pour arreter la demo : Ctrl+C dans cette fenetre.
echo.
".venv\Scripts\python.exe" "demo_v2.py" --port 8792
set "RISE_V2_EXIT=%ERRORLEVEL%"
if "%RISE_V2_EXIT%"=="0" exit /b 0
echo.
echo La demo s'est arretee. Le detail est affiche ci-dessus.
pause
exit /b %RISE_V2_EXIT%

:installation_absente
echo Executer d'abord Installer_V2_Windows.cmd dans ce meme dossier.
pause
exit /b 2

:incomplet
echo Le dossier est incomplet. Extraire toute l'archive avant de lancer ce fichier.
pause
exit /b 2
