# TANGO V2 — démarrage sur Mac et Windows avec WSL

Cette livraison comprend l'application et ses dépendances pour **Mac Intel**, **Mac Apple Silicon** et **WSL Linux x86_64 (PC Intel/AMD)**, avec **Python 3.12**. Elle permet une installation sans téléchargement de paquets, même si le VPN ou le proxy de l'entreprise bloque l'accès au dépôt Python.

Le contrôle part des données présentes en entrée Kafka pour chercher leurs correspondances dans la sortie, selon les seules lignes marquées `x` du mapping. Les autres données sont hors comparaison. Les contrôles des schémas et des références sont présentés séparément.

## Sur Mac

1. Installer Python 3.12 s'il n'est pas déjà disponible.
2. Extraire tout le ZIP et conserver le dossier `controle_tango_v2` ensemble.
3. Double-cliquer sur `Installer_V2_Mac.command` une seule fois, puis sur `Lancer_V2_Mac.command`.

Si le double-clic ne fonctionne pas, ouvrir Terminal dans le dossier extrait :

```sh
bash Installer_V2_Mac.command --hors-ligne
bash Lancer_V2_Mac.command
```

Pour les utilisations suivantes, lancer seulement `Lancer_V2_Mac.command`.

## Sur le PC d'entreprise, dans WSL

Prérequis : WSL et une distribution Linux avec **Python 3.12 et le module venv**, disponibles selon les règles du poste. Ubuntu 24.04 est une cible adaptée. La livraison n'installe pas WSL ou Python.

1. Extraire le ZIP côté Windows. Copier le dossier `controle_tango_v2` dans le dossier personnel Linux de WSL, par exemple `~/applications/controle_tango_v2`. Les chemins Windows sont accessibles sous `/mnt/c/...`.
2. Dans le terminal WSL, se placer dans ce dossier puis exécuter :

```sh
cd ~/applications/controle_tango_v2
bash Installer_V2_WSL.sh --hors-ligne
bash Lancer_V2_WSL.sh
```

3. Dans le navigateur **Windows**, ouvrir **http://127.0.0.1:8792/**.

Pour les utilisations suivantes, exécuter seulement `bash Lancer_V2_WSL.sh` depuis ce dossier, puis ouvrir l'adresse locale. Laisser le terminal ouvert ; **Ctrl+C** arrête l'application.

## VPN et proxy

L'installation ci-dessus utilise les paquets inclus et ne consulte aucun dépôt Internet. Le VPN peut rester connecté. Les contrôles de fichiers fonctionnent en local après l'installation.

Si l'entreprise demande une installation depuis son propre dépôt Python, utiliser `--en-ligne`. L'installateur conserve le proxy et les réglages pip déjà présents dans WSL. Un fichier `reseau.local.ini` permet de préciser l'adresse du proxy, le dépôt interne et le certificat PEM fournis par l'IT. Voir **GUIDE_MAC_WSL.md** pour les réglages automatiques Windows, le cas PAC et les erreurs 407/certificat/DNS.

Diagnostic sans accès réseau :

```sh
bash Diagnostic_Mac_WSL.sh
```

## Données et validation

Les fichiers et rapports restent sur le poste. Le serveur écoute uniquement `127.0.0.1`. L'historique est dans `v2_runs/` ; conserver ce dossier lors d'une mise à jour. Mac et WSL créent chacun leur environnement Python : ne pas transférer les dossiers `.venv*`.

La préparation inclut une installation hors ligne propre et les tests sur le Mac disponible. Le lancement réel sous WSL et le VPN/proxy de votre entreprise restent à vérifier sur ce PC. La prise en charge des réglages réseau ne garantit pas la compatibilité de tous les VPN.
