"""Garanties de l'installation : proxy hérité, mode hors ligne et données conservées."""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

import tango_local as local


ROOT = Path(__file__).resolve().parents[1]


class NetworkConfigurationChecks(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="tango_network_")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.config = self.root / "reseau.local.ini"

    def test_inherited_proxy_and_both_company_exceptions_survive(self):
        original = {"HTTPS_PROXY": "http://proxy.example:8080", "NO_PROXY": ".entreprise", "no_proxy": "intranet", "PIP_INDEX_URL": "https://depot.example/simple"}
        result = local.network_environment(self.config, original)
        self.assertEqual(result["HTTPS_PROXY"], original["HTTPS_PROXY"])
        self.assertEqual(result["PIP_INDEX_URL"], original["PIP_INDEX_URL"])
        self.assertEqual(result["no_proxy"], result["NO_PROXY"])
        self.assertEqual(set(result["NO_PROXY"].split(",")), {".entreprise", "intranet", *local.LOOPBACK})
        self.assertNotIn("localhost", original["NO_PROXY"])

    def test_local_config_supports_percent_encoded_password_and_relative_ca(self):
        (self.root / "ca.pem").touch()
        self.config.write_text("[reseau]\nproxy=http://user:p%40ss@proxy.example:8080\nindex_url=https://depot.example/simple\ncertificat=ca.pem\ntimeout=45\n", encoding="utf-8")
        result = local.network_environment(self.config, {"PIP_EXTRA_INDEX_URL": "https://other.example"})
        self.assertEqual(result["http_proxy"], "http://user:p%40ss@proxy.example:8080")
        self.assertEqual(result["PIP_PROXY"], result["HTTPS_PROXY"])
        self.assertEqual(result["PIP_CERT"], str((self.root / "ca.pem").resolve()))
        self.assertEqual(result["PIP_DEFAULT_TIMEOUT"], "45")
        self.assertNotIn("PIP_EXTRA_INDEX_URL", result)

    def test_missing_ca_has_actionable_error(self):
        self.config.write_text("[reseau]\ncertificat=absent.pem\n", encoding="utf-8")
        with self.assertRaisesRegex(local.LocalError, "certificat PEM"):
            local.network_environment(self.config, {})

    def test_unknown_option_cannot_silently_change_behavior(self):
        self.config.write_text("[reseau]\ntrusted_host=pypi.org\n", encoding="utf-8")
        with self.assertRaises(local.LocalError):
            local.network_environment(self.config, {})

    def test_offline_cancels_remote_find_links_and_all_pip_config(self):
        original = {"PIP_FIND_LINKS": "https://remote.example/wheels", "PIP_INDEX_URL": "https://index.example", "PIP_CONFIG_FILE": "secret.conf", "HTTPS_PROXY": "http://proxy.example", "WSL_PAC_URL": "https://pac.example", "PATH": "/bin"}
        result = local.offline_environment(original)
        self.assertEqual(result["PIP_CONFIG_FILE"], os.devnull)
        self.assertFalse(set(original).intersection(result) - {"PATH", "PIP_CONFIG_FILE"})
        self.assertEqual(result["PATH"], "/bin")
        self.assertIn("127.0.0.1", result["NO_PROXY"])

    def test_proxy_credentials_are_redacted_in_pip_output(self):
        text = "Failed https://alice:p%40ss@packages.example/simple via http://bob:secret@proxy.example:80"
        result = local.sanitized(text, {"HTTPS_PROXY": "http://bob:secret@proxy.example:80"})
        for secret in ("alice", "p%40ss", "bob", "secret"):
            self.assertNotIn(secret, result)

    def test_pac_is_explained_without_printing_its_address(self):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            local.warn_pac({"WSL_PAC_URL": "https://private.example/autoconfig.pac"})
        self.assertIn("PAC", output.getvalue())
        self.assertNotIn("private.example", output.getvalue())


class OfflinePackageChecks(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="tango_offline_")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        (self.root / "requirements.txt").write_text("sample==1.0\n", encoding="utf-8")
        self.folder = self.root / "paquets"
        self.folder.mkdir()
        self.wheel = self.folder / "sample-1.0-py3-none-any.whl"
        with ZipFile(self.wheel, "w") as archive:
            archive.writestr("sample-1.0.dist-info/METADATA", "Metadata-Version: 2.1\nName: sample\nVersion: 1.0\n")
        local.write_wheel_manifest(self.folder, "wsl-x86_64", self.root)

    def test_matching_package_set_passes_and_lock_pins_hashes(self):
        lock = local.verify_wheels(self.folder, "wsl-x86_64", self.root)
        self.assertIn("sample==1.0 --hash=sha256:", lock.read_text())
        self.assertIn(hashlib.sha256(self.wheel.read_bytes()).hexdigest(), lock.read_text())

    def test_other_os_is_rejected(self):
        with self.assertRaises(local.LocalError):
            local.verify_wheels(self.folder, "mac-arm64", self.root)

    def test_changed_wheel_is_rejected(self):
        self.wheel.write_bytes(b"modified")
        with self.assertRaises(local.LocalError):
            local.verify_wheels(self.folder, "wsl-x86_64", self.root)

    def test_missing_wheel_is_rejected(self):
        self.wheel.unlink()
        with self.assertRaises(local.LocalError):
            local.verify_wheels(self.folder, "wsl-x86_64", self.root)

    def test_changed_requirements_cannot_reuse_stale_wheel_set(self):
        (self.root / "requirements.txt").write_text("sample==2.0\n")
        with self.assertRaises(local.LocalError):
            local.verify_wheels(self.folder, "wsl-x86_64", self.root)

    def test_path_outside_wheel_directory_is_rejected(self):
        path = self.folder / "manifest.json"
        manifest = json.loads(path.read_text())
        manifest["fichiers"]["../elsewhere.whl"] = "0" * 64
        path.write_text(json.dumps(manifest))
        with self.assertRaises(local.LocalError):
            local.verify_wheels(self.folder, "wsl-x86_64", self.root)

    def test_offline_install_ignores_broken_network_config_and_keeps_history(self):
        history = self.root / "v2_runs" / "old-run"
        history.mkdir(parents=True)
        (history / "rapport.json").write_text("{}")
        config = self.root / "reseau.local.ini"
        config.write_text("broken config")
        args = argparse.Namespace(dossier_paquets=self.folder, hors_ligne=True, en_ligne=False, config=config)
        python = self.root / ".venv-wsl/bin/python"
        python.parent.mkdir(parents=True)
        python.touch()
        with patch.object(local, "target_name", return_value="wsl-x86_64"), patch.object(local, "environment_python", return_value=python), patch.object(local, "check_environment"), patch.object(local, "run_pip") as pip, contextlib.redirect_stdout(io.StringIO()):
            local.install(args, self.root)
        self.assertTrue((history / "rapport.json").is_file())
        command = pip.call_args_list[0].args[1]
        self.assertIn("--no-index", command)
        self.assertIn("--require-hashes", command)
        self.assertNotIn(str(self.root / "requirements.txt"), command)

    def test_invalid_bundled_manifest_never_falls_back_to_network(self):
        (self.folder / "manifest.json").write_text("invalid")
        args = argparse.Namespace(dossier_paquets=self.folder, hors_ligne=False, en_ligne=False, config=self.root / "reseau.local.ini")
        with patch.object(local, "target_name", return_value="wsl-x86_64"), patch.object(local, "run_pip") as pip, self.assertRaises(local.LocalError):
            local.install(args, self.root)
        pip.assert_not_called()


class LocalLauncherChecks(unittest.TestCase):
    def test_platform_venvs_are_separate(self):
        with patch.object(local.sys, "platform", "darwin"):
            mac = local.environment_python()
        with patch.object(local.sys, "platform", "linux"):
            wsl = local.environment_python()
        self.assertNotEqual(mac, wsl)

    def test_wsl_launch_requires_no_windows_executable_or_network_config(self):
        args = argparse.Namespace(port=8793, no_browser=False, data_dir=None)
        with patch.object(local, "check_environment"), patch.object(local.sys, "platform", "linux"), patch.object(local.os, "chdir"), patch.object(local.os, "execve") as launch, contextlib.redirect_stdout(io.StringIO()):
            local.launch(args)
        executable, command, environment = launch.call_args.args
        self.assertIn("--no-browser", command)
        self.assertIn("8793", command)
        self.assertIn("127.0.0.1", environment["no_proxy"])
        self.assertTrue(str(executable).endswith(".venv-wsl/bin/python"))

    def test_shell_entry_point_handles_paths_with_spaces(self):
        with tempfile.TemporaryDirectory(prefix="tango shell test ") as temporary:
            root = Path(temporary)
            (root / "tools").mkdir()
            (root / "tools/tango_posix.sh").write_bytes((ROOT / "tools/tango_posix.sh").read_bytes())
            (root / "tango_local.py").write_text("import sys; print(repr(sys.argv[1:]))", encoding="utf-8")
            result = subprocess.run(["bash", str(root / "tools/tango_posix.sh"), "diagnostic", "--config", "a path/with spaces.ini"], cwd="/", env={**os.environ, "TANGO_PYTHON": sys.executable}, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("'a path/with spaces.ini'", result.stdout)

    def test_scripts_are_parseable_by_bash(self):
        names = ("Installer_V2_Mac.command", "Lancer_V2_Mac.command", "Installer_V2_WSL.sh", "Lancer_V2_WSL.sh", "Diagnostic_Mac_WSL.sh", "Preparer_hors_ligne.sh", "tools/tango_posix.sh")
        for name in names:
            with self.subTest(name=name):
                result = subprocess.run(["bash", "-n", str(ROOT / name)], capture_output=True)
                self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == "__main__":
    unittest.main()
