import copy
import json
import tempfile
import unittest
from contextlib import redirect_stdout,redirect_stderr
from io import StringIO
from pathlib import Path
from unittest.mock import patch

import fastavro
from fastavro.validation import validate

import controle_mapping as cm
import controle_tango as ct
import tango_mapping as tm
import tango_engine as e

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"donnees_tango"


class TangoChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile=cm.load_document(ROOT/"profil_tango.json")
        cls.names={}
        cls.schema=fastavro.parse_schema(cm.load_document(DATA/"avro.json"),named_schemas=cls.names)
        cls.source,_=cm.avro_catalog(cls.schema,cls.names)
        cls.swagger=cm.load_document(DATA/"swagger.yaml")
        cls.validator,selected=cm.make_output_validator(cls.swagger,cls.profile["schema_sortie"])
        cls.target,_=cm.swagger_catalog(cls.swagger,selected)
        lines,cls.meta=tm.import_mapping(DATA/"mapping.xlsm",cls.source,cls.target)
        cls.lines=ct.configure(lines,cls.profile,cls.source,cls.target)
        cls.byrow={line.row:line for line in cls.lines}

    def setUp(self):
        self.profile=copy.deepcopy(type(self).profile)

    def incoming(self,**values):
        # Nullable Avro fields use their actual schema defaults, never guessed values.
        record={item["name"]:copy.deepcopy(item.get("default")) for item in self.schema["fields"]}
        record.update(MTI=4000,ISOMTI=100,transUId="00000000-0000-4000-8000-000000000001",resultCode=0)
        record.update(values)
        return record

    def compute(self,row,message):
        return e.expected(self.byrow[row],message,self.profile,{})

    def test_real_files_import_without_macro_execution(self):
        self.assertEqual(len(self.lines),322)
        self.assertTrue(all(line.marked for line in self.lines))
        self.assertEqual(self.meta["selection"]["colonne"],"B")
        self.assertEqual(self.meta["selection"]["lignes_marquees"],324)
        self.assertNotIn(431,self.byrow)
        self.assertNotIn(492,self.byrow)
        self.assertIn(453,self.byrow)
        self.assertEqual({item["ligne"] for item in self.meta["selection"]["titres_conteneurs_marques"]},{237,251})
        self.assertEqual(self.byrow[6].source,"transUId")
        self.assertEqual(self.byrow[13].targets,["card.agreementEntityId"])
        self.assertEqual(self.byrow[88].targets,["acquirer.referenceIdentification"])
        self.assertEqual(self.byrow[112].targets,["terminal.acceptanceSysComponent.idManufacturerCode"])
        self.assertEqual(self.byrow[484].targets,["transaction.issuerControlList"])

    def test_event_category_is_excluded_when_its_mark_is_removed(self):
        sheets=copy.deepcopy(self.meta["sheets"])
        dict(sheets["Notification Forwarding"])[492].pop("B",None)
        with patch.object(tm,"read_sheets",return_value=sheets):
            lines,meta=tm.import_mapping(DATA/"mapping.xlsm",self.source,self.target)
        self.assertEqual(len(lines),322)
        self.assertNotIn(492,{line.row for line in lines})
        self.assertTrue(any(line["row"]==492 and not line["marked"] for line in meta["lignes_hors_perimetre"]))

    def test_unmarked_fields_no_longer_generate_mapping_errors(self):
        sheets=copy.deepcopy(self.meta["sheets"])
        rows=dict(sheets["Notification Forwarding"])
        for row in (5,19):
            rows[row].pop("B")
        with tempfile.TemporaryDirectory() as tmp:
            report=Path(tmp)/"report.json"
            with patch.object(tm,"read_sheets",return_value=sheets),redirect_stdout(StringIO()):
                code=ct.main(["--entree",str(ROOT/"examples_reels/audit_KAFKA.txt"),"--sortie",str(ROOT/"examples_reels/Kafka_audit_sortie.txt"),"--rapport",str(report)])
            data=json.loads(report.read_text())
        self.assertEqual(code,1)
        self.assertEqual(data["compteurs_par_niveau"]["valeurs"]["ERREUR"],14)
        self.assertFalse(any(line["row"] in {5,19} for line in data["mapping_resolu"]))
        self.assertFalse(any(line["ligne_excel"] in {5,19} for line in data["controles"]))

    def test_expanding_the_scope_to_unmarked_rows_is_not_available(self):
        with redirect_stderr(StringIO()),self.assertRaises(SystemExit) as exc:
            ct.args(["--inclure-non-marques"])
        self.assertEqual(exc.exception.code,2)

    def test_reference_copies_identical(self):
        manifest=cm.load_document(DATA/"provenance.json")
        for name,value in manifest.items():
            self.assertEqual(tm.sha256(DATA/name),value["sha256"])

    def test_isomti_wins_over_mti(self):
        self.assertEqual(self.compute(5,self.incoming()),"IAS_ONLINE_AUTH_AUTHORISATION")
        self.assertEqual(self.compute(5,self.incoming(ISOMTI=430)),"IAS_ONLINE_AUTH_REVERSAL ADVICE")

    def test_unknown_event_code_is_not_coerced(self):
        with self.assertRaises(ValueError):
            self.compute(5,self.incoming(ISOMTI=999))

    def test_schema_ref_descriptions_are_annotations(self):
        _,limits=cm.swagger_catalog(self.swagger,cm.pointer(self.swagger,self.profile["schema_sortie"]))
        self.assertFalse(limits)

    def test_positions_and_boolean_conversion(self):
        message=self.incoming(context={"POSEntryMode":"051","partialApprovalInd":"3"})
        self.assertEqual(self.compute(31,message),"CHON")
        self.assertEqual(self.compute(32,message),"TACP")
        self.assertIs(self.compute(38,message),True)
        with self.assertRaises(ValueError):
            self.compute(32,self.incoming(context={"POSEntryMode":"05"}))

    def test_incorrect_field_variants(self):
        message=lambda value:self.incoming(context={"aditionalResponseInfo":{"ISO44incorrectField":value}})
        self.assertEqual(self.compute(70,message("05904121")),"059")
        self.assertEqual(self.compute(71,message("05904121")),"0412")
        self.assertEqual(self.compute(72,message("05904121")),"VAER")
        self.assertIs(self.compute(71,message("0591")),cm.MISSING)

    def test_composite_conditions(self):
        message=self.incoming(context={"processingCode":"20XXXX"},processingInfo={"amountType":"D"})
        self.assertEqual(self.compute(65,message),"DEAC")
        self.assertIs(self.compute(66,message),cm.MISSING)

    def test_null_optional_omitted_but_required_missing_fails(self):
        message=self.incoming(bankId=None)
        self.assertIs(self.compute(10,message),cm.MISSING)
        with self.assertRaises(ValueError):
            self.compute(6,self.incoming(transUId=None))

    def test_category_from_ias_object_presence(self):
        # Cette règle historique reste calculable si elle est sélectionnée à nouveau.
        rule=copy.deepcopy(self.byrow[5])
        rule.operation="categorie_service"
        rule.source="processingInfo.IASTechInfo"
        rule.parameters={}
        self.assertEqual(e.expected(rule,self.incoming(),self.profile,{}),"ISW_ONLINE_AUTH")
        self.assertEqual(e.expected(rule,self.incoming(processingInfo={"IASTechInfo":{}}),self.profile,{}),"IAS_ONLINE_AUTH")

    def test_enrichment_reference_is_independent(self):
        line=self.byrow[519]
        with self.assertRaises(e.Pending):
            e.expected(line,self.incoming(),self.profile,{})
        self.assertEqual(e.expected(line,self.incoming(),self.profile,{"cardholder.id":"id-reference"}),"id-reference")

    def test_header_conflict_not_silently_selected(self):
        with self.assertRaises(e.Pending):
            self.compute(3,self.incoming())
        self.profile["decisions"]["event_type"]="iss-authorisation-processed"
        self.assertEqual(self.compute(3,self.incoming()),"iss-authorisation-processed")

    def test_money_no_assumed_euro_scaling(self):
        with self.assertRaises(e.Pending):
            self.compute(132,self.incoming(transactionAmt=12345,currency="978"))
        self.profile["monnaie"]={"unite_source":"mineure","exposants":{"978":2}}
        expected=self.compute(132,self.incoming(transactionAmt=12345,currency="978"))
        self.assertEqual(expected,"123.45")
        self.assertFalse(e.diff(expected,"123.450",self.byrow[132]))
        self.assertTrue(e.diff(expected,"123.46",self.byrow[132]))

    def test_composite_amount_filter_no_first_of_duplicate(self):
        self.profile["monnaie"]={"unite_source":"majeure"}
        item={"amountType":"02","value":42,"currencyCode":"978"}
        self.assertEqual(self.compute(142,self.incoming(additionalAmtList=[item])),{"amount":"42","currency":"978"})
        with self.assertRaises(e.Pending):
            self.compute(142,self.incoming(additionalAmtList=[item,item]))

    def test_emv_amount_uses_authorised_currency(self):
        self.profile["monnaie"]={"unite_source":"mineure","exposants":{"978":2,"392":0}}
        message=self.incoming(currency="978",transCurrencyCode="392",EMVData={"amtAuthorized":"123"})
        self.assertEqual(self.compute(319,message),"123")

    def test_two_control_lists_join_even_if_first_missing(self):
        message=self.incoming(processingInfo={"IASTechInfo":{"ACResultList":[{"controlName":"EMACC65_GQ","resultCode":3097}]}})
        expected=self.compute(484,message)
        self.assertEqual(expected,[{"code":"EMACC65","controlCode":"EMACC65_GQ","responseCode":"3097"}])

    def test_control_lists_preserve_duplicates(self):
        row={"controlName":"CTRL_ABC","resultCode":0}
        message=self.incoming(processingInfo={"ACResultList":[row],"IASTechInfo":{"ACResultList":[row]}})
        self.assertEqual(len(self.compute(484,message)),2)

    def test_scores_selected_by_service_id_not_position(self):
        line=self.byrow[358]
        body={"riskScoringList":[{"serviceId":"01","serviceData":"A"},{"serviceId":"04","serviceData":"B"}]}
        self.assertEqual(e.observed(line,body,None),{"serviceId":"04","serviceData":"B"})
        body["riskScoringList"].append({"serviceId":"04","serviceData":"B"})
        with self.assertRaises(ValueError):
            e.observed(line,body,None)

    def test_unknown_parsing_stays_pending(self):
        with self.assertRaises(e.Pending):
            self.compute(192,self.incoming(originalInfo={"initialTransECAddtlData":"01"}))

    def test_packed_rate_exact_decimal(self):
        self.assertEqual(e.packed_rate("69985022"),"9.985022")
        with self.assertRaises(ValueError):
            e.packed_rate("x9985022")

    def test_exchange_rate_positions(self):
        packet="1"+"ECB".ljust(70)+"TABLE"+"69985022"+" "
        result=e.exchange_rates(packet)
        self.assertEqual(result[0]["exchangeRate"],"9.985022")
        self.assertEqual(result[0]["exchangeRateOrigin"],"ECBR")
        self.assertFalse(list(self.validator.iter_errors({"transaction":{"exchangeRateInformationList":result}})))
        with self.assertRaises(e.Pending):
            e.exchange_rates(packet+packet)

    def test_exchange_boolean_needs_explicit_conversion(self):
        packet="1"+"ECB".ljust(70)+"TABLE"+"69985022"+"1"
        with self.assertRaises(e.Pending):
            e.exchange_rates(packet)
        self.assertIs(e.exchange_rates(packet,{"1":True})[0]["persistentFxEligibleIndicator"],True)

    def test_rule_change_invalidates_previous_implementation(self):
        changed=copy.deepcopy(self.byrow[31])
        changed.signature="changed"
        ct.configure([changed],self.profile,self.source,self.target)
        self.assertEqual(changed.operation,"a_definir")
        self.assertTrue(any(note["code"]=="REGLE_MODIFIEE" for note in changed.notes))

    def test_actual_structural_errors_are_reported(self):
        audit=ct.TangoAudit()
        audit.structures(self.lines,self.source,self.target,[],self.profile)
        errors=[row for row in audit.rows if row["statut"]=="ERREUR"]
        self.assertEqual({row["ligne_excel"] for row in errors},{123,125,194,371})

    def test_multiple_sources_do_not_generate_fake_value_failures(self):
        audit=ct.TangoAudit()
        audit.structures(self.lines,self.source,self.target,[],self.profile)
        audit.values([self.byrow[23],self.byrow[271],self.byrow[275]],self.incoming(CVX2Info={"verifiedCVX2Form":1}),{"card":{"securityCodeIndicator":"CVDC"}},None,self.profile,{})
        self.assertTrue(any(row["ligne_excel"]==271 and row["statut"]=="OK" for row in audit.rows))
        self.assertFalse(any(row["niveau"]=="valeurs" and row["statut"]=="ERREUR" for row in audit.rows))

    def test_configuration_error_replaces_previous_html(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=Path(tmp)/"rapport.json"
            report.with_suffix(".html").write_text("OLD SUCCESS")
            with redirect_stderr(StringIO()),redirect_stdout(StringIO()):
                code=ct.main(["--swagger",str(Path(tmp)/"missing.yaml"),"--rapport",str(report)])
            self.assertEqual(code,2)
            self.assertNotIn("OLD SUCCESS",report.with_suffix(".html").read_text())
            self.assertEqual(json.loads(report.read_text())["statut"],"ERREUR_CONFIGURATION")

    def test_synthetic_source_valid_with_actual_avro(self):
        self.assertTrue(validate(self.incoming(),self.schema,strict=True))

    def test_missing_legacy_conversions_no_false_difference(self):
        line=self.byrow[162]
        expected=e.expected(line,self.incoming(),self.profile,{})
        actual=e.observed(line,{},None)
        self.assertFalse(e.diff(expected,actual,line))

    def test_full_fictive_messages_no_value_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=Path(tmp)/"report.json"
            with redirect_stdout(StringIO()):
                code=ct.main(["--entree",str(ROOT/"examples_tango/entree_fictive.json"),"--sortie",str(ROOT/"examples_tango/sortie_fictive.json"),"--rapport",str(report)])
            # Input-contract inconsistencies remain visible; the exercised values are correct.
            self.assertEqual(code,1)
            data=json.loads(report.read_text())
            errors=[row for row in data["controles"] if row["niveau"]=="valeurs" and row["statut"]=="ERREUR"]
            self.assertEqual(errors,[])
            self.assertTrue(data["valeurs_executees"])

    def test_full_fictive_messages_detect_three_independent_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=Path(tmp)/"report.json"
            with redirect_stdout(StringIO()):
                ct.main(["--entree",str(ROOT/"examples_tango/entree_fictive.json"),"--sortie",str(ROOT/"examples_tango/sortie_avec_3_ecarts.json"),"--rapport",str(report)])
            data=json.loads(report.read_text())
            errors=[row for row in data["controles"] if row["niveau"]=="valeurs" and row["statut"]=="ERREUR"]
            self.assertEqual({row["ligne_excel"] for row in errors},{5,31,75})


if __name__=="__main__":
    unittest.main()
