"""Le lot rapproche uniquement des identifiants prouvés uniques."""
import base64
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import demo_v2
import tango_batch

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'examples_reels/2026-10-26/audit_kafka_entree.txt'
OUTPUT = ROOT / 'examples_reels/2026-10-26/audit_sortie_kafka.json'
OLD = b'82fd284e-ef88-4ef5-ba73-1a333fe1cde1'
NEW = b'92fd284e-ef88-4ef5-ba73-1a333fe1cde1'

def item(path, name, replacement=False):
    content=path.read_bytes().replace(OLD,NEW) if replacement else path.read_bytes()
    return {'name':name,'content_base64':base64.b64encode(content).decode()}

class BatchMatchingTests(unittest.TestCase):
    def test_real_pair_has_both_matching_identifiers(self):
        refs=tango_batch.references(ROOT/'donnees_tango/avro.json',ROOT/'donnees_tango/swagger.yaml',ROOT/'profil_tango.json')
        source=tango_batch.input_identity(INPUT,refs)
        target=tango_batch.output_identity(OUTPUT,refs)
        self.assertEqual(source['operationRefId'],target['transaction.context.operationReferenceId'])
        self.assertEqual(source['transRefId'],target['transaction.identification.endToEndTransId'])

    def test_no_positional_pairing_or_conflicting_identifiers(self):
        inputs=[{'operationRefId':'A','transRefId':'A'},{'operationRefId':'B','transRefId':'B'}]
        outputs=[{'transaction.context.operationReferenceId':'B','transaction.identification.endToEndTransId':'B'},
                 {'transaction.context.operationReferenceId':'A','transaction.identification.endToEndTransId':'A'}]
        self.assertEqual(tango_batch.match(inputs,outputs)[0],{0:1,1:0})
        self.assertEqual(tango_batch.match(inputs,[{'transaction.context.operationReferenceId':'A','transaction.identification.endToEndTransId':'B'}])[0],{})

    def test_duplicates_and_missing_ids_are_not_forced(self):
        matches,source_status,target_status=tango_batch.match([{'operationRefId':'A'},{'operationRefId':'A'},{}],[{'transaction.context.operationReferenceId':'A'},{}])
        self.assertEqual(matches,{})
        self.assertEqual(source_status[:2],['ambiguë','ambiguë'])
        self.assertEqual(source_status[2],'sans identifiant')
        self.assertEqual(target_status[0],'ambiguë')

    def test_real_batch_keeps_pair_reports_and_source_files(self):
        original=(hashlib.sha256(INPUT.read_bytes()).digest(),hashlib.sha256(OUTPUT.read_bytes()).digest())
        with tempfile.TemporaryDirectory() as tmp:
            app=demo_v2.LocalApp(Path(tmp),root=ROOT)
            result=app.run({'mode':'batch','label':'Essai lot','files':{
                'entrees':[item(INPUT,'a.txt'),item(INPUT,'b.txt',True)],
                'sorties':[item(OUTPUT,'b.json',True),item(OUTPUT,'a.json')]}})
            batch=result['report']['v2']['batch']
            self.assertEqual(batch['matched'],2)
            self.assertEqual(batch['unmatched'],0)
            self.assertEqual([(row['entree'],row['sortie']) for row in batch['items']],[('a.txt','a.json'),('b.txt','b.json')])
            for row in batch['items']:
                self.assertEqual(row['ecarts_mapping'],14)
                self.assertTrue(app.result(row['rapport_individuel'])['report']['v2']['findings'])
            folder=app.run_folder(result['run']['id'])
            self.assertTrue(all((folder/('rapport.'+ext)).is_file() for ext in ('json','csv','html')))
            self.assertEqual(len(app.history()),3)
        self.assertEqual(original,(hashlib.sha256(INPUT.read_bytes()).digest(),hashlib.sha256(OUTPUT.read_bytes()).digest()))

    def test_unmatched_stays_visible_without_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=demo_v2.LocalApp(Path(tmp),root=ROOT)
            result=app.run({'mode':'batch','files':{'entrees':[item(INPUT,'a.txt')], 'sorties':[item(OUTPUT,'b.json',True)]}})
            batch=result['report']['v2']['batch']
            self.assertEqual(batch['matched'],0)
            self.assertEqual(batch['unmatched'],2)
            self.assertEqual(len(app.history()),1)

if __name__=='__main__': unittest.main()
