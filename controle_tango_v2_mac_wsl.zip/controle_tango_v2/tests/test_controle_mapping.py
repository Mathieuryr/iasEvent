"""Tests de comportement : écarts, schémas, tableaux et contrôles incomplets."""
import json
import tempfile
import unittest
from contextlib import redirect_stdout, redirect_stderr
from decimal import Decimal
from io import StringIO
from pathlib import Path

import fastavro

import controle_mapping as cm

ROOT = Path(__file__).resolve().parents[1]
MAPPING = ROOT / "examples/mapping.xlsx"
COLUMNS = dict(source="source", target="cible", operation="regle", params="parametres", tolerance="tolerance")


class Checks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.report = Path(self.tmp.name) / "rapport.json"
        self.args = ["--avro", str(ROOT / "examples/entree.avsc"), "--mapping", str(MAPPING),
                     "--swagger", str(ROOT / "examples/swagger.json"), "--schema-sortie", "#/components/schemas/EvenementSID",
                     "--rapport", str(self.report)]

    def run_audit(self, extra=()):
        with redirect_stdout(StringIO()), redirect_stderr(StringIO()):
            code = cm.main(self.args + list(extra))
        return code, json.loads(self.report.read_text())

    def catalogs(self, source, target):
        names = {}
        parsed = fastavro.parse_schema(source, named_schemas=names)
        doc = {"openapi": "3.0.3", "components": {"schemas": {"X": target}}}
        left, left_limits = cm.avro_catalog(parsed, names)
        right, right_limits = cm.swagger_catalog(doc, target)
        return left, right, left_limits, right_limits

    def audit_small(self, source, target, rules):
        audit = cm.Audit()
        left, right, left_limits, right_limits = self.catalogs(source, target)
        audit.structures(left, right, rules, left_limits, right_limits)
        return audit.result("structures", {})

    def record(self, datatype="string"):
        return {"type": "record", "name": "Source", "fields": [{"name": "a", "type": datatype}]}

    def target(self, datatype="string"):
        return {"type": "object", "required": ["b"], "properties": {"b": {"type": datatype}}}

    def test_examples_structures(self):
        code, report = self.run_audit()
        self.assertEqual(code, 0, report)
        self.assertEqual(report["compteurs"], {"OK": 7, "ERREUR": 0, "A_VERIFIER": 0})

    def test_examples_both(self):
        code, report = self.run_audit(["--entree", str(ROOT / "examples/entree.json"), "--sortie", str(ROOT / "examples/sortie.json")])
        self.assertEqual(code, 0, report)
        self.assertEqual(report["compteurs"]["OK"], 16)
        self.assertTrue(self.report.with_suffix(".csv").exists())

    def test_bad_output_mapping_and_schema(self):
        code, report = self.run_audit(["--entree", str(ROOT / "examples/entree.json"), "--sortie", str(ROOT / "examples/sortie_avec_erreurs.json")])
        self.assertEqual(code, 1)
        codes = [row["code"] for row in report["controles"]]
        self.assertIn("SORTIE_SWAGGER_INVALIDE", codes)
        self.assertEqual(codes.count("ECART_MAPPING"), 4)

    def test_bad_input_avro_not_hidden(self):
        message = cm.load_document(ROOT / "examples/entree.json")
        message["devise"] = "XXX"
        path = Path(self.tmp.name) / "invalid.json"
        path.write_text(json.dumps(message))
        code, report = self.run_audit(["--entree", str(path), "--sortie", str(ROOT / "examples/sortie.json")])
        self.assertEqual(code, 1)
        self.assertTrue(any(row["code"] == "ENTREE_AVRO_INVALIDE" for row in report["controles"]))

    def test_input_avro_container(self):
        path = Path(self.tmp.name) / "input.avro"
        with path.open("wb") as stream:
            fastavro.writer(stream, cm.load_document(ROOT / "examples/entree.avsc"), [cm.load_document(ROOT / "examples/entree.json")])
        code, report = self.run_audit(["--entree", str(path), "--sortie", str(ROOT / "examples/sortie.json")])
        self.assertEqual(code, 0, report)

    def test_missing_path_and_required_coverage(self):
        code, report = self.audit_small(self.record(), self.target(), [cm.Rule(2, "absent", "x")])
        self.assertEqual(code, 1)
        codes = {row["code"] for row in report["controles"]}
        self.assertTrue({"SOURCE_ABSENTE", "CIBLE_ABSENTE", "CIBLE_OBLIGATOIRE_NON_MAPPEE"} <= codes)

    def test_incompatible_types(self):
        code, _ = self.audit_small(self.record("string"), self.target("integer"), [cm.Rule(2, "a", "b")])
        self.assertEqual(code, 1)

    def test_integer_to_number_is_compatible(self):
        code, report = self.audit_small(self.record("long"), self.target("number"), [cm.Rule(2, "a", "b")])
        self.assertEqual(code, 0, report)

    def test_nullable_cannot_silently_be_non_nullable(self):
        code, _ = self.audit_small(self.record(["null", "string"]), self.target(), [cm.Rule(2, "a", "b")])
        self.assertEqual(code, 1)

    def test_unknown_rule_never_passes(self):
        code, report = self.audit_small(self.record(), self.target(), [cm.Rule(2, "a", "b", "regle_metier")])
        self.assertEqual(code, 3)
        self.assertEqual(report["statut"], "VERIFICATION_INCOMPLETE")

    def test_duplicate_destination(self):
        code, report = self.audit_small(self.record(), self.target(), [cm.Rule(2, "a", "b"), cm.Rule(3, "a", "b")])
        self.assertEqual(code, 1)
        self.assertTrue(any(row["code"] == "CIBLE_DUPLIQUEE" for row in report["controles"]))

    def test_incomplete_enum_dictionary(self):
        source = self.record({"type": "enum", "name": "Code", "symbols": ["A", "B"]})
        code, report = self.audit_small(source, self.target(), [cm.Rule(2, "a", "b", "dictionnaire", {"A": "X"})])
        self.assertEqual(code, 1)
        self.assertTrue(any(row["code"] == "DICTIONNAIRE_INCOMPLET" for row in report["controles"]))

    def test_union_with_free_string_not_mistaken_for_finite_enum(self):
        source = self.record([{"type": "enum", "name": "Code", "symbols": ["A"]}, "string"])
        target = self.target()
        target["properties"]["b"]["enum"] = ["A"]
        code, report = self.audit_small(source, target, [cm.Rule(2, "a", "b")])
        self.assertEqual(code, 3, report)
        self.assertTrue(any(row["code"] == "ENUM_NON_PROUVEE" for row in report["controles"]))

    def test_named_avro_records(self):
        schema = {"type": "record", "name": "Source", "namespace": "demo", "fields": [
            {"name": "a", "type": {"type": "record", "name": "Sub", "fields": [{"name": "id", "type": "string"}]}},
            {"name": "b", "type": "Sub"}]}
        names = {}
        parsed = fastavro.parse_schema(schema, named_schemas=names)
        catalog, limits = cm.avro_catalog(parsed, names)
        self.assertEqual(catalog["b.id"].types, {"string"})
        self.assertFalse(limits)

    def test_allof_explicitly_incomplete_but_values_validated(self):
        target = {"allOf": [self.target()]}
        code, report = self.audit_small(self.record(), target, [cm.Rule(2, "a", "b")])
        self.assertEqual(code, 3, report)
        doc = {"openapi": "3.0.3", "components": {"schemas": {"X": target}}}
        validator, _ = cm.make_output_validator(doc, "#/components/schemas/X")
        self.assertTrue(list(validator.iter_errors({})))

    def test_swagger_20_local_refs(self):
        doc = {"swagger": "2.0", "definitions": {"X": self.target()}}
        validator, _ = cm.make_output_validator(doc, "#/definitions/X")
        self.assertFalse(list(validator.iter_errors({"b": "ok"})))
        self.assertTrue(list(validator.iter_errors({"b": 3})))

    def test_openapi_31_union_and_nested_local_refs(self):
        doc = {"openapi": "3.1.1", "components": {"schemas": {
            "X": {"type": "object", "properties": {"b": {"$ref": "#/components/schemas/Y"}}},
            "Y": {"type": ["string", "null"]}}}}
        validator, _ = cm.make_output_validator(doc, "#/components/schemas/X")
        self.assertFalse(list(validator.iter_errors({"b": None})))
        self.assertTrue(list(validator.iter_errors({"b": 3})))

    def test_nullable_openapi_30(self):
        doc = {"openapi": "3.0.3", "components": {"schemas": {"X": {"type": "string", "nullable": True}}}}
        validator, _ = cm.make_output_validator(doc, "#/components/schemas/X")
        self.assertFalse(list(validator.iter_errors(None)))

    def test_no_automatic_external_reference_fetch(self):
        with self.assertRaises(cm.ConfigurationError):
            cm.swagger_catalog({}, {"$ref": "https://example.invalid/secret-schema.json"})

    def test_schema_format_date_is_enforced(self):
        doc = {"openapi": "3.0.3", "components": {"schemas": {"X": {"type": "string", "format": "date"}}}}
        validator, _ = cm.make_output_validator(doc, "#/components/schemas/X")
        self.assertTrue(list(validator.iter_errors("2026-02-30")))

    def test_missing_on_both_sides_is_error(self):
        audit = cm.Audit()
        audit.values({}, {}, [cm.Rule(2, "a", "b")])
        self.assertEqual(audit.result("values", {})[0], 1)

    def test_nested_array_alignment_and_missing_elements(self):
        msg = {"a": [{"id": "1"}, {}]}
        found = cm.extract(msg, "a[].id")
        self.assertIs(found[1], cm.MISSING)
        issues = cm.differences(found, ["1", "2"], Decimal(0))
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["chemin"], "[1]")
        self.assertTrue(cm.differences(["1", "2"], ["2", "1"], Decimal(0)))

    def test_tolerance_and_strict_types(self):
        self.assertFalse(cm.differences(Decimal("1.01"), 1, Decimal("0.01")))
        self.assertTrue(cm.differences(Decimal("1.011"), 1, Decimal("0.01")))
        self.assertTrue(cm.differences(True, 1, Decimal("100")))
        self.assertTrue(cm.differences("1", 1, Decimal("100")))

    def test_decimal_and_integer_never_truncate(self):
        self.assertEqual(cm.transform("1.235", cm.Rule(2, "a", "b", "decimal", {"decimales": 2})), "1.24")
        with self.assertRaises(ValueError):
            cm.transform("1.2", cm.Rule(2, "a", "b", "entier"))
        with self.assertRaises(ValueError):
            cm.transform("NaN", cm.Rule(2, "a", "b", "nombre"))

    def test_parameters_are_checked_without_messages(self):
        for rule in [cm.Rule(2, "a", "b", "decimal"), cm.Rule(2, "a", "b", "date_iso"), cm.Rule(2, "a", "b", "dictionnaire", {})]:
            with self.assertRaises(cm.ConfigurationError):
                cm.validate_rule(rule)

    def test_mapping_read_uses_declared_cells(self):
        rows = cm.read_mapping(MAPPING, None, 1, COLUMNS)
        self.assertEqual(len(rows), 7)
        self.assertEqual(rows[-1].params, "SAE")

    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(cm.ConfigurationError):
            cm.strict_json('{"id":"a","id":"b"}')

    def test_duplicate_yaml_keys_rejected(self):
        path = Path(self.tmp.name) / "duplicate.yaml"
        path.write_text('openapi: 3.0.3\nopenapi: 3.1.1\n')
        with self.assertRaises(cm.ConfigurationError):
            cm.load_document(path)

    def test_unmapped_optional_fields_are_visible(self):
        target = self.target()
        target["properties"]["optional"] = {"type": "string"}
        code, report = self.audit_small(self.record(), target, [cm.Rule(2, "a", "b")])
        self.assertEqual(code, 0)
        self.assertEqual(report["couverture"]["cibles_non_mappees"], ["optional"])

    def test_invalid_file_replaces_report_with_error(self):
        code, report = self.run_audit(["--swagger", str(Path(self.tmp.name) / "absent.json")])
        self.assertEqual(code, 2)
        self.assertEqual(report["statut"], "ERREUR_CONFIGURATION")

    def test_report_cannot_overwrite_source(self):
        with redirect_stderr(StringIO()), self.assertRaises(SystemExit):
            cm.arguments(self.args + ["--rapport", str(ROOT / "examples/swagger.json")])

    def test_report_requires_json_extension(self):
        with redirect_stderr(StringIO()), self.assertRaises(SystemExit):
            cm.arguments(self.args + ["--rapport", str(self.report.with_suffix(".csv"))])

    def test_binary_mismatch_remains_reportable(self):
        audit = cm.Audit()
        audit.values({"a": b"example"}, {"b": "example"}, [cm.Rule(2, "a", "b")])
        code, report = audit.result("values", {})
        self.assertEqual(code, 1)
        cm.write_report(self.report, report)
        self.assertEqual(json.loads(self.report.read_text())["controles"][0]["attendu"]["type"], "bytes")


if __name__ == "__main__":
    unittest.main()
