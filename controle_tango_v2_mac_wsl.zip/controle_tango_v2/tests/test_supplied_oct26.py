"""Régressions sur la paire du 26 octobre et le mapping nouvellement fourni."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

import controle_tango as ct
import v2_reporting


ROOT = Path(__file__).resolve().parents[1]


class SuppliedOctoberPairChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory(prefix="tango_oct26_") as temporary:
            report = Path(temporary) / "report.json"
            with contextlib.redirect_stdout(io.StringIO()):
                cls.code = ct.main(["--entree", str(ROOT / "examples_reels/2026-10-26/audit_kafka_entree.txt"),
                                    "--sortie", str(ROOT / "examples_reels/2026-10-26/audit_sortie_kafka.json"),
                                    "--rapport", str(report)])
            cls.report = json.loads(report.read_text(encoding="utf-8"))
        cls.values = [row for row in cls.report["controles"] if row["niveau"] == "valeurs"]

    def test_current_workbook_selection_and_input_scope_are_used(self):
        self.assertEqual(self.code, 1)
        self.assertEqual(self.report["couverture"]["lignes_actives"], 322)
        self.assertEqual(self.report["couverture"]["selection"]["lignes_marquees"], 324)
        rows = {row["row"] for row in self.report["mapping_resolu"]}
        self.assertIn(453, rows)
        self.assertFalse({431, 492} & rows)
        self.assertEqual(self.report["decisions"]["perimetre_comparaison"], "sources_presentes_uniquement")

    def test_output_authentication_amount_without_source_is_ignored(self):
        rows = [row for row in self.values if row["ligne_excel"] == 196]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["code"], "SOURCE_ABSENTE_IGNOREE")
        self.assertNotIn("obtenu", rows[0])

    def test_present_sources_still_identify_missing_and_different_targets(self):
        mapping = [row for row in self.values if row["statut"] == "ERREUR" and row["code"] in {"ECART_MAPPING", "ECART_PRESENCE"}]
        self.assertEqual(len(mapping), 14)
        self.assertEqual({row["ligne_excel"] for row in mapping}, {52, 65, 66, 121, 128, 129, 263, 264, 266, 267, 271, 453, 461})
        expected = next(row for row in mapping if row["ligne_excel"] == 453)
        self.assertEqual(expected["attendu"], "DEBT")
        self.assertFalse(any(row["niveau"] == "interne" for row in self.report["controles"]))

    def test_global_contract_checks_remain_separate_from_mapping_counts(self):
        decorated = v2_reporting.decorate_report(self.report.copy())
        summary = decorated["v2"]["summary"]
        self.assertEqual(summary["mapping_errors"], 14)
        self.assertEqual(summary["schema_errors"], 13)
        self.assertEqual(summary["reference_errors"], 4)
        self.assertEqual(summary["rules_in_scope"], 66)
        self.assertEqual(summary["ignored_rules"], 236)

    def test_real_input_output_view_keeps_source_and_transformed_value_distinct(self):
        row = next(item for item in self.values if item.get("ligne_excel") == 453)
        comparison = row["visualisation"]
        self.assertTrue(comparison["applicable"])
        self.assertIn({"path": "processingInfo.amountType", "state": "present", "value": "D"}, comparison["inputs"])
        self.assertEqual(comparison["expected"], {"state": "known", "value": "DEBT"})
        self.assertIn({"path": "transaction.context.debitCreditIndicator", "state": "present", "value": {"DebitCreditIndicator": "DEBT"}}, comparison["outputs"])

    def test_conforming_values_are_visible_and_ignored_output_remains_unread(self):
        conforming = next(item for item in self.values if item.get("ligne_excel") == 5)
        self.assertEqual(conforming["statut"], "OK")
        comparison = conforming["visualisation"]
        self.assertTrue(comparison["inputs"])
        self.assertTrue(comparison["outputs"])
        self.assertEqual(comparison["expected"]["state"], "known")
        ignored = next(item for item in self.values if item.get("ligne_excel") == 196)["visualisation"]
        self.assertFalse(ignored["applicable"])
        self.assertEqual(ignored["outputs"], [])


if __name__ == "__main__":
    unittest.main()
