import copy
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch

import fastavro

import controle_mapping as cm
import controle_tango as ct
import tango_mapping as tm
import v2_reporting


ROOT=Path(__file__).resolve().parents[1]


class V2AuditChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile=cm.load_document(ROOT/'profil_tango.json')
        names={}
        cls.schema=fastavro.parse_schema(cm.load_document(ROOT/'donnees_tango/avro.json'),named_schemas=names)
        cls.source,_=cm.avro_catalog(cls.schema,names)
        cls.document=cm.load_document(ROOT/'donnees_tango/swagger.yaml')
        cls.validator,selected=cm.make_output_validator(cls.document,cls.profile['schema_sortie'])
        cls.target,_=cm.swagger_catalog(cls.document,selected)
        lines,cls.meta=tm.import_mapping(ROOT/'donnees_tango/mapping.xlsm',cls.source,cls.target)
        cls.lines=ct.configure(lines,cls.profile,cls.source,cls.target)
        cls.byrow={line.row:line for line in cls.lines}

    def test_valid_date_configuration_removes_pending_structure(self):
        profile=copy.deepcopy(self.profile)
        profile['formats_dates']['processingInfo.startDateTime']={'entree':'epoch-ms','sortie':'iso-utc-ms'}
        audit=ct.TangoAudit()
        audit.structures([self.byrow[441]],self.source,self.target,[],profile)
        self.assertFalse(any(row['code']=='REGLE_A_COMPLETER' for row in audit.rows))
        self.assertTrue(any(row['statut']=='OK' for row in audit.rows))

    def test_per_source_money_configuration_removes_pending_structure(self):
        profile=copy.deepcopy(self.profile)
        profile['monnaie']['unites_par_source']={'transactionAmt':'majeure'}
        audit=ct.TangoAudit()
        audit.structures([self.byrow[132]],self.source,self.target,[],profile)
        self.assertFalse(any(row['code']=='ECHELLE_MONETAIRE' for row in audit.rows))

    def test_code_only_limit_needs_no_monetary_configuration(self):
        audit=ct.TangoAudit()
        audit.structures([self.byrow[461]],self.source,self.target,[],self.profile)
        self.assertFalse(any(row['code']=='ECHELLE_MONETAIRE' for row in audit.rows))

    def test_missing_money_and_date_configuration_stay_pending(self):
        audit=ct.TangoAudit()
        audit.structures([self.byrow[441],self.byrow[132]],self.source,self.target,[],self.profile)
        self.assertTrue({'REGLE_A_COMPLETER','ECHELLE_MONETAIRE'} <= {row['code'] for row in audit.rows})

    def test_independent_reference_no_longer_claimed_missing(self):
        audit=ct.TangoAudit()
        audit.structures([self.byrow[519]],self.source,self.target,[],self.profile,{'cardholder.id':'REFERENCE-TEST'})
        self.assertTrue(any(row['code']=='REFERENCE_FOURNIE' for row in audit.rows))
        self.assertFalse(any(row['statut']=='A_VERIFIER' for row in audit.rows))

    def test_unexpected_failure_of_one_rule_keeps_other_findings(self):
        import tango_engine as engine
        original=engine.expected
        def failing(line,*args):
            if line.row==5:raise RuntimeError('défaut interne simulé')
            return original(line,*args)
        audit=ct.TangoAudit()
        with patch.object(engine,'expected',side_effect=failing):
            audit.values([self.byrow[5],self.byrow[10]],{'ISOMTI':100,'bankId':'30004'}, {'issuer':{'institutionId':'30004'},'eventProcessingData':{'eventNature':'IAS_ONLINE_AUTH_AUTHORISATION'}},None,self.profile,{})
        self.assertTrue(any(row['code']=='ERREUR_INTERNE_REGLE' for row in audit.rows))
        self.assertTrue(any(row['ligne_excel']==10 and row['statut']=='OK' for row in audit.rows))

    def test_invalid_occurrence_preserves_full_report(self):
        incoming=cm.load_document(ROOT/'examples_tango/entree_fictive.json')
        incoming.setdefault('processingInfo',{})['limitResultList']=[None]
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);source=folder/'input.json';source.write_text(json.dumps(incoming))
            report=folder/'report.json'
            with redirect_stdout(StringIO()):
                code=ct.main(['--entree',str(source),'--sortie',str(ROOT/'examples_tango/sortie_fictive.json'),'--rapport',str(report)])
            data=json.loads(report.read_text())
        self.assertEqual(code,1)
        self.assertEqual(data['mode'],'structures_et_valeurs')
        self.assertTrue(any(row['code']=='ENTREE_AVRO_INVALIDE' for row in data['controles']))
        self.assertTrue(any(row['code']=='DONNEE_OU_TRANSFORMATION' and 'limitResultList[0]' in row['detail'] for row in data['controles']))
        self.assertGreater(len(data['controles']),10)

    def test_orphaned_group_member_is_not_reported_as_covered(self):
        lines=copy.deepcopy([self.byrow[143]])
        ct.configure(lines,self.profile,self.source,self.target)
        self.assertEqual(lines[0].operation,'a_definir')
        self.assertIn('parent',lines[0].parameters['raison'])

    def test_partial_ambiguous_amount_group_stays_pending(self):
        lines=copy.deepcopy([self.byrow[142],self.byrow[143]])
        ct.configure(lines,self.profile,self.source,self.target)
        self.assertTrue(all(line.operation=='a_definir' for line in lines))


class V2ReportingChecks(unittest.TestCase):
    def test_schema_path_action_and_actual_value_are_visible(self):
        report={'controles':[{'niveau':'valeurs','code':'SORTIE_SWAGGER_INVALIDE','statut':'ERREUR','chemin':'transaction.eMV.terminalTransactionDate','detail':"'140801' is not a 'date'",'obtenu':'140801'}]}
        result=v2_reporting.decorate_report(report)
        finding=result['v2']['findings'][0]
        self.assertEqual(finding['category'],'schema')
        self.assertEqual(finding['target'],'transaction.eMV.terminalTransactionDate')
        self.assertIn('AAAA-MM-JJ',finding['action'])
        self.assertTrue(finding['has_actual'])
        self.assertEqual(result['v2']['summary']['schema_errors'],1)
        self.assertEqual(result['v2']['summary']['mapping_errors'],0)

    def test_reference_decisions_and_value_decisions_have_separate_counts(self):
        report={'controles':[{'niveau':level,'code':'TEST','statut':'A_VERIFIER'} for level in ['structure','valeurs','preparation']]}
        summary=v2_reporting.decorate_report(report)['v2']['summary']
        self.assertEqual(summary['pending'],1)
        self.assertEqual(summary['reference_pending'],1)
        self.assertEqual(summary['preparation_pending'],1)

    def test_export_escapes_data_and_retains_null_as_known_value(self):
        report={'controles':[{'niveau':'valeurs','code':'ECART_MAPPING','statut':'ERREUR','cible':'<script>bad()</script>','detail':'<img src=x>','attendu':None,'obtenu':'</pre><script>bad()</script>'}]}
        v2_reporting.decorate_report(report)
        self.assertTrue(report['v2']['findings'][0]['has_expected'])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'report.html';v2_reporting.write_html(path,report,{'label':'<script>label</script>'})
            content=path.read_text()
        self.assertNotIn('<script>',content)
        self.assertIn('&lt;script&gt;',content)
        self.assertIn('null',content)

    def test_csv_keeps_types_actions_and_prevents_excel_formulas(self):
        import csv
        report={'controles':[{'niveau':'valeurs','code':'ECART_MAPPING','statut':'ERREUR','source':'=malicious()','cible':'id','attendu':'000009','obtenu':None}]}
        v2_reporting.decorate_report(report)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'report.csv';v2_reporting.write_csv(path,report)
            with path.open(encoding='utf-8-sig',newline='') as stream:row=next(csv.DictReader(stream,delimiter=';'))
        self.assertEqual(row['attendu'],'"000009"')
        self.assertEqual(row['obtenu'],'null')
        self.assertTrue(row['source'].startswith("'="))
        self.assertTrue(row['action'])


if __name__=='__main__':unittest.main()
