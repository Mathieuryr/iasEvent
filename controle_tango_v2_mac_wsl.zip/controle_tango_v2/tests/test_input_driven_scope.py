"""Périmètre événement : retrouver les correspondances des données d'entrée.

Ces tests ne demandent aucune omission des champs fournis uniquement en sortie.
"""
from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import patch

import controle_mapping as cm
import controle_tango as ct
import tango_engine as engine


def rule(**changes):
    values = dict(row=10, source="source", targets=["target"], operation="copie",
                  parameters={}, presence="required", location="body", marked=True,
                  raw_attribute="target", notes=[])
    values.update(changes)
    return SimpleNamespace(**values)


def control(row, attribute, source):
    return rule(row=row, raw_attribute=attribute, source=source,
                targets=["transaction.issuerControlList"], operation="controles_emetteur",
                parameters={"sources": ["processingInfo.ACResultList", "processingInfo.IASTechInfo.ACResultList"]})


def limit(row=10, attribute="usageCurrentValueLimitAmount"):
    return rule(row=row, raw_attribute=attribute, source="processingInfo.limitResultList",
                targets=["card.usageCurrentValueList"], operation="limites")


def audit(rules, incoming, outgoing, *, headers=None, conflicts=(), profile=None):
    result = ct.TangoAudit()
    result.conflicting_targets.update(conflicts)
    result.values(rules, incoming, outgoing, headers,
                  profile or {"decisions": {"event_nature_source": "ISOMTI"}}, {})
    return result.rows


class SourceScopeChecks(unittest.TestCase):
    def test_selected_control_code_ignores_unselected_full_name(self):
        for extra in ('OTHER',None):
            with self.subTest(extra=extra):
                rows=audit([control(484,'code','processingInfo.ACResultList[].controlName')],
                           {'processingInfo':{'ACResultList':[{'controlName':'CTRL_X'}]}},
                           {'transaction':{'issuerControlList':[{'code':'CTRL','controlCode':extra}]}})
                self.assertEqual(rows[0]['statut'],'OK')

    def test_selected_control_full_name_ignores_unselected_short_code(self):
        rows=audit([control(485,'controlCode','processingInfo.ACResultList[].controlName')],
                   {'processingInfo':{'ACResultList':[{'controlName':'CTRL_X'}]}},
                   {'transaction':{'issuerControlList':[{'controlCode':'CTRL_X','code':'OTHER'}]}})
        self.assertEqual(rows[0]['statut'],'OK')

    def test_absent_and_null_sources_are_skipped_without_observing_or_transforming(self):
        for incoming in ({}, {"source": None}):
            for location in ("body", "headers"):
                with self.subTest(incoming=incoming, location=location), \
                        patch.object(engine, "observed", side_effect=AssertionError("hors périmètre")) as observed, \
                        patch.object(engine, "expected", side_effect=AssertionError("hors périmètre")) as expected:
                    rows = audit([rule(location=location)], incoming, {"target": {"malformed": True}})
                    self.assertEqual(rows[0]["code"], "SOURCE_ABSENTE_IGNOREE")
                    self.assertEqual(rows[0]["statut"], "NON_APPLICABLE")
                    observed.assert_not_called()
                    expected.assert_not_called()

    def test_source_without_identified_correspondence_is_skipped_before_evaluation(self):
        for operation in ("contexte", "decision_header"):
            with self.subTest(operation=operation), patch.object(engine, "observed") as observed, patch.object(engine, "expected") as expected:
                rows = audit([rule(source="", operation=operation)], {"unrelated": 1}, {"target": "enriched"})
                self.assertEqual(rows[0]["code"], "SOURCE_NON_IDENTIFIEE_HORS_PERIMETRE")
                self.assertEqual(rows[0]["statut"], "NON_APPLICABLE")
                observed.assert_not_called()
                expected.assert_not_called()

    def test_only_supplied_scalar_source_is_compared(self):
        rows = audit([rule(), rule(row=11, source="other", targets=["extra"])],
                     {"source": "A"}, {"target": "B", "extra": {"free": "unrelated"}})
        applicable = [item for item in rows if item["statut"] != "NON_APPLICABLE"]
        self.assertEqual(len(applicable), 1)
        self.assertEqual(applicable[0]["code"], "ECART_MAPPING")
        self.assertEqual(applicable[0]["ligne_excel"], 10)

    def test_zero_false_and_empty_scalar_collections_remain_supplied(self):
        for value in (0, False, "", [], {}):
            with self.subTest(value=value):
                rows = audit([rule()], {"source": value}, {})
                self.assertEqual(rows[0]["code"], "ECART_PRESENCE")

    def test_empty_array_projection_has_no_data_to_compare(self):
        rows = audit([rule(source="items[].value")], {"items": []}, {"target": "ignored"})
        self.assertEqual(rows[0]["code"], "SOURCE_ABSENTE_IGNOREE")

    def test_absent_score_source_does_not_inspect_malformed_output_list(self):
        rows = audit([rule(operation="score", targets=["riskScoringList"], parameters={"code": "04"})],
                     {}, {"riskScoringList": [None]})
        self.assertEqual(rows[0]["code"], "SOURCE_ABSENTE_IGNOREE")

    def test_present_known_source_wins_over_unidentified_shared_source(self):
        rules = [rule(row=11, source="", operation="contexte"), rule(row=12, source="source")]
        for output, expected in (("A", "OK"), ("B", "ERREUR")):
            with self.subTest(output=output):
                rows = audit(rules, {"source": "A"}, {"target": output}, conflicts={"target"})
                row = next(item for item in rows if item["ligne_excel"] == 12)
                self.assertEqual(row["statut"], expected)
                self.assertFalse(any(item["code"] == "PRIORITE_NON_DEFINIE" for item in rows))

    def test_all_absent_shared_sources_ignore_the_existing_output(self):
        rules = [rule(row=11, source="first"), rule(row=12, source="second")]
        rows = audit(rules, {}, {"target": "ignored"}, conflicts={"target"})
        self.assertTrue(rows)
        self.assertTrue(all(item["statut"] == "NON_APPLICABLE" for item in rows))
        self.assertFalse(any(item["code"] == "ECART_PRESENCE" for item in rows))


class DirectionalValueChecks(unittest.TestCase):
    def test_additional_output_object_fields_are_not_compared(self):
        incoming = {"source": {"known": {"value": "A"}}}
        outgoing = {"target": {"known": {"value": "A", "extra": None}, "other": "unrelated"}}
        self.assertEqual(audit([rule()], incoming, outgoing)[0]["statut"], "OK")

    def test_nested_null_and_missing_input_fields_are_outside_scope(self):
        incoming = {"source": {"active": 0, "optional": None,
                                "nested": {"known": "A", "missing": cm.MISSING}}}
        for outgoing in (
                {"target": {"active": 0, "nested": {"known": "A"}}},
                {"target": {"active": 0, "optional": "ignored",
                            "nested": {"known": "A", "missing": "also ignored"}}}):
            with self.subTest(outgoing=outgoing):
                rows = audit([rule()], incoming, outgoing)
                self.assertEqual(rows[0]["statut"], "OK", rows)

    def test_null_holes_in_array_projection_do_not_require_output_occurrences(self):
        incoming = {"items": [{"other": "not the mapped field"}, {"value": None}, {"value": 0}]}
        rows = audit([rule(source="items[].value")], incoming, {"target": ["extra", 0]})
        self.assertEqual(rows[0]["statut"], "OK", rows)

    def test_array_projection_with_only_null_or_missing_values_is_ignored(self):
        incoming = {"items": [{"other": "unrelated"}, {"value": None}]}
        rows = audit([rule(source="items[].value")], incoming, {"target": "outside scope"})
        self.assertEqual(rows[0]["code"], "SOURCE_ABSENTE_IGNOREE", rows)

    def test_present_nested_value_is_still_checked_among_extra_fields(self):
        rows = audit([rule()], {"source": {"known": "A"}}, {"target": {"known": "B", "extra": "A"}})
        self.assertEqual(rows[0]["code"], "ECART_MAPPING")
        self.assertEqual(rows[0]["chemin"], "target.known")

    def test_output_list_is_matched_without_order_and_can_contain_extra_records(self):
        expected = [{"code": "A"}, {"code": "B", "value": {"number": 2}}]
        actual = [{"code": "EXTRA"}, {"code": "B", "value": {"number": 2, "other": 3}}, {"code": "A", "unknown": True}]
        self.assertFalse(engine.diff(expected, actual, rule()))

    def test_list_duplicates_cannot_be_satisfied_by_a_single_output_occurrence(self):
        expected = [{"code": "A"}, {"code": "A"}]
        actual = [{"code": "A"}, {"code": "OTHER"}, {"code": "OTHER"}]
        self.assertTrue(engine.diff(expected, actual, rule()))

    def test_nested_subset_match_reassigns_overlapping_candidates(self):
        expected = [{"code": "A"}, {"code": "A", "number": 2}]
        actual = [{"code": "A", "number": 2}, {"code": "A", "number": 3}]
        self.assertFalse(engine.diff(expected, actual, rule()))

    def test_missing_expected_nested_field_remains_an_error(self):
        self.assertTrue(engine.diff({"known": 1}, {"extra": 1}, rule()))

    def test_generic_contract_comparator_keeps_its_original_exact_behavior(self):
        from decimal import Decimal
        self.assertTrue(cm.differences({"known": 1}, {"known": 1, "extra": 2}, Decimal(0)))


class GroupInputScopeChecks(unittest.TestCase):
    def control_rules(self):
        return [control(484, "code", "processingInfo.ACResultList[].controlName"),
                control(486, "controlResponseCode", "processingInfo.ACResultList[].resultCode")]

    def test_control_masks_follow_each_input_occurrence(self):
        incoming = {"processingInfo": {"ACResultList": [
            {"controlName": "FIRST", "resultCode": 0},
            {"controlName": "SECOND", "resultCode": None}]}}
        outgoing = {"transaction": {"issuerControlList": [
            {"code": "EXTRA", "responseCode": "different"},
            {"code": "SECOND", "responseCode": "not supplied in input"},
            {"code": "FIRST", "responseCode": "0"}]}}
        rows = audit(self.control_rules(), incoming, outgoing)
        self.assertFalse([item for item in rows if item["statut"] in {"ERREUR", "A_VERIFIER"}], rows)

    def test_direct_control_rule_also_ignores_absent_fields_and_extra_outputs(self):
        line = self.control_rules()[0]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL"}]}}
        expected = engine.expected(line, incoming, {}, {})
        actual = [{"code": "EXTRA", "controlCode": "OTHER"},
                  {"code": "CTRL", "controlCode": "CTRL", "responseCode": "ignored"}]
        self.assertFalse(engine.diff(expected, actual, line))

    def test_unrelated_complete_control_does_not_hide_missing_mapped_response(self):
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL", "resultCode": 0}]}}
        outgoing = {"transaction": {"issuerControlList": [
            {"code": "CTRL"}, {"code": "OTHER", "responseCode": "0"}]}}
        rows = audit(self.control_rules(), incoming, outgoing)
        errors = [item for item in rows if item["statut"] == "ERREUR"]
        self.assertTrue(errors, rows)
        self.assertTrue(any(item["code"] == "ECART_PRESENCE" for item in errors), errors)

    def test_missing_whole_group_source_ignores_malformed_target(self):
        for operation, rules, outgoing in (
                ("controles_emetteur", self.control_rules(), {"transaction": {"issuerControlList": [None]}}),
                ("limites", [limit()], {"card": {"usageCurrentValueList": [None]}})):
            with self.subTest(operation=operation):
                rows = audit(rules, {"processingInfo": {}}, outgoing)
                self.assertFalse([item for item in rows if item["statut"] in {"ERREUR", "A_VERIFIER"}], rows)

    def test_limit_presence_uses_the_matching_code_even_when_money_rule_is_pending(self):
        incoming = {"currency": "978", "processingInfo": {"limitResultList": [{"limitId": 31, "maxTotalAmt": "2"}]}}
        outgoing = {"card": {"usageCurrentValueList": [
            {"code": "PDOM"},
            {"code": "PINT", "limitAmount": {"amount": "2", "currency": "978"}}]}}
        rows = audit([limit()], incoming, outgoing)
        self.assertTrue(any(item["code"] == "ECART_PRESENCE" for item in rows), rows)

    def test_absent_limit_amount_does_not_become_a_constraint_on_output(self):
        rules = [limit(row=461, attribute="usageCurrentValueCode"), limit(row=469)]
        incoming = {"processingInfo": {"limitResultList": [{"limitId": 31, "maxTotalAmt": None}]}}
        outgoing = {"card": {"usageCurrentValueList": [{"code": "PDOM", "limitAmount": {"anything": "ignored"}}]}}
        rows = audit(rules, incoming, outgoing)
        self.assertFalse([item for item in rows if item["statut"] in {"ERREUR", "A_VERIFIER"}], rows)

    def test_group_source_duplicate_needs_distinct_output_correspondences(self):
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL"}, {"controlName": "CTRL"}]}}
        outgoing = {"transaction": {"issuerControlList": [{"code": "CTRL"}, {"code": "OTHER"}]}}
        rows = audit([self.control_rules()[0]], incoming, outgoing)
        self.assertTrue(any(item["statut"] == "ERREUR" for item in rows), rows)


if __name__ == "__main__":
    unittest.main()
