"""Contrats de la démo locale : vrais contrôles et échanges HTTP en boucle locale."""
from __future__ import annotations

import base64
import errno
import hashlib
import http.client
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

import demo_v2 as demo


ROOT = Path(__file__).resolve().parents[1]
SOURCE_NAMES = ("audit_KAFKA.txt", "Kafka_audit_sortie.txt")


def source_hashes():
    return {name: hashlib.sha256((ROOT / "examples_reels" / name).read_bytes()).hexdigest() for name in SOURCE_NAMES}


def uploaded_pair():
    names = {"entree": "Entrée SAE éç 漢字.txt", "sortie": "Sortie SID ü 漢字.txt"}
    return {
        key: {"name": names[key], "content_base64": base64.b64encode((ROOT / "examples_reels" / filename).read_bytes()).decode("ascii")}
        for key, filename in zip(("entree", "sortie"), SOURCE_NAMES)
    }


class LocalAppIntegrationChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix="tango_v2_backend_")
        cls.original_hashes = source_hashes()
        cls.app = demo.LocalApp(Path(cls.temporary.name) / "historique", root=ROOT)
        cls.original = cls.app.run({"mode": "demo", "label": "Recette de départ"})
        cls.corrected = cls.app.run({"mode": "demo-corrected"})
        cls.custom = cls.app.run({"mode": "custom", "label": "<script>démo</script>", "files": uploaded_pair()})

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_corrected_copy_removes_one_mapping_error_and_keeps_sources_intact(self):
        before = self.original["report"]["v2"]["summary"]
        after = self.corrected["report"]["v2"]["summary"]
        self.assertEqual(after["mapping_errors"], before["mapping_errors"] - 1)
        self.assertEqual(after["schema_errors"], before["schema_errors"])
        self.assertEqual(after["reference_errors"], before["reference_errors"])
        self.assertEqual(source_hashes(), self.original_hashes)
        comparison = self.corrected["report"]["v2"]["comparison"]
        self.assertEqual(comparison["corrected"], 1)
        self.assertEqual(comparison["new"], 0)

    def test_custom_unicode_files_use_default_references_and_real_engine(self):
        result = self.custom
        self.assertEqual(result["run"]["source_names"]["entree"], "Entrée SAE éç 漢字.txt")
        self.assertEqual(result["run"]["source_names"]["sortie"], "Sortie SID ü 漢字.txt")
        self.assertEqual(result["report"]["decisions"]["event_nature_source"], "ISOMTI")
        self.assertTrue(all(line["marked"] for line in result["report"]["mapping_resolu"]))
        self.assertEqual(result["report"]["v2"]["summary"], self.original["report"]["v2"]["summary"])
        expected_mapping = hashlib.sha256((ROOT / "donnees_tango/mapping.xlsm").read_bytes()).hexdigest()
        self.assertEqual(result["report"]["fichiers"]["mapping"]["sha256"], expected_mapping)

    def test_history_and_exports_survive_a_new_app_instance(self):
        reopened = demo.LocalApp(self.app.data_dir, root=ROOT)
        expected_ids = {result["run"]["id"] for result in (self.original, self.corrected, self.custom)}
        self.assertTrue(expected_ids <= {run["id"] for run in reopened.history()})
        result = reopened.result(self.custom["run"]["id"])
        self.assertEqual(result, self.custom)
        folder = reopened.run_folder(self.custom["run"]["id"])
        for suffix in ("json", "csv", "html"):
            self.assertGreater((folder / ("rapport." + suffix)).stat().st_size, 0)
        html = (folder / "rapport.html").read_text(encoding="utf-8")
        self.assertNotIn("<script>démo</script>", html)
        self.assertIn("&lt;script&gt;démo&lt;/script&gt;", html)
        self.assertIn("transaction.eMV.terminalTransactionDate", html)

    def test_upload_errors_are_actionable_and_size_limit_is_enforced(self):
        bad = uploaded_pair()
        bad["entree"]["content_base64"] = "%%%invalide%%%"
        with self.assertRaises(demo.DemoError) as error:
            self.app.run({"mode": "custom", "files": bad})
        self.assertEqual(error.exception.status, 400)
        with patch.object(demo, "MAX_FILE_BYTES", 8), self.assertRaises(demo.DemoError) as error:
            self.app.decode_files({"entree": {"name": "message.txt", "content_base64": base64.b64encode(b"123456789").decode("ascii")}, "sortie": uploaded_pair()["sortie"]})
        self.assertEqual(error.exception.status, 413)


class LocalHttpIntegrationChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix="tango_v2_http_")
        cls.app = demo.LocalApp(Path(cls.temporary.name) / "historique", root=ROOT)
        try:
            cls.server = demo.DemoServer(("127.0.0.1", 0), cls.app)
        except OSError as exc:
            cls.temporary.cleanup()
            if exc.errno in {errno.EACCES, errno.EPERM}:
                raise unittest.SkipTest("Le sandbox interdit les sockets localhost ; relancer ces tests avec l'autorisation réseau locale.") from exc
            raise
        cls.port = cls.server.server_address[1]
        cls.silence_logs = patch.object(demo.DemoHandler, "log_message", lambda *_args, **_kwargs: None)
        cls.silence_logs.start()
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join(timeout=5)
        cls.server.server_close()
        cls.silence_logs.stop()
        cls.temporary.cleanup()

    def request(self, method, path, payload=None, headers=None):
        current_headers = dict(headers or {})
        if payload is not None and not isinstance(payload, bytes):
            payload = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            current_headers.setdefault("Content-Type", "application/json")
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=100)
        try:
            connection.request(method, path, body=payload, headers=current_headers)
            response = connection.getresponse()
            body = response.read()
            return response.status, dict(response.getheaders()), body
        finally:
            connection.close()

    def json_request(self, method, path, payload=None, headers=None):
        status, response_headers, body = self.request(method, path, payload, headers)
        return status, response_headers, json.loads(body.decode("utf-8"))

    def test_same_origin_demo_corrected_history_and_exports(self):
        status, headers, state = self.json_request("GET", "/api/state")
        self.assertEqual(status, 200)
        self.assertEqual(state["version"], demo.VERSION)
        self.assertTrue(state["demo"]["available"])
        self.assertEqual(headers["Cache-Control"], "no-store")
        original_hashes = source_hashes()
        origin = {"Origin": f"http://127.0.0.1:{self.port}"}
        status, _, original = self.json_request("POST", "/api/run", {"mode": "demo"}, origin)
        self.assertEqual(status, 200)
        status, _, corrected = self.json_request("POST", "/api/run", {"mode": "demo-corrected"}, origin)
        self.assertEqual(status, 200)
        self.assertEqual(corrected["report"]["v2"]["summary"]["mapping_errors"], original["report"]["v2"]["summary"]["mapping_errors"] - 1)
        self.assertEqual(source_hashes(), original_hashes)
        run_id = corrected["run"]["id"]
        status, _, restored = self.json_request("GET", f"/api/history/{run_id}")
        self.assertEqual(status, 200)
        self.assertEqual(restored, corrected)
        for extension, expected_type in (("json", "application/json"), ("csv", "text/csv"), ("html", "text/html")):
            with self.subTest(extension=extension):
                status, export_headers, body = self.request("GET", f"/api/history/{run_id}/download?format={extension}")
                self.assertEqual(status, 200)
                self.assertIn(expected_type, export_headers["Content-Type"])
                self.assertIn("attachment", export_headers["Content-Disposition"])
                self.assertTrue(body)

    def test_custom_upload_keeps_unicode_names(self):
        status, _, result = self.json_request("POST", "/api/run", {"mode": "custom", "label": "Recette été 漢字", "files": uploaded_pair()})
        self.assertEqual(status, 200)
        self.assertEqual(result["run"]["label"], "Recette été 漢字")
        self.assertEqual(result["run"]["source_names"]["entree"], "Entrée SAE éç 漢字.txt")
        self.assertTrue(result["report"]["valeurs_executees"])

    def test_static_files_and_head_are_served_without_reference_files(self):
        for path, expected_type in (("/", "text/html"), ("/app.js", "text/javascript"), ("/style.css", "text/css")):
            with self.subTest(path=path):
                status, headers, body = self.request("GET", path)
                self.assertEqual(status, 200)
                self.assertIn(expected_type, headers["Content-Type"])
                self.assertTrue(body)
        status, _, body = self.request("HEAD", "/api/state")
        self.assertEqual(status, 200)
        self.assertEqual(body, b"")
        for path in ("/../profil_tango.json", "/%2e%2e/profil_tango.json", "/donnees_tango/mapping.xlsm", "/api/history/%2e%2e/download?format=json"):
            with self.subTest(path=path):
                status, _, body = self.request("GET", path)
                self.assertEqual(status, 404)
                self.assertNotIn(b"mapping_sha256_initial", body)

    def test_invalid_requests_return_client_errors_instead_of_running(self):
        cases = (
            (400, {"mode": "custom", "files": {}}, None),
            (400, {"mode": []}, None),
            (400, b"not-json", {"Content-Type": "application/json"}),
            (415, b"{}", {"Content-Type": "text/plain"}),
            (403, {"mode": "demo"}, {"Origin": "https://external.invalid"}),
            (403, {"mode": "demo"}, {"Host": f"external.invalid:{self.port}"}),
        )
        for expected_status, payload, headers in cases:
            with self.subTest(status=expected_status, payload=payload):
                status, _, response = self.json_request("POST", "/api/run", payload, headers)
                self.assertEqual(status, expected_status)
                self.assertTrue(response["error"])
        status, _, _ = self.json_request("POST", "/api/run", b"{}", {"Content-Type": "application/json", "Content-Length": "invalid"})
        self.assertEqual(status, 400)

    def test_busy_and_request_size_limit_do_not_start_a_run(self):
        self.app.run_lock.acquire()
        try:
            status, _, response = self.json_request("POST", "/api/run", {"mode": "demo"})
        finally:
            self.app.run_lock.release()
        self.assertEqual(status, 409)
        self.assertIn("en cours", response["error"])
        with patch.object(demo, "MAX_REQUEST_BYTES", 8):
            status, _, response = self.json_request("POST", "/api/run", {"mode": "demo"})
        self.assertEqual(status, 413)
        self.assertTrue(response["error"])


if __name__ == "__main__":
    unittest.main()
