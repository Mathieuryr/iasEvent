"""Traçabilité des règles et exports sur le cas métier fourni."""
import json
import tempfile
import unittest
from pathlib import Path
import v2_reporting as reporting

ROOT = Path(__file__).resolve().parents[1]

class RuleExplanationChecks(unittest.TestCase):
    def test_dictionary_keeps_codes_and_types(self):
        rule = reporting.explain_rule({'row':453,'operation':'pipeline','comment':'Commentaire Excel',
            'parameters':{'etapes':[{'operation':'dictionnaire','valeurs':{'D':'DEBT','C':'CRDT'},'defaut':False}]}})
        self.assertIn('"D" → "DEBT"', rule['steps'][0])
        self.assertIn('false', rule['steps'][1])
        self.assertEqual(rule['comment'], 'Commentaire Excel')

    def test_cut_explains_index_convention(self):
        rule=reporting.explain_rule({'operation':'pipeline','parameters':{'etapes':[{'operation':'decoupage','debut':2,'fin':4}]}})
        self.assertIn('2 inclus → 4 exclu',rule['steps'][0])

    def test_missing_rule_does_not_invent_copy(self):
        self.assertEqual(reporting.explain_rule(None)['title'],'Règle non enregistrée')
        rule=reporting.explain_rule({'operation':'a_definir','parameters':{'raison':'Conversion non validée'}})
        self.assertEqual(rule['steps'],['Conversion non validée'])

    def test_recorded_mapping_is_used_and_exports_escape_comments(self):
        row={'niveau':'valeurs','statut':'OK','code':'VALEUR_CONFORME','ligne_excel':453,
             'source':'amountType','cible':'indicator','detail':'Conforme',
             'visualisation':{'applicable':True,'inputs':[{'path':'amountType','state':'present','value':'D'}],
              'outputs':[{'path':'indicator','state':'present','value':'DEBT'}],'expected':{'state':'known','value':'DEBT'}}}
        report={'controles':[row],'mapping_resolu':[{'row':453,'operation':'pipeline','comment':'<script>unsafe</script>',
             'parameters':{'etapes':[{'operation':'dictionnaire','valeurs':{'D':'DEBT'}}]}}]}
        reporting.decorate_report(report)
        self.assertIn('"D" → "DEBT"', report['v2']['findings'][0]['rule']['steps'][0])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'report.html';reporting.write_html(path,report,{})
            self.assertNotIn('<script>unsafe</script>',path.read_text())
            self.assertIn('&lt;script&gt;unsafe',path.read_text())
            csv=Path(tmp)/'report.csv';reporting.write_csv(csv,report)
            self.assertIn('regle_mapping',csv.read_text())

if __name__=='__main__': unittest.main()
