"""La vue expose les données réelles sans modifier le périmètre des contrôles."""
import json
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import controle_mapping as cm
import controle_tango as ct
import tango_engine as engine
import tango_visualisation as view


def rule(**changes):
    values = dict(row=10, source="source", targets=["target"], operation="copie", parameters={},
                  presence="required", location="body", marked=True, raw_attribute="target", notes=[])
    values.update(changes)
    return SimpleNamespace(**values)


def audit(lines, incoming, outgoing, *, profile=None, headers=None, conflicts=()):
    result = ct.TangoAudit()
    result.conflicting_targets.update(conflicts)
    result.values(lines, incoming, outgoing, headers, profile or {}, {})
    return result.rows


def control(row, attribute, source):
    return rule(row=row, raw_attribute=attribute, source=source, targets=["transaction.issuerControlList"],
                operation="controles_emetteur", parameters={"sources": ["processingInfo.ACResultList"]})


class VisualisationChecks(unittest.TestCase):
    def test_false_zero_and_empty_values_are_visible_with_type(self):
        for value in (False, 0, "", [], {}):
            with self.subTest(value=value):
                row = audit([rule()], {"source": value}, {"target": value})[0]
                self.assertEqual(row["statut"], "OK")
                visual = row["visualisation"]
                self.assertEqual(visual["inputs"], [{"path": "source", "state": "present", "value": value}])
                self.assertEqual(visual["outputs"], [{"path": "target", "state": "present", "value": value}])
                self.assertEqual(visual["expected"], {"state": "known", "value": value})
                self.assertIs(type(visual["outputs"][0]["value"]), type(value))

    def test_absent_null_unidentified_source_does_not_read_output(self):
        class NoRead(dict):
            def get(self, *args):
                raise AssertionError("Sortie hors périmètre")
            def __getitem__(self, key):
                raise AssertionError("Sortie hors périmètre")
        for source, incoming, state in (("source", {}, "absent"), ("source", {"source": None}, "null"), ("", {}, None)):
            with self.subTest(source=source, incoming=incoming), patch.object(engine, "expected") as expected:
                visual = audit([rule(source=source)], incoming, NoRead(target="unrelated"))[0]["visualisation"]
                expected.assert_not_called()
                self.assertFalse(visual["applicable"])
                self.assertEqual(visual["outputs"], [])
                if state:
                    self.assertEqual(visual["inputs"][0]["state"], state)

    def test_missing_output_has_raw_input_and_calculated_expected(self):
        row = audit([rule(operation="pipeline", parameters={"etapes": [{"operation": "dictionnaire", "valeurs": {"D": "DEBT"}}]})],
                    {"source": "D"}, {})[0]
        self.assertEqual(row["code"], "ECART_PRESENCE")
        self.assertEqual(row["attendu"], {"presence": "présente"})
        self.assertEqual(row["visualisation"]["expected"], {"state": "known", "value": "DEBT"})
        self.assertEqual(row["visualisation"]["outputs"], [{"path": "target", "state": "absent"}])

    def test_expected_is_calculated_only_once_for_ordinary_comparison(self):
        original = engine.expected
        with patch.object(engine, "expected", wraps=original) as expected:
            row = audit([rule()], {"source": "A"}, {"target": "B"})[0]
        self.assertEqual(expected.call_count, 1)
        self.assertEqual(row["visualisation"]["inputs"][0]["value"], "A")
        self.assertEqual(row["visualisation"]["outputs"][0]["value"], "B")

    def test_pending_rule_shows_real_values_without_fabricated_expected(self):
        row = audit([rule(operation="a_definir")], {"source": "original"}, {"target": "observed"})[0]
        self.assertEqual(row["statut"], "A_VERIFIER")
        self.assertEqual(row["visualisation"]["expected"], {"state": "pending"})
        self.assertEqual(row["visualisation"]["outputs"][0]["value"], "observed")

    def test_conflicting_sources_do_not_choose_expected_even_with_missing_output(self):
        lines = [rule(), rule(row=11, source="second")]
        with patch.object(engine, "expected") as expected:
            rows = audit(lines, {"source": "A", "second": "B"}, {}, conflicts={"target"})
        expected.assert_not_called()
        self.assertEqual(rows[0]["visualisation"]["expected"]["state"], "pending")

    def test_selected_group_uses_concrete_indexes_and_ignores_output_extras(self):
        lines = [control(10, "code", "processingInfo.ACResultList[].controlName"),
                 control(11, "controlResponseCode", "processingInfo.ACResultList[].resultCode")]
        incoming = {"processingInfo": {"ACResultList": [
            {"controlName": "A_suffix", "resultCode": 1, "unused": "do not show"},
            {"controlName": "B_suffix", "resultCode": 0}]}}
        outgoing = {"transaction": {"issuerControlList": [
            {"code": "OTHER", "responseCode": "extra"},
            {"code": "B", "responseCode": "0", "extra": "do not show"},
            {"code": "A", "responseCode": "1"}]}}
        row = audit(lines, incoming, outgoing)[0]
        self.assertEqual(row["statut"], "OK")
        visual = row["visualisation"]
        self.assertEqual([entry["path"] for entry in visual["outputs"]], [
            "transaction.issuerControlList[2].code", "transaction.issuerControlList[2].responseCode",
            "transaction.issuerControlList[1].code", "transaction.issuerControlList[1].responseCode"])
        self.assertEqual(visual["outputs"][1]["value"], "1")
        self.assertIs(type(visual["inputs"][1]["value"]), int)
        self.assertNotIn("do not show", json.dumps(visual))
        self.assertNotIn("OTHER", json.dumps(visual))

    def test_group_pending_conversion_still_finds_real_amount_by_identity(self):
        line = rule(raw_attribute="usageCurrentValueLimitAmount", source="processingInfo.limitResultList",
                    targets=["card.usageCurrentValueList"], operation="limites")
        incoming = {"currency": "978", "processingInfo": {"limitResultList": [{"limitId": 31, "maxTotalAmt": "200"}]}}
        outgoing = {"card": {"usageCurrentValueList": [
            {"code": "PINT", "limitAmount": {"amount": "unrelated"}},
            {"code": "PDOM", "limitAmount": {"amount": "2.00", "currency": "978"}}]}}
        row = audit([line], incoming, outgoing)[0]
        self.assertEqual(row["statut"], "A_VERIFIER")
        self.assertEqual(row["visualisation"]["outputs"][0]["path"], "card.usageCurrentValueList[1].limitAmount")
        self.assertEqual(row["visualisation"]["expected"]["state"], "pending")

    def test_pending_group_ambiguity_is_explicit_without_arbitrary_pairing(self):
        line = rule(raw_attribute="usageCurrentValueLimitAmount", source="processingInfo.limitResultList",
                    targets=["card.usageCurrentValueList"], operation="limites")
        incoming = {"currency": "978", "processingInfo": {"limitResultList": [{"limitId": 31, "maxTotalAmt": "200"}]}}
        outgoing = {"card": {"usageCurrentValueList": [
            {"code": "PDOM", "limitAmount": {"amount": "1"}},
            {"code": "PDOM", "limitAmount": {"amount": "2"}}]}}
        visual = audit([line], incoming, outgoing)[0]["visualisation"]
        self.assertEqual(visual["outputs"][0]["state"], "unavailable")
        self.assertIn("univoque", visual["note"])

    def test_score_selects_matching_service_and_real_value(self):
        line = rule(operation="score", targets=["riskScoringList"], parameters={"code": "04"})
        row = audit([line], {"source": 0}, {"riskScoringList": [{"serviceId": "OTHER", "serviceData": 99},
                                                                       {"serviceId": "04", "serviceData": 0}]})[0]
        self.assertEqual(row["visualisation"]["outputs"], [{"path": "riskScoringList[1].serviceData", "state": "present", "value": 0}])

    def test_headers_missing_and_case_insensitive_values_are_distinct(self):
        line = rule(location="headers", targets=["eventNature"])
        missing = audit([line], {"source": "A"}, {}, headers=None)[0]["visualisation"]
        present = audit([line], {"source": "A"}, {}, headers={"EVENTNATURE": "A"})[0]["visualisation"]
        self.assertEqual(missing["outputs"][0]["state"], "unavailable")
        self.assertEqual(present["outputs"][0]["value"], "A")

    def test_view_failure_never_changes_audit_result(self):
        with patch.object(view, "build", side_effect=ValueError("display error")):
            row = audit([rule()], {"source": "A"}, {"target": "A"})[0]
        self.assertEqual(row["statut"], "OK")
        self.assertIn("indisponible", row["visualisation"]["note"])

    def test_nested_missing_values_are_serializable(self):
        row = audit([rule()], {"source": {"value": 0, "ignored": cm.MISSING}}, {"target": {"value": 0, "extra": 1}})[0]
        json.dumps(row)
        self.assertEqual(row["visualisation"]["outputs"][0]["value"], {"value": 0})

    def test_array_source_paths_keep_original_indexes(self):
        entries = view.extract_entries({"items": [{"value": None}, {}, {"value": False}]}, "items[].value")
        self.assertEqual([(item["path"], item["state"]) for item in entries], [
            ("items[0].value", "null"), ("items[1].value", "absent"), ("items[2].value", "present")])


if __name__ == "__main__":
    unittest.main()
