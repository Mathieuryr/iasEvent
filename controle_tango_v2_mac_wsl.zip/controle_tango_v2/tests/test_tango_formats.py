import copy
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path

import fastavro
from fastavro.validation import validate

import controle_mapping as cm
import controle_tango as ct
import tango_engine as engine
import tango_formats as fmt


ROOT = Path(__file__).resolve().parents[1]


class AuditTextChecks(unittest.TestCase):
    def catalog(self):
        return {"codes[]": cm.Field(types={"string"}), "items[]": cm.Field(types={"object"})}

    def test_numbers_strings_empty_values_and_arrays(self):
        text = """Audit data:
  1. ISOMTI : number <0100>
  2. identifiant : tg::String <000009>
  3. empty : tg::String <>
  4. codes : array
         codes : occurrence
           codes : tg::String <1503>
         codes : occurrence
           codes : tg::String <0001>
  5. items : array
         items : occurrence
           id : number <31>
         items : occurrence
           id : number <31>
  6. nested : dict
         flag : tg::String <0>
"""
        data, info = fmt.parse_audit_text(text, self.catalog())
        self.assertEqual(data, {"ISOMTI": 100, "identifiant": "000009", "empty": "", "codes": ["1503", "0001"],
                                "items": [{"id": 31}, {"id": 31}], "nested": {"flag": "0"}})
        self.assertEqual(info["elements"]["occurrences"], 4)

    def test_strings_are_only_data(self):
        value = '__import__("os").system("false") <test>'
        data, _ = fmt.parse_audit_text(f"Audit data:\n 1. value : tg::String <{value}>\n", {})
        self.assertEqual(data["value"], value)

    def test_rejects_duplicate_fields_unread_lines_and_broken_structure(self):
        bad = [
            "Audit data:\n 1. id : number <1>\n 2. id : number <2>",
            "Audit data:\n 1. id : number <1>\nunread data",
            "Audit data:\n 1. id : number <1>\n 3. x : number <2>",
            "Audit data:\n 1. items : array\n   wrong : occurrence",
            "Audit data:\n 1. id : number <1.5>",
            "Audit data:\n 1. obj : dict\n    a : number <1>\n     b : number <2>",
            "Audit data:\n 1. codes : array\n    codes : occurrence\n      wrong : tg::String <X>",
        ]
        for text in bad:
            with self.subTest(text=text), self.assertRaises(cm.ConfigurationError):
                fmt.parse_audit_text(text, self.catalog())

    def test_unknown_fields_remain_visible(self):
        value = {"known": {"extra": "value"}, "unknown": {"anything": 42}}
        paths = fmt.unknown_input_paths(value, {"known": cm.Field(types={"object"})})
        self.assertEqual(paths, ["known.extra", "unknown"])
        self.assertEqual(value["unknown"]["anything"], 42)


class OutputWrapperChecks(unittest.TestCase):
    def schema(self):
        document = {"components": {"schemas": {
            "IssAuthorFullCard": {"type": "object", "properties": {"accountNature": {"type": "string", "enum": ["DEAC"]}}},
            "IssAuthorFullAmountAndCurrency": {"type": "object", "properties": {"amount": {"type": "string"}}},
        }}}
        selected = {"type": "object", "properties": {
            "card": {"$ref": "#/components/schemas/IssAuthorFullCard"},
            "amount": {"$ref": "#/components/schemas/IssAuthorFullAmountAndCurrency"},
            "flag": {"type": "boolean"},
            "names": {"type": "array", "items": {"type": "string"}},
            "legitimate": {"type": "object", "properties": {"string": {"type": "string"}}},
        }}
        return document, selected

    def test_known_wrappers_keep_values_and_empty_objects(self):
        document, selected = self.schema()
        value = {"card": {"IssAuthorFullCard": {"accountNature": {"CardAccountNature": "DEAC"}}},
                 "amount": {"CashAmount": {}}, "flag": {"boolean": False}, "names": {"array": [{"string": "000"}]}}
        before = copy.deepcopy(value)
        decoded, info = fmt.normalize_output(value, document, selected)
        self.assertEqual(decoded, {"card": {"accountNature": "DEAC"}, "amount": {}, "flag": False, "names": ["000"]})
        self.assertEqual(info["enveloppes_retirees"], 6)
        self.assertEqual(value, before)

    def test_unknown_or_ambiguous_wrappers_are_not_discarded(self):
        document, selected = self.schema()
        value = {"card": {"UnknownRecord": {}}, "flag": {"boolean": False, "other": 1}, "unknown": {"string": "X"}}
        decoded, info = fmt.normalize_output(value, document, selected)
        self.assertEqual(decoded, value)
        self.assertEqual(info["enveloppes_retirees"], 0)

    def test_legitimate_single_property_and_explicit_raw_mode_are_preserved(self):
        document, selected = self.schema()
        value = {"legitimate": {"string": "X"}}
        self.assertEqual(fmt.normalize_output(value, document, selected)[0], value)
        raw = {"card": {"IssAuthorFullCard": {}}}
        self.assertEqual(fmt.normalize_output(raw, document, selected, "json")[0], raw)


class SuppliedMessagesChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile = cm.load_document(ROOT / "profil_tango.json")
        names = {}
        cls.schema = fastavro.parse_schema(cm.load_document(ROOT / "donnees_tango/avro.json"), named_schemas=names)
        cls.source, _ = cm.avro_catalog(cls.schema, names)
        cls.document = cm.load_document(ROOT / "donnees_tango/swagger.yaml")
        cls.validator, cls.selected = cm.make_output_validator(cls.document, cls.profile["schema_sortie"])

    def decode(self):
        incoming, i = fmt.read_input(ROOT / "examples_reels/audit_KAFKA.txt", self.schema, self.source)
        outgoing, o = fmt.normalize_output(cm.load_document(ROOT / "examples_reels/Kafka_audit_sortie.txt"), self.document, self.selected)
        return incoming, outgoing, i, o

    def test_full_export_is_read_and_identifiers_match(self):
        incoming, outgoing, i, o = self.decode()
        self.assertTrue(validate(incoming, self.schema, strict=True))
        self.assertEqual(i["lignes_lues"], 391)
        self.assertEqual(i["champs_racine"], 43)
        self.assertEqual(i["elements"]["occurrences"], 58)
        self.assertEqual(o["enveloppes_retirees"], 268)
        self.assertEqual(incoming["ISOMTI"], 100)
        self.assertEqual(incoming["context"]["msgReasons"], [{"msgReasons": "1503"}])
        self.assertEqual(incoming["transUId"], outgoing["transaction"]["identification"]["endToEndTransId"])
        controls = incoming["processingInfo"]
        self.assertEqual(len(controls["ACResultList"]) + len(controls["IASTechInfo"]["ACResultList"]),
                         len(outgoing["transaction"]["issuerControlList"]))
        self.assertEqual(outgoing["transaction"]["totalAmount"]["amount"], "2020")
        self.assertFalse(fmt.unknown_input_paths(incoming, self.source))

    def test_actual_format_defect_is_not_hidden_by_decoding(self):
        _, outgoing, _, _ = self.decode()
        errors = list(self.validator.iter_errors(outgoing))
        self.assertEqual(len(errors), 1)
        self.assertEqual(list(errors[0].absolute_path), ["transaction", "eMV", "terminalTransactionDate"])
        self.assertEqual(outgoing["transaction"]["eMV"]["terminalTransactionDate"], "140801")

    def audit(self, outgoing_path=None):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "report.json"
            with redirect_stdout(StringIO()):
                code = ct.main(["--entree", str(ROOT / "examples_reels/audit_KAFKA.txt"),
                                "--sortie", str(outgoing_path or ROOT / "examples_reels/Kafka_audit_sortie.txt"), "--rapport", str(path)])
            self.assertEqual(code, 1)
            return json.loads(path.read_text())

    def test_audit_reports_observed_defects_and_keeps_ambiguities_open(self):
        data = self.audit()
        values = [r for r in data["controles"] if r["niveau"] == "valeurs"]
        errors = [r for r in values if r["statut"] == "ERREUR"]
        self.assertEqual(len(errors), 16)
        self.assertEqual({r["ligne_excel"] for r in errors}, {None, 5, 19, 52, 65, 66, 104, 121, 128, 129, 160, 196, 374, 375, 461})
        for row in [93, 317, 327, 484]:
            self.assertTrue(any(r["ligne_excel"] == row and r["statut"] == "OK" for r in values))
        for row in [441, 442, 443]:
            self.assertTrue(any(r["ligne_excel"] == row and r["statut"] == "A_VERIFIER" for r in values))

    def test_restoring_event_nature_removes_that_error(self):
        outgoing = cm.load_document(ROOT / "examples_reels/Kafka_audit_sortie.txt")
        outgoing["eventProcessingData"]["IssAuthorFullEventProcessingData"]["eventNature"] = {"string": "IAS_ONLINE_AUTH_AUTHORISATION"}
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "corrected.json"
            path.write_text(json.dumps(outgoing))
            data = self.audit(path)
        self.assertEqual(data["compteurs_par_niveau"]["valeurs"]["ERREUR"], 15)
        self.assertTrue(any(r["ligne_excel"] == 5 and r["niveau"] == "valeurs" and r["statut"] == "OK" for r in data["controles"]))

    def test_epoch_ms_conversion_needs_an_explicit_profile(self):
        from types import SimpleNamespace
        line = SimpleNamespace(operation="date_a_confirmer", parameters={}, source="processingInfo.startDateTime", targets=[], presence="optionnal")
        incoming = {"processingInfo": {"startDateTime": "1792594881946"}}
        with self.assertRaises(engine.Pending):
            engine.expected(line, incoming, self.profile, {})
        profile = copy.deepcopy(self.profile)
        profile["formats_dates"][line.source] = {"entree": "epoch-ms", "sortie": "iso-utc-ms"}
        self.assertEqual(engine.expected(line, incoming, profile, {}), "2026-10-21T15:01:21.946Z")
        incoming["processingInfo"]["startDateTime"] = "-1"
        self.assertEqual(engine.expected(line, incoming, profile, {}), "1969-12-31T23:59:59.999Z")


if __name__ == "__main__":
    unittest.main()
