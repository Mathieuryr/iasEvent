"""Régressions V2 : sélection des sous-champs et occurrences invalides."""
import copy
import unittest
from pathlib import Path

import fastavro

import controle_mapping as cm
import controle_tango as ct
import tango_engine as engine
import tango_mapping as tm


ROOT = Path(__file__).resolve().parents[1]


class SelectedGroupChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile = cm.load_document(ROOT / "profil_tango.json")
        names = {}
        schema = fastavro.parse_schema(cm.load_document(ROOT / "donnees_tango/avro.json"), named_schemas=names)
        source, _ = cm.avro_catalog(schema, names)
        swagger = cm.load_document(ROOT / "donnees_tango/swagger.yaml")
        target, _ = cm.swagger_catalog(swagger, cm.pointer(swagger, cls.profile["schema_sortie"]))
        lines, _ = tm.import_mapping(ROOT / "donnees_tango/mapping.xlsm", source, target)
        ct.configure(lines, cls.profile, source, target)
        cls.byrow = {line.row: line for line in lines}

    def prepared(self, *rows):
        return engine.prepare_selected_lines([self.byrow[row] for row in rows])

    def compare(self, line, incoming, items, *, profile=None):
        body = {"transaction": {"issuerControlList": items}} if line.operation == "controles_emetteur" else {"card": {"usageCurrentValueList": items}}
        expected = engine.expected(line, incoming, profile or self.profile, {})
        actual = engine.observed(line, body, None)
        return expected, engine.diff(expected, actual, line)

    def test_only_selected_code_does_not_require_response_code(self):
        line = self.prepared(484)[0]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL_SUFFIX"}]}}
        expected, errors = self.compare(line, incoming, [{"code": "CTRL", "responseCode": "unselected"}])
        self.assertEqual(expected, [{"code": "CTRL"}])
        self.assertEqual(errors, [])

    def test_only_response_does_not_require_name(self):
        line = self.prepared(486)[0]
        incoming = {"processingInfo": {"ACResultList": [{"resultCode": 0}]}}
        expected, errors = self.compare(line, incoming, [{"responseCode": "0", "controlCode": {"ignored": True}}])
        self.assertEqual(expected, [{"responseCode": "0"}])
        self.assertEqual(errors, [])

    def test_each_source_list_has_its_own_selection(self):
        line = self.prepared(484, 503)[0]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL"}],
                                        "IASTechInfo": {"ACResultList": [{"resultCode": 7}]}}}
        expected, errors = self.compare(line, incoming, [{"responseCode": "7"}, {"code": "CTRL"}])
        self.assertEqual(expected, [{"code": "CTRL"}, {"responseCode": "7"}])
        self.assertEqual(errors, [])

    def test_matching_reassigns_candidates_instead_of_greedy_first_match(self):
        line = self.prepared(484, 503)[0]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL"}],
                                        "IASTechInfo": {"ACResultList": [{"resultCode": 0}]}}}
        _, errors = self.compare(line, incoming, [{"code": "CTRL", "responseCode": "0"},
                                                 {"code": "CTRL", "responseCode": "1"}])
        self.assertEqual(errors, [])

    def test_unselected_source_occurrences_are_not_compared(self):
        line = self.prepared(484)[0]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL"}],
                                        "IASTechInfo": {"ACResultList": [None]}}}
        _, errors = self.compare(line, incoming, [{"code": "OTHER"}, {"code": "CTRL"}])
        self.assertEqual(errors, [])

    def test_duplicate_selected_occurrences_are_not_deduplicated(self):
        line = self.prepared(484)[0]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL"}, {"controlName": "CTRL"}]}}
        expected, errors = self.compare(line, incoming, [{"code": "CTRL"}])
        self.assertEqual(len(expected), 2)
        self.assertTrue(errors)
        self.assertIn("occurrence", errors[0]["motif"])

    def test_all_selected_sources_require_exact_occurrence_count(self):
        line = self.prepared(484, 501)[0]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "FIRST"}],
                                        "IASTechInfo": {"ACResultList": [{"controlName": "SECOND"}]}}}
        _, errors = self.compare(line, incoming, [{"code": "SECOND"}, {"code": "FIRST"}, {"code": "EXTRA"}])
        self.assertTrue(any("nombre d'occurrences" in error["motif"] for error in errors))

    def test_legacy_direct_call_still_calculates_complete_control(self):
        line = self.byrow[484]
        incoming = {"processingInfo": {"ACResultList": [{"controlName": "CTRL_X", "resultCode": 0}]}}
        self.assertEqual(engine.expected(line, incoming, self.profile, {}),
                         [{"code": "CTRL", "controlCode": "CTRL_X", "responseCode": "0"}])

    def test_limit_code_does_not_require_category_or_money_configuration(self):
        line = self.prepared(461)[0]
        incoming = {"processingInfo": {"limitResultList": [{"limitId": 31, "maxTotalAmt": "unselected"}]}}
        expected, errors = self.compare(line, incoming, [{"code": "PDOM", "category": "unselected"}])
        self.assertEqual(expected, [{"code": "PDOM"}])
        self.assertEqual(errors, [])

    def test_limit_category_does_not_require_monetary_values(self):
        line = self.prepared(481)[0]
        incoming = {"processingInfo": {"limitResultList": [{"limitId": 31, "limittype": 20}]}}
        expected, errors = self.compare(line, incoming, [{"category": "NUBR", "code": "unselected"}])
        self.assertEqual(expected, [{"category": "NUBR"}])
        self.assertEqual(errors, [])

    def test_selected_limit_amount_accepts_equivalent_decimal_formats(self):
        line = self.prepared(469)[0]
        profile = copy.deepcopy(self.profile)
        profile["monnaie"]["unites_par_source"] = {"processingInfo.limitResultList[].maxTotalAmt": "majeure"}
        incoming = {"currency": "978", "processingInfo": {"limitResultList": [{"limitId": 31, "maxTotalAmt": "2"}]}}
        expected, errors = self.compare(line, incoming, [{"limitAmount": {"amount": "2.00", "currency": "978"},
                                                         "amount": {"amount": "unselected"}}], profile=profile)
        self.assertEqual(expected, [{"limitAmount": {"amount": "2", "currency": "978"}}])
        self.assertEqual(errors, [])

    def test_selected_limit_number_is_still_compared(self):
        line = self.prepared(468)[0]
        incoming = {"processingInfo": {"limitResultList": [{"limitId": 31, "maxTotalNbr": 4}]}}
        _, errors = self.compare(line, incoming, [{"limitNumber": "5"}])
        self.assertTrue(any(error["chemin"].endswith(".limitNumber") for error in errors))

    def test_preparation_does_not_mutate_original_rules(self):
        original = copy.deepcopy(self.byrow[484].parameters)
        selected = self.prepared(484)[0]
        self.assertIn("_selection", selected.parameters)
        self.assertEqual(self.byrow[484].parameters, original)

    def test_invalid_input_occurrences_report_their_path(self):
        cases = [
            (484, {"processingInfo": {"ACResultList": [None]}}, "processingInfo.ACResultList[0]"),
            (461, {"processingInfo": {"limitResultList": [None]}}, "processingInfo.limitResultList[0]"),
            (466, {"processingInfo": {"limitResultList": [None]}}, "processingInfo.limitResultList[0]"),
            (142, {"additionalAmtList": [None]}, "additionalAmtList[0]"),
        ]
        for row, message, path in cases:
            with self.subTest(row=row), self.assertRaisesRegex(ValueError, path.replace("[", "\\[").replace("]", "\\]")):
                engine.expected(self.byrow[row], message, self.profile, {})

    def test_invalid_output_occurrences_report_their_path(self):
        with self.assertRaisesRegex(ValueError, r"transaction.issuerControlList\[0\]"):
            engine.observed(self.byrow[484], {"transaction": {"issuerControlList": [None]}}, None)
        with self.assertRaisesRegex(ValueError, r"riskScoringList\[0\]"):
            engine.observed(self.byrow[358], {"riskScoringList": [None]}, None)


if __name__ == "__main__":
    unittest.main()
