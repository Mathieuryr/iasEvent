"""Règle utilisateur : seule l'entrée Kafka décide de la présence en sortie."""
import copy
import unittest
from types import SimpleNamespace

import controle_tango as ct
import tango_engine as engine
import tango_presence as presence


def line(**changes):
    values=dict(row=10,source='source',targets=['target'],operation='copie',parameters={},presence='required',location='body',marked=True,raw_attribute='target',notes=[])
    values.update(changes)
    return SimpleNamespace(**values)


class PresenceKafkaChecks(unittest.TestCase):
    def audit(self,rule,incoming,outgoing,headers=None):
        audit=ct.TangoAudit()
        audit.values([rule],incoming,outgoing,headers,{'decisions':{'event_nature_source':'ISOMTI'},'politique_presence':'entree_kafka_uniquement'},{})
        return audit.rows

    def test_present_on_both_sides_still_compares_the_value(self):
        self.assertEqual(self.audit(line(),{'source':'A'},{'target':'A'})[0]['statut'],'OK')
        rows=self.audit(line(),{'source':'A'},{'target':'B'})
        self.assertEqual(rows[0]['code'],'ECART_MAPPING')

    def test_present_only_in_input_is_a_presence_error(self):
        for actual in [{},{'target':None}]:
            with self.subTest(actual=actual):
                rows=self.audit(line(),{'source':'A'},actual)
                self.assertEqual(rows[0]['code'],'ECART_PRESENCE')

    def test_absent_only_in_input_requires_omission_even_if_output_is_empty(self):
        for incoming in [{},{'source':None}]:
            for value in ['unexpected',None,{},[],0,False,'']:
                with self.subTest(incoming=incoming,value=value):
                    rows=self.audit(line(),incoming,{'target':value})
                    self.assertEqual(rows[0]['code'],'ECART_PRESENCE')

    def test_absent_both_sides_is_conformant_despite_required_excel_label(self):
        for incoming in [{},{'source':None}]:
            rows=self.audit(line(),incoming,{})
            self.assertEqual(rows[0]['code'],'ABSENCE_CONFORME')
            self.assertEqual(rows[0]['statut'],'NON_APPLICABLE')

    def test_zero_false_and_empty_values_are_not_missing(self):
        for value in [0,False,'',[],{}]:
            with self.subTest(value=value):
                self.assertEqual(self.audit(line(),{'source':value},{'target':value})[0]['statut'],'OK')
                self.assertEqual(self.audit(line(),{'source':value},{})[0]['code'],'ECART_PRESENCE')

    def test_pending_transformation_does_not_hide_missing_target(self):
        rule=line(operation='date_a_confirmer')
        self.assertEqual(self.audit(rule,{'source':'20261026'},{})[0]['code'],'ECART_PRESENCE')
        rows=self.audit(rule,{'source':'20261026'},{'target':'2026-10-26'})
        self.assertEqual(rows[0]['statut'],'A_VERIFIER')
        self.assertIn('Présence conforme',rows[0]['detail'])

    def test_no_transaction_type_filter_is_applied_to_presence(self):
        rule=line(operation='pipeline',parameters={'condition':{'source':'type','egale':'D'},'etapes':[]})
        for typology in ['D','C',None]:
            incoming={'source':'A','type':typology,'ISOMTI':400}
            self.assertEqual(self.audit(rule,incoming,{})[0]['code'],'ECART_PRESENCE')
        rows=self.audit(rule,{'source':'A','type':'C'},{'target':'A'})
        self.assertEqual(rows[0]['code'],'REGLE_VALEUR_A_REVOIR')

    def test_uncaptured_headers_are_unknown_instead_of_declared_missing(self):
        rule=line(location='headers',targets=['X-Test'])
        self.assertEqual(self.audit(rule,{'source':'A'},{})[0]['statut'],'A_VERIFIER')
        self.assertEqual(self.audit(rule,{'source':'A'},{},headers={})[0]['code'],'ECART_PRESENCE')

    def test_unknown_kafka_source_is_not_treated_as_proven_absence(self):
        rule=line(source='',operation='contexte')
        self.assertEqual(self.audit(rule,{}, {'target':'enriched'})[0]['statut'],'A_VERIFIER')

    def test_score_presence_is_checked_for_its_service_id(self):
        rule=line(operation='score',targets=['riskScoringList'],parameters={'code':'04'})
        self.assertEqual(self.audit(rule,{'source':'20'},{'riskScoringList':[{'serviceId':'04'}]})[0]['code'],'ECART_PRESENCE')
        self.assertEqual(self.audit(rule,{}, {'riskScoringList':[{'serviceId':'03','serviceData':'other'}]})[0]['code'],'ABSENCE_CONFORME')

    def test_minimum_amount_is_not_inferred_from_unrelated_limit_occurrences(self):
        rule=line(operation='minimum_autorisable',source='limits')
        expectation=presence.expected_presence(rule,{'limits':[{'limitId':31,'maxTotalAmt':20}]},{})
        self.assertFalse(expectation.required)


class GroupPresenceChecks(unittest.TestCase):
    def control(self,row,attribute,source):
        return line(row=row,raw_attribute=attribute,source=source,targets=['transaction.issuerControlList'],operation='controles_emetteur',parameters={'sources':['processingInfo.ACResultList','processingInfo.IASTechInfo.ACResultList']})

    def compare(self,rules,incoming,items):
        prepared=engine.prepare_selected_lines(rules)
        return presence.check(prepared[0],incoming,{'transaction':{'issuerControlList':items}},None,{})[1]

    def test_missing_subfield_is_not_hidden_by_an_existing_group(self):
        rules=[self.control(484,'code','processingInfo.ACResultList[].controlName'),self.control(486,'controlResponseCode','processingInfo.ACResultList[].resultCode')]
        incoming={'processingInfo':{'ACResultList':[{'controlName':'CTRL','resultCode':0}]}}
        issues=self.compare(rules,incoming,[{'code':'CTRL'}])
        self.assertTrue(any(item['chemin'].endswith('responseCode') for item in issues))

    def test_absent_subfield_must_not_be_emitted_even_with_other_present_fields(self):
        rules=[self.control(484,'code','processingInfo.ACResultList[].controlName'),self.control(486,'controlResponseCode','processingInfo.ACResultList[].resultCode')]
        incoming={'processingInfo':{'ACResultList':[{'controlName':'CTRL','resultCode':None}]}}
        self.assertFalse(self.compare(rules,incoming,[{'code':'CTRL'}]))
        self.assertTrue(self.compare(rules,incoming,[{'code':'CTRL','responseCode':'0'}]))

    def test_duplicate_occurrences_produce_distinct_missing_paths(self):
        rules=[self.control(484,'code','processingInfo.ACResultList[].controlName'),self.control(486,'controlResponseCode','processingInfo.ACResultList[].resultCode')]
        incoming={'processingInfo':{'ACResultList':[{'controlName':'A','resultCode':0},{'controlName':'B','resultCode':0}]}}
        issues=self.compare(rules,incoming,[{'code':'A'},{'code':'B'}])
        paths={item['chemin'] for item in issues}
        self.assertIn('transaction.issuerControlList[0].responseCode',paths)
        self.assertIn('transaction.issuerControlList[1].responseCode',paths)

    def test_unselected_existing_source_is_not_mistaken_for_an_extra_selected_value(self):
        rules=[self.control(484,'code','processingInfo.ACResultList[].controlName')]
        incoming={'processingInfo':{'ACResultList':None,'IASTechInfo':{'ACResultList':[{'controlName':'OTHER'}]}}}
        self.assertFalse(self.compare(rules,incoming,[{'code':'OTHER'}]))
        self.assertTrue(self.compare(rules,{'processingInfo':{}},[{'code':'UNEXPECTED'}]))


if __name__=='__main__':unittest.main()
