import copy
import csv
import json
import tempfile
import unittest
from pathlib import Path

import v2_reporting as reporting


class ComparisonReportingTests(unittest.TestCase):
    def pair(self, status="OK"):
        return {
            "niveau": "valeurs", "statut": status, "code": "VALEUR_CONFORME" if status == "OK" else "ECART_MAPPING",
            "ligne_excel": 453, "source": "processingInfo.amountType", "cible": "transaction.context.debitCreditIndicator",
            "detail": "Comparaison du débit/crédit.",
            "visualisation": {
                "applicable": True,
                "inputs": [{"path": "processingInfo.amountType", "state": "present", "value": "D"}],
                "outputs": [{"path": "transaction.context.debitCreditIndicator", "state": "present", "value": "DEBT"}],
                "expected": {"state": "known", "value": "DEBT"},
            },
        }

    def report(self, rows):
        return reporting.decorate_report({
            "decisions": {"perimetre_comparaison": "sources_presentes_uniquement"},
            "couverture": {"lignes_actives": len(rows)}, "controles": rows,
        })

    def html(self, report):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rapport.html"
            reporting.write_html(path, report, {"label": "Test des correspondances"})
            return path.read_text()

    def csv(self, report):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rapport.csv"
            reporting.write_csv(path, report)
            with path.open(encoding="utf-8-sig", newline="") as stream:
                return list(csv.DictReader(stream, delimiter=";"))

    def test_projection_keeps_input_actual_expected_distinct_and_counts_unchanged(self):
        row = self.pair("ERREUR")
        row.update(attendu="présent", obtenu="absent")
        row["visualisation"]["outputs"] = [{"path": row["cible"], "state": "absent"}]
        legacy = copy.deepcopy(row)
        legacy.pop("visualisation")
        report = self.report([row])
        item = report["v2"]["findings"][0]
        self.assertEqual(item["comparison"]["inputs"][0]["value"], "D")
        self.assertEqual(item["comparison"]["expected"]["value"], "DEBT")
        self.assertEqual(item["comparison"]["outputs"][0]["state"], "absent")
        self.assertEqual(item["expected"], "présent")
        self.assertEqual(item["actual"], "absent")
        self.assertEqual(report["v2"]["summary"], self.report([legacy])["v2"]["summary"])

    def test_html_includes_conforming_pairs_and_keeps_schema_findings_separate(self):
        schema = {"niveau": "valeurs", "statut": "ERREUR", "code": "SORTIE_SWAGGER_INVALIDE", "cible": "schemaOnly", "detail": "Contrat invalide"}
        content = self.html(self.report([self.pair(), schema]))
        pair_section, other_section = content.split("<h2>Autres constats à examiner</h2>")
        self.assertIn("Entrée Kafka · valeur source", pair_section)
        self.assertIn("Sortie SID · valeur observée", pair_section)
        self.assertIn("processingInfo.amountType", pair_section)
        self.assertIn("&quot;D&quot;", pair_section)
        self.assertIn("&quot;DEBT&quot;", pair_section)
        self.assertIn("Valeur attendue selon le mapping", pair_section)
        self.assertNotIn("schemaOnly", pair_section)
        self.assertIn("schemaOnly", other_section)

    def test_missing_output_and_pending_expected_are_explicit(self):
        row = self.pair("A_VERIFIER")
        row["visualisation"]["outputs"][0] = {"path": row["cible"], "state": "absent"}
        row["visualisation"]["expected"] = {"state": "pending"}
        content = self.html(self.report([row]))
        self.assertIn("Champ absent", content)
        self.assertIn("aucune valeur attendue déterminée", content)
        self.assertNotIn("&quot;DEBT&quot;", content)

    def test_value_types_and_collection_paths_survive_exports(self):
        row = self.pair()
        values = [0, False, "", None, [], {}]
        entries = [{"path": f"items[{i}].value", "state": "null" if value is None else "present", "value": value} for i, value in enumerate(values)]
        row["visualisation"]["inputs"] = entries
        row["visualisation"]["outputs"] = list(reversed(entries))
        row["visualisation"]["note"] = "Les chemins désignent les occurrences lues ; l'ordre ne prouve pas l'appariement."
        report = self.report([row])
        csv_row = self.csv(report)[0]
        self.assertEqual(json.loads(csv_row["entree_kafka"]), entries)
        self.assertEqual(json.loads(csv_row["sortie_sid"]), list(reversed(entries)))
        self.assertEqual(json.loads(csv_row["attendu_mapping"]), {"state": "known", "value": "DEBT"})
        content = self.html(report)
        for text in ("items[0].value", "items[5].value", "false", "null", "&quot;&quot;"):
            self.assertIn(text, content)

    def test_ignored_source_does_not_export_any_output(self):
        row = self.pair("NON_APPLICABLE")
        row["visualisation"].update(applicable=False, inputs=[{"path": row["source"], "state": "null", "value": None}], outputs=[], expected={"state": "unavailable"})
        report = self.report([row])
        csv_row = self.csv(report)[0]
        self.assertEqual(csv_row["sortie_sid"], "")
        self.assertEqual(csv_row["attendu_mapping"], "")
        self.assertNotIn("processingInfo.amountType", self.html(report))

    def test_legacy_report_requests_rerun_without_inventing_input(self):
        row = self.pair("ERREUR")
        row.pop("visualisation")
        row.update(attendu="EXPECTED-ONLY", obtenu="ACTUAL-DIAGNOSTIC")
        report = self.report([row])
        self.assertNotIn("comparison", report["v2"]["findings"][0])
        csv_row = self.csv(report)[0]
        self.assertEqual(csv_row["entree_kafka"], "")
        self.assertEqual(csv_row["sortie_sid"], "")
        self.assertIn("Relancer", csv_row["note_visualisation"])
        content = self.html(report)
        self.assertIn("EXPECTED-ONLY", content)
        self.assertIn("ACTUAL-DIAGNOSTIC", content)
        self.assertIn("Relancer le contrôle", content)

    def test_values_paths_notes_and_diagnostics_are_escaped(self):
        row = self.pair("ERREUR")
        row["source"] = "=FORMULA()"
        row["visualisation"]["inputs"][0].update(path="<script>path</script>", value="</pre><script>value</script>")
        row["visualisation"]["outputs"][0]["value"] = "<img src=x onerror=alert(1)>"
        row["visualisation"]["note"] = "<script>note</script>"
        row["visualisation"]["expected"]["value"] = "<script>expected</script>"
        report = self.report([row])
        content = self.html(report)
        self.assertNotIn("<script>", content)
        self.assertNotIn("<img", content)
        self.assertIn("&lt;script&gt;value&lt;/script&gt;", content)
        self.assertIn("&lt;script&gt;note&lt;/script&gt;", content)
        self.assertTrue(self.csv(report)[0]["source"].startswith("'="))


if __name__ == "__main__":
    unittest.main()
