"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const state = {busy: false, mode: "demo", history: [], current: null, findings: [], selected: null, status: "attention", category: "all", search: "", available: false};
  const categoryNames = {mapping: "Mapping", schema: "Schéma", reference: "Références", decision: "À préciser", preparation: "Lecture"};
  const statusNames = {ERREUR: "Écart", ERROR: "Écart", A_VERIFIER: "À préciser", WARNING: "À préciser", PENDING: "À préciser", OK: "Conforme", INFO: "Info", NON_APPLICABLE: "Sans objet", "NOT-APPLICABLE": "Sans objet"};
  const severityKey = (value) => String(value || "INFO").toUpperCase();
  const findingStatus = (finding) => severityKey(finding.status || finding.severity);
  const isError = (f) => ["ERREUR", "ERROR"].includes(findingStatus(f));
  const isPending = (f) => ["A_VERIFIER", "WARNING", "PENDING"].includes(findingStatus(f));
  const attention = (f) => isError(f) || isPending(f);
  const symbol = (name) => {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", `#i-${name}`);
    svg.append(use);
    svg.setAttribute("aria-hidden", "true");
    return svg;
  };
  const numeric = (value) => typeof value === "number" && Number.isFinite(value) ? value.toLocaleString("fr-FR") : "—";
  const has = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
  const valueText = (value) => {
    if (value === undefined) return "Non renseignée dans ce constat";
    if (value && typeof value === "object" && value.absent === true && Object.keys(value).length === 1) return "Champ absent";
    return JSON.stringify(value, null, 2);
  };
  const dateText = (value) => {
    if (!value) return "Date non renseignée";
    const date = new Date(value);
    return Number.isNaN(date.valueOf()) ? String(value) : new Intl.DateTimeFormat("fr-FR", {day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit"}).format(date);
  };

  async function api(path, options = {}) {
    let response;
    try { response = await fetch(path, {...options, headers: {"Content-Type": "application/json", ...(options.headers || {})}}); }
    catch (_) { throw new Error("Le service local ne répond pas. Vérifiez que le lanceur de la V2 est toujours ouvert, puis réessayez."); }
    let data;
    try { data = await response.json(); }
    catch (_) { throw new Error("Le service local a renvoyé une réponse illisible. Vérifiez la fenêtre du lanceur."); }
    if (!response.ok) {
      const message = response.status === 409 ? "Un autre contrôle est déjà en cours. Attendez sa fin avant de relancer." : (data.detail || data.error || `Le contrôle n’a pas abouti (${response.status}).`);
      throw new Error(typeof message === "string" ? message : JSON.stringify(message));
    }
    return data;
  }

  function showNotice(message, title = "Le contrôle n’a pas pu être terminé") {
    $("notice-title").textContent = title;
    $("notice-message").textContent = message;
    $("notice").hidden = false;
    $("notice").scrollIntoView({behavior: "smooth", block: "nearest"});
  }

  function setBusy(busy, title = "Contrôle en cours…") {
    state.busy = busy;
    $("progress-title").textContent = title;
    $("progress-panel").hidden = !busy;
    ["run-demo", "run-corrected", "empty-run-demo"].forEach((id) => {$(id).disabled = busy || !state.available;});
    $("run-custom").disabled = busy;
    $("run-batch").disabled = busy;
    document.querySelectorAll("input[type=file], #run-label, #reset-references").forEach((el) => {el.disabled = busy;});
    document.querySelectorAll(".history-entry").forEach((el) => {el.disabled = busy;});
    $("workspace").setAttribute("aria-busy", String(busy));
  }

  function setMode(mode) {
    state.mode = mode;
    for (const item of ["demo", "custom", "batch"]) {
      const active = mode === item;
      $("mode-" + item).classList.toggle("active", active);
      $("mode-" + item).setAttribute("aria-selected", String(active));
      $(item + "-panel").hidden = !active;
    }
  }

  async function filePayload(file) {
    // FileReader produit directement du base64 et préserve les fichiers binaires Excel/Avro.
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({name: file.name, content_base64: String(reader.result).split(",", 2)[1]});
      reader.onerror = () => reject(new Error(`Impossible de lire le fichier « ${file.name} ».`));
      reader.readAsDataURL(file);
    });
  }

  async function launch(mode) {
    if (state.busy) return;
    $("notice").hidden = true;
    let request = {mode};
    if (mode === "batch" && !$("batch-panel").reportValidity()) return;
    if (mode === "custom") {
      if (!$("custom-panel").reportValidity()) return;
      request.label = $("run-label").value.trim();
      request.files = {};
    }
    setBusy(true, mode === "demo-corrected" ? "Contrôle de la copie avec eventNature renseigné…" : "Comparaison des messages en cours…");
    try {
      if (mode === "batch") {
        request.label = $("batch-label").value.trim();
        request.files = {entrees: [], sorties: []};
        for (const file of $("batch-entrees").files) request.files.entrees.push(await filePayload(file));
        for (const file of $("batch-sorties").files) request.files.sorties.push(await filePayload(file));
        for (const key of ["mapping", "avro", "swagger"]) {const file = $("batch-" + key).files?.[0]; if (file) request.files[key] = await filePayload(file);}
      }
      if (mode === "custom") {
        for (const input of document.querySelectorAll("input[data-file-key]")) {
          if (input.files && input.files[0]) request.files[input.dataset.fileKey] = await filePayload(input.files[0]);
        }
      }
      const result = await api("/api/run", {method: "POST", body: JSON.stringify(request)});
      renderResult(result);
      await refreshState(true);
      $("results").scrollIntoView({behavior: "smooth", block: "start"});
    } catch (error) {showNotice(error.message);}
    finally {setBusy(false);}
  }

  let remoteBusyTimer;
  async function refreshState(silent = false) {
    try {
      const data = await api("/api/state");
      state.available = data.demo?.available !== false;
      state.history = Array.isArray(data.history) ? data.history : [];
      $("connection-status").classList.remove("offline");
      $("connection-status").replaceChildren(document.createElement("span"), document.createTextNode("Exécution locale"));
      renderHistory();
      setBusy(Boolean(data.busy));
      clearTimeout(remoteBusyTimer);
      if (data.busy) remoteBusyTimer = setTimeout(() => refreshState(true), 2000);
    } catch (error) {
      state.available = false;
      $("connection-status").classList.add("offline");
      $("connection-status").replaceChildren(document.createElement("span"), document.createTextNode("Service indisponible"));
      if (!silent) showNotice(error.message, "Connexion au service local impossible");
      setBusy(false);
    }
  }

  function renderHistory() {
    $("history-count").textContent = String(state.history.length);
    const list = $("history-list");
    list.replaceChildren();
    if (!state.history.length) {
      const p = document.createElement("p"); p.className = "empty-history";
      p.append(document.createTextNode("Vos contrôles apparaîtront ici."), document.createElement("br"), document.createTextNode("Chaque résultat est conservé séparément."));
      list.append(p); return;
    }
    state.history.slice(0, 8).forEach((run) => {
      const button = document.createElement("button");
      button.className = "history-entry";
      button.classList.toggle("active", String(run.id) === String(state.current?.run?.id));
      button.disabled = state.busy;
      const dot = document.createElement("span"); dot.className = "history-dot";
      const summary = run.summary || {};
      const errors = [summary.mapping_errors, summary.schema_errors, summary.reference_errors].filter((value) => typeof value === "number");
      if (errors.length && errors.every((value) => value === 0)) dot.classList.add("clean");
      const content = document.createElement("div");
      const strong = document.createElement("strong"); strong.textContent = run.label || "Contrôle enregistré";
      const small = document.createElement("small"); small.textContent = dateText(run.created_at);
      content.append(strong, small); button.append(dot, content, symbol("chevron"));
      button.addEventListener("click", () => loadHistory(run.id));
      list.append(button);
    });
  }

  async function loadHistory(id) {
    if (state.busy) return;
    setBusy(true, "Lecture du contrôle enregistré…");
    try {
      const result = await api(`/api/history/${encodeURIComponent(id)}`);
      renderResult(result);
      $("results").scrollIntoView({behavior: "smooth", block: "start"});
    } catch (error) {showNotice(error.message, "Impossible d’ouvrir ce contrôle");}
    finally {setBusy(false);}
  }

  function renderResult(result) {
    if (!result || !result.report || !result.report.v2 || !Array.isArray(result.report.v2.findings)) throw new Error("Le résultat ne contient pas les données attendues par la V2.");
    state.current = result;
    state.findings = result.report.v2.findings.map((finding, index) => ({...finding, _key: String(finding.id ?? index), _order: index}));
    state.selected = null;
    const hasComparisons = state.findings.some((finding) => finding.comparison?.applicable === true);
    $("filter-correspondences").disabled = !hasComparisons;
    $("filter-correspondences").title = hasComparisons ? "Afficher les correspondances, y compris les données conformes" : "Relancez un contrôle pour enregistrer les données de cette vue";
    if (result.report.v2.batch) { renderBatch(result); return; }
    $("batch-results").hidden = true;
    $("metric-grid").hidden = false;
    $("findings-empty").hidden = true;
    const summary = result.report.v2.summary || {};
    const correction = result.report.v2.demo_correction;
    const comparison = result.report.v2.comparison;
    const showCorrection = typeof correction?.description === "string" && correction.description.trim().length > 0;
    $("demo-correction").hidden = !showCorrection;
    $("demo-correction-description").textContent = showCorrection ? correction.description : "";
    const showComparison = showCorrection && comparison && ["corrected", "new", "unchanged"].every((key) => typeof comparison[key] === "number" && Number.isFinite(comparison[key]) && comparison[key] >= 0);
    $("demo-comparison").hidden = !showComparison;
    if (showComparison) {
      $("demo-corrected-count").textContent = `${numeric(comparison.corrected)} écart${comparison.corrected > 1 ? "s" : ""} corrigé${comparison.corrected > 1 ? "s" : ""}`;
      $("demo-new-count").textContent = `${numeric(comparison.new)} ${comparison.new > 1 ? "nouveaux écarts" : "nouvel écart"}`;
      $("demo-unchanged-count").textContent = `${numeric(comparison.unchanged)} écart${comparison.unchanged > 1 ? "s" : ""} inchangé${comparison.unchanged > 1 ? "s" : ""}`;
    }
    $("count-mapping").textContent = numeric(summary.mapping_errors);
    $("count-schema").textContent = numeric(summary.schema_errors);
    $("count-reference").textContent = numeric(summary.reference_errors);
    $("count-pending").textContent = numeric(summary.pending);
    $("count-ok").textContent = numeric(summary.ok);
    $("count-na").textContent = numeric(summary.not_applicable);
    $("count-rules").textContent = numeric(summary.selected_rules);
    const inputScope = summary.input_scope_only === true || result.report.decisions?.perimetre_comparaison === "sources_presentes_uniquement";
    const scopeParts = [];
    if (inputScope) {
      if (typeof summary.rules_in_scope === "number") scopeParts.push(`${numeric(summary.rules_in_scope)} correspondances issues des données présentes en entrée`);
      if (typeof summary.ignored_rules === "number") scopeParts.push(`${numeric(summary.ignored_rules)} hors comparaison (source absente, null ou non identifiée)`);
      scopeParts.push("Les autres données de sortie sont ignorées. Schémas et références sont contrôlés séparément.");
    }
    $("scope-summary").textContent = scopeParts.join(" · ");
    $("scope-summary").hidden = scopeParts.length === 0;
    if (summary.preparation_errors > 0) showNotice("Une erreur de lecture ou d’exécution figure dans les résultats. Consultez son détail avant de conclure sur le contrôle.", "Un problème d’exécution est à examiner");
    $("run-description").textContent = `${result.run?.label || "Contrôle terminé"} · ${dateText(result.run?.created_at)}`;
    $("results-title").textContent = "Les données, de l’entrée à la sortie";
    $("coverage-bar").hidden = false;
    const morePending = [];
    if (summary.reference_pending) morePending.push(`${numeric(summary.reference_pending)} point${summary.reference_pending > 1 ? "s" : ""} sur les références`);
    if (summary.preparation_pending) morePending.push(`${numeric(summary.preparation_pending)} point${summary.preparation_pending > 1 ? "s" : ""} sur la lecture des fichiers`);
    $("additional-pending").textContent = morePending.length ? `À préciser également : ${morePending.join(" et ")}.` : "";
    $("additional-pending").hidden = morePending.length === 0;
    $("findings-empty").hidden = true;
    $("findings-content").hidden = false;
    document.querySelectorAll(".metric").forEach((el) => {el.disabled = false;});
    const id = result.run?.id;
    $("export-actions").hidden = !id;
    if (id) ["html", "csv", "json"].forEach((format) => {$("export-" + format).href = `/api/history/${encodeURIComponent(id)}/download?format=${format}`;});
    state.status = state.findings.some((finding) => finding.comparison?.applicable === true) ? "correspondences" : "attention"; state.category = "all"; state.search = "";
    $("search").value = "";
    closeDetail(); updateFilters(); renderFindings(); renderHistory();
    const visible = filteredFindings();
    const first = visible.find(isError) || visible.find(attention) || visible[0];
    if (first && state.status !== "correspondences") selectFinding(first._key, false);
  }

  function renderBatch(result) {
    const batch = result.report.v2.batch;
    $("results-title").textContent = "Contrôle par lot";
    $("run-description").textContent = `${result.run.label} · ${dateText(result.run.created_at)}`;
    $("batch-results").hidden = false;
    $("metric-grid").hidden = true;
    $("coverage-bar").hidden = true;
    $("scope-summary").hidden = true;
    $("additional-pending").hidden = true;
    $("findings-empty").hidden = true;
    $("findings-content").hidden = true;
    $("batch-summary").textContent = `${batch.matched} paire${batch.matched > 1 ? "s" : ""} contrôlée${batch.matched > 1 ? "s" : ""} · ${batch.unmatched} message${batch.unmatched > 1 ? "s" : ""} sans paire unique. Les cas ambigus restent sans contrôle.`;
    const id = result.run?.id;
    $("export-actions").hidden = !id;
    if (id) for (const format of ["html", "csv", "json"]) $("export-" + format).href = `/api/history/${encodeURIComponent(id)}/download?format=${format}`;
    const body = $("batch-body"); body.replaceChildren();
    for (const item of batch.items) {
      const tr = document.createElement("tr");
      const add = value => {const td = document.createElement("td"); td.textContent = String(value ?? ""); tr.append(td); return td;};
      add(item.statut); add(item.entree); add(item.sortie);
      add(Object.entries({...item.identifiants_entree, ...item.identifiants_sortie}).map(([key,value]) => `${key}: ${value}`).join("\n"));
      add(item.ecarts_mapping);
      const td = document.createElement("td");
      if (item.rapport_individuel) {const button = document.createElement("button"); button.className = "text-button"; button.textContent = "Ouvrir le contrôle"; button.addEventListener("click", () => loadHistory(item.rapport_individuel)); td.append(button);}
      else td.textContent = item.detail || "Aucune paire unique";
      tr.append(td); body.append(tr);
    }
    renderHistory();
  }

  function badge(finding) {
    const value = findingStatus(finding);
    const span = document.createElement("span"); span.className = "status-badge";
    const kind = isError(finding) ? "error" : isPending(finding) ? "pending" : value === "OK" ? "ok" : "info";
    span.classList.add("status-" + kind);
    if (["error", "pending"].includes(kind)) span.append(symbol(kind === "error" ? "alert" : "info"));
    span.append(document.createTextNode(statusNames[value] || value));
    return span;
  }

  function filteredFindings() {
    const search = state.search.toLocaleLowerCase("fr-FR");
    const visible = state.findings.filter((finding) => {
      if (state.status === "attention" && !attention(finding)) return false;
      if (state.status === "correspondences" && finding.comparison?.applicable !== true) return false;
      if (state.category !== "all" && finding.category !== state.category) return false;
      return !search || [finding.target, finding.source, finding.detail, finding.action, finding.excel_row, finding.code, finding.category, JSON.stringify(finding.rule || {}), finding.comparison ? JSON.stringify(finding.comparison) : ""].some((value) => String(value ?? "").toLocaleLowerCase("fr-FR").includes(search));
    });
    const categoryOrder = {mapping: 0, schema: 1, reference: 2, preparation: 3, decision: 4};
    const statusOrder = (finding) => isError(finding) ? 0 : isPending(finding) ? 1 : findingStatus(finding) === "OK" ? 2 : 3;
    return visible.sort((a, b) => statusOrder(a) - statusOrder(b)
      || (isError(a) ? (categoryOrder[a.category] ?? 5) - (categoryOrder[b.category] ?? 5) : 0)
      || a._order - b._order);
  }

  function renderFindings() {
    const rows = filteredFindings();
    const body = $("findings-body"); body.replaceChildren();
    const errorCount = rows.filter(isError).length;
    const pendingCount = rows.filter(isPending).length;
    $("visible-count").textContent = `${rows.length.toLocaleString("fr-FR")} contrôle${rows.length > 1 ? "s" : ""} affiché${rows.length > 1 ? "s" : ""} · ${errorCount} écart${errorCount > 1 ? "s" : ""}, ${pendingCount} à préciser`;
    $("no-match").hidden = rows.length !== 0;
    const paired = state.status === "correspondences";
    $("findings-table").classList.toggle("comparison-table", paired);
    const header = document.createElement("tr");
    (paired ? ["Résultat", "Champ Kafka", "Entrée", "Règle · Excel", "Attendu", "Sortie SID", "Écart"] : ["Statut", "Type", "Champ concerné", "Constat", "Détail"]).forEach(label => {
      const th = document.createElement("th"); th.scope = "col"; th.textContent = label; header.append(th);
    });
    $("findings-head").replaceChildren(header);
    const fragment = document.createDocumentFragment();
    rows.forEach((finding) => {
      const row = document.createElement("tr"); row.tabIndex = 0; row.dataset.key = finding._key;
      row.classList.toggle("selected", state.selected === finding._key);
      const field = finding.target || finding.source || finding.code || "Contrôle global";
      row.setAttribute("aria-label", `${statusNames[findingStatus(finding)] || finding.severity}, ${field}. Afficher le détail.`);
      row.setAttribute("aria-selected", String(state.selected === finding._key));
      const status = document.createElement("td"); status.append(badge(finding));
      const category = document.createElement("td"); category.className = "category-name"; category.textContent = categoryNames[finding.category] || finding.category || "Contrôle";
      const destination = document.createElement("td"); const name = document.createElement("span"); name.className = "field-name"; name.textContent = field; destination.append(name);
      if (finding.excel_row !== null && finding.excel_row !== undefined && finding.excel_row !== "") {const line = document.createElement("span"); line.className = "field-line"; line.textContent = `Ligne Excel ${finding.excel_row}`; destination.append(line);}
      const detail = document.createElement("td"); detail.className = "row-detail"; detail.textContent = finding.detail || "";
      const end = document.createElement("td"); const arrow = symbol("chevron"); arrow.classList.add("row-chevron"); end.append(arrow);
      if (paired) {
        const comparison = finding.comparison;
        const cell = (text, cls = "") => { const td = document.createElement("td"); td.className = cls; td.textContent = text; return td; };
        const entries = values => (values || []).map(item => `${item.path}\n${dataValueText(item)}`).join("\n\n");
        const source = cell(finding.source || "Source composée", "field-name-cell");
        const input = cell(entries(comparison.inputs), "data-cell");
        const rule = cell(`${finding.rule?.title || "Règle non enregistrée"}\nLigne ${finding.excel_row ?? "—"}\n${(finding.rule?.steps || []).join("\n")}`, "rule-cell");
        const expected = cell(comparison.expected?.state === "known" ? JSON.stringify(comparison.expected.value, null, 2) : "À préciser", "data-cell");
        const output = cell(entries(comparison.outputs), "data-cell");
        const difference = cell(isError(finding) ? `${differenceLabel(finding)}\n${finding.target}\n${finding.detail}` : isPending(finding) ? finding.detail : "Conforme à la règle", "difference-cell");
        if (isError(finding)) { difference.classList.add("difference-error"); output.classList.add("difference-error"); }
        if (isPending(finding)) difference.classList.add("difference-pending");
        row.append(status, source, input, rule, expected, output, difference);
      } else row.append(status, category, destination, detail, end);
      row.addEventListener("click", () => selectFinding(finding._key));
      row.addEventListener("keydown", (event) => {if (event.key === "Enter" || event.key === " ") {event.preventDefault(); selectFinding(finding._key);}});
      fragment.append(row);
    });
    body.append(fragment);
    if (state.selected && !rows.some((finding) => finding._key === state.selected)) closeDetail();
  }

  function dataValueText(item) {
    if (!item || item.state === "unavailable") return "Valeur non disponible";
    if (item.state === "absent") return "Champ absent";
    if (item.state === "null") return "null";
    return has(item, "value") ? JSON.stringify(item.value, null, 2) : "Valeur non disponible";
  }

  function renderDataValues(id, values, emptyLabel) {
    const target = $(id); target.replaceChildren();
    if (!Array.isArray(values) || values.length === 0) {
      const p = document.createElement("p"); p.className = "comparison-empty"; p.textContent = emptyLabel; target.append(p); return;
    }
    for (const item of values) {
      const block = document.createElement("div"); block.className = "comparison-value";
      const path = document.createElement("code"); path.className = "comparison-path"; path.textContent = item.path || "Chemin non identifié";
      const pre = document.createElement("pre"); pre.textContent = dataValueText(item);
      if (["absent", "unavailable"].includes(item.state)) pre.classList.add("value-unavailable");
      const type = document.createElement("span"); type.className = "comparison-type";
      if (item.state === "present" && has(item, "value")) {
        type.textContent = item.value === null ? "Valeur null" : typeof item.value === "string" ? "Texte" : typeof item.value === "number" ? "Nombre" : typeof item.value === "boolean" ? "Booléen" : Array.isArray(item.value) ? "Liste" : "Objet";
      } else { type.textContent = item.state === "null" ? "Valeur null" : item.state === "absent" ? "Aucune valeur fournie" : "Lecture non disponible"; }
      block.append(path, pre, type); target.append(block);
    }
  }

  function differenceLabel(finding) {
    if (finding.code === "ECART_PRESENCE") return "Donnée manquante ou null en sortie";
    if (finding.code !== "ECART_MAPPING") return "Contrôle à examiner";
    const type = value => value === null ? "null" : Array.isArray(value) ? "liste" : typeof value === "object" ? "objet" : typeof value === "string" ? "texte" : typeof value === "number" ? "nombre" : typeof value === "boolean" ? "booléen" : "inconnu";
    if (finding.has_expected && finding.has_actual && type(finding.expected) !== type(finding.actual))
      return `Type différent : attendu ${type(finding.expected)}, reçu ${type(finding.actual)}`;
    return "Valeur ou présence différente";
  }

  function renderRuleAndDifference(finding) {
    const rule = $("mapping-rule"); rule.replaceChildren();
    const heading = document.createElement("h4"); heading.textContent = `${finding.rule?.title || "Règle non enregistrée"} · ligne Excel ${finding.excel_row ?? "—"}`; rule.append(heading);
    for (const text of finding.rule?.steps || []) { const p = document.createElement("p"); p.textContent = text; rule.append(p); }
    if (finding.rule?.comment) { const details = document.createElement("details"); const summary = document.createElement("summary"); summary.textContent = "Commentaire du mapping Excel"; const p = document.createElement("p"); p.textContent = finding.rule.comment; details.append(summary, p); rule.append(details); }
    if (finding.rule?.parameters && Object.keys(finding.rule.parameters).length) { const details = document.createElement("details"); const summary = document.createElement("summary"); summary.textContent = "Paramètres enregistrés de la règle"; const pre = document.createElement("pre"); pre.textContent = JSON.stringify(finding.rule.parameters, null, 2); details.append(summary, pre); rule.append(details); }
    const diff = $("mapping-difference"); diff.replaceChildren(); diff.hidden = !isError(finding);
    if (!isError(finding)) return;
    const title = document.createElement("h4"); title.textContent = differenceLabel(finding);
    const path = document.createElement("code"); path.textContent = finding.target;
    const reason = document.createElement("p"); reason.textContent = finding.detail;
    diff.append(title, path, reason);
    for (const [key, label] of [["expected", "Attendu à cet emplacement"], ["actual", "Reçu à cet emplacement"]]) {
      if (!finding["has_" + key]) continue;
      const p = document.createElement("p"); p.textContent = label;
      const pre = document.createElement("pre"); pre.textContent = valueText(finding[key]); diff.append(p, pre);
    }
  }

  function renderComparison(finding) {
    const comparison = finding.comparison;
    $("comparison-panel").hidden = !comparison || comparison.applicable !== true;
    $("comparison-unavailable").hidden = true;
    if (!comparison) {
      if (["mapping", "decision"].includes(finding.category) && finding.excel_row) {
        $("comparison-unavailable").textContent = "Ce contrôle enregistré ne contient pas les valeurs d’entrée et de sortie pour cette vue. Relancez le contrôle avec la même paire de fichiers pour les visualiser.";
        $("comparison-unavailable").hidden = false;
      }
      return;
    }
    if (!comparison.applicable) {
      $("comparison-unavailable").textContent = comparison.note || "Source absente, null ou non identifiée : cette correspondance reste hors comparaison. La sortie n’est pas examinée.";
      $("comparison-unavailable").hidden = false;
      return;
    }
    renderRuleAndDifference(finding);
    renderDataValues("comparison-input-values", comparison.inputs, "Aucune donnée source lisible pour cette correspondance.");
    renderDataValues("comparison-output-values", comparison.outputs, "Aucune correspondance de sortie identifiée.");
    const known = comparison.expected?.state === "known" && has(comparison.expected, "value");
    $("comparison-expected-value").hidden = !known;
    $("comparison-expected-value").textContent = known ? JSON.stringify(comparison.expected.value, null, 2) : "";
    $("comparison-expected-explanation").textContent = known ? "Résultat calculé à partir de l’entrée et de la règle de mapping." : comparison.expected?.state === "pending" ? "À préciser : la règle ne permet pas encore de calculer une valeur attendue fiable." : "La valeur attendue n’a pas pu être déterminée pour ce contrôle.";
    $("comparison-note").textContent = comparison.note || "";
    $("comparison-note").hidden = !comparison.note;
  }

  function comparisonCopyText(comparison) {
    if (!comparison) return "";
    if (!comparison.applicable) return comparison.note || "Correspondance hors comparaison : sortie non examinée.";
    const describe = (entries) => (Array.isArray(entries) ? entries : []).map((item) => `${item.path || "Chemin non identifié"} : ${dataValueText(item)}`).join("\n");
    const expected = comparison.expected?.state === "known" && has(comparison.expected, "value") ? JSON.stringify(comparison.expected.value, null, 2) : "À préciser / non disponible";
    return [`Entrée Kafka :\n${describe(comparison.inputs)}`, `Sortie SID :\n${describe(comparison.outputs)}`, `Attendu du mapping :\n${expected}`, comparison.note || ""].filter(Boolean).join("\n\n");
  }

  function selectFinding(key, scroll = true) {
    const finding = state.findings.find((item) => item._key === key);
    if (!finding) return;
    state.selected = key;
    $("detail-panel").hidden = false;
    $("findings-layout").classList.add("has-detail");
    $("detail-status").replaceChildren(badge(finding));
    $("detail-title").textContent = finding.target || finding.source || finding.code || "Contrôle global";
    $("detail-description").textContent = finding.detail || "";
    renderComparison(finding);
    const meta = $("detail-meta"); meta.replaceChildren();
    [["Type", categoryNames[finding.category] || finding.category], ["Ligne Excel", finding.excel_row], ["Source", finding.source], ["Contrôle", finding.code || finding.id]].forEach(([label, value]) => {
      if (value === null || value === undefined || value === "") return;
      const dl = document.createElement("div"); const dt = document.createElement("dt"); dt.textContent = label;
      const dd = document.createElement("dd"); dd.textContent = String(value); dl.append(dt, dd); meta.append(dl);
    });
    $("detail-action").textContent = finding.action || "Consulter le détail de la règle et les fichiers de référence.";
    $("expected-block").hidden = !!finding.comparison || (has(finding, "has_expected") ? !finding.has_expected : !has(finding, "expected"));
    $("actual-block").hidden = !!finding.comparison || (has(finding, "has_actual") ? !finding.has_actual : !has(finding, "actual"));
    $("detail-expected").textContent = valueText(finding.expected);
    $("detail-actual").textContent = valueText(finding.actual);
    document.querySelectorAll("#findings-body tr").forEach((row) => {const selected = row.dataset.key === key; row.classList.toggle("selected", selected); row.setAttribute("aria-selected", String(selected));});
    if (scroll) $("detail-panel").scrollIntoView({behavior: "smooth", block: "nearest"});
  }

  function closeDetail() {
    state.selected = null;
    $("detail-panel").hidden = true;
    $("findings-layout").classList.remove("has-detail");
    document.querySelectorAll("#findings-body tr.selected").forEach((row) => {row.classList.remove("selected"); row.setAttribute("aria-selected", "false");});
  }

  function updateFilters() {
    $("category-filter").value = state.category;
    document.querySelectorAll("[data-status]").forEach((button) => {const active = button.dataset.status === state.status; button.classList.toggle("active", active); button.setAttribute("aria-pressed", String(active));});
    document.querySelectorAll(".metric").forEach((button) => {const active = button.dataset.category === state.category; button.classList.toggle("active", active); button.setAttribute("aria-pressed", String(active));});
  }

  function resetFilters() {state.status = "attention"; state.category = "all"; state.search = ""; $("search").value = ""; updateFilters(); renderFindings();}

  const defaultCaptions = {entree: "Choisir un audit texte ou un message JSON / Avro", sortie: "Choisir le message de sortie correspondant", mapping: "Classeur fourni · sélection par colonne B", avro: "Schéma fourni", swagger: "Contrat fourni"};
  function updateFile(input) {
    const key = input.dataset.fileKey;
    const file = input.files?.[0];
    $("name-" + key).textContent = file ? file.name : defaultCaptions[key];
    const picker = input.closest(".file-picker");
    if (picker) picker.classList.toggle("has-file", Boolean(file));
  }

  for (const key of ["entrees", "sorties"]) $("batch-" + key).addEventListener("change", () => {const files = $("batch-" + key).files; $("name-batch-" + key).textContent = `${files.length} fichier${files.length > 1 ? "s" : ""} sélectionné${files.length > 1 ? "s" : ""}`;});

  let toastTimer;
  function toast(text) {$("toast").textContent = text; $("toast").hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => {$("toast").hidden = true;}, 3000);}

  $("mode-demo").addEventListener("click", () => setMode("demo"));
  $("mode-custom").addEventListener("click", () => setMode("custom"));
  $("mode-batch").addEventListener("click", () => setMode("batch"));
  ["demo", "batch", "custom"].forEach((mode, index) => $("mode-" + mode).addEventListener("keydown", (event) => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const modes = ["demo", "batch", "custom"];
    const next = event.key === "Home" ? 0 : event.key === "End" ? 2 : event.key === "ArrowRight" ? (index + 1) % 3 : (index + 2) % 3;
    setMode(modes[next]); $("mode-" + modes[next]).focus();
  }));
  $("run-demo").addEventListener("click", () => launch("demo"));
  $("empty-run-demo").addEventListener("click", () => launch("demo"));
  $("run-corrected").addEventListener("click", () => launch("demo-corrected"));
  $("custom-panel").addEventListener("submit", (event) => {event.preventDefault(); launch("custom");});
  $("batch-panel").addEventListener("submit", (event) => {event.preventDefault(); launch("batch");});
  $("notice-close").addEventListener("click", () => {$("notice").hidden = true;});
  document.querySelectorAll("input[data-file-key]").forEach((input) => input.addEventListener("change", () => updateFile(input)));
  $("reset-references").addEventListener("click", () => {["mapping", "avro", "swagger"].forEach((key) => {const input = $("file-" + key); input.value = ""; updateFile(input);});});
  document.querySelectorAll(".file-picker").forEach((picker) => {
    picker.addEventListener("dragover", (event) => {event.preventDefault(); if (!state.busy) picker.classList.add("dragging");});
    picker.addEventListener("dragleave", () => picker.classList.remove("dragging"));
    picker.addEventListener("drop", (event) => {event.preventDefault(); picker.classList.remove("dragging"); if (state.busy || !event.dataTransfer?.files.length) return; const input = picker.querySelector("input"); const transfer = new DataTransfer(); transfer.items.add(event.dataTransfer.files[0]); input.files = transfer.files; updateFile(input);});
  });
  document.querySelectorAll("[data-status]").forEach((button) => button.addEventListener("click", () => {state.status = button.dataset.status; if (state.status === "correspondences") state.category = "all"; updateFilters(); renderFindings();}));
  document.querySelectorAll(".metric").forEach((button) => button.addEventListener("click", () => {state.category = state.category === button.dataset.category ? "all" : button.dataset.category; state.status = "attention"; updateFilters(); renderFindings();}));
  $("category-filter").addEventListener("change", (event) => {state.category = event.target.value; updateFilters(); renderFindings();});
  $("search").addEventListener("input", (event) => {state.search = event.target.value; renderFindings();});
  $("reset-filters").addEventListener("click", resetFilters);
  $("close-detail").addEventListener("click", closeDetail);
  $("copy-detail").addEventListener("click", async () => {
    const finding = state.findings.find((item) => item._key === state.selected);
    if (!finding) return;
    const text = [finding.target || finding.source || "Contrôle global", finding.excel_row ? `Ligne Excel : ${finding.excel_row}` : "", finding.detail, comparisonCopyText(finding.comparison), `Action : ${finding.action || "À préciser"}`, (!finding.comparison && (has(finding, "has_expected") ? finding.has_expected : has(finding, "expected"))) ? `Attendu : ${valueText(finding.expected)}` : "", (!finding.comparison && (has(finding, "has_actual") ? finding.has_actual : has(finding, "actual"))) ? `Obtenu : ${valueText(finding.actual)}` : ""].filter(Boolean).join("\n");
    try {await navigator.clipboard.writeText(text); toast("Constat copié dans le presse-papiers.");}
    catch (_) {toast("La copie automatique n’est pas disponible. Sélectionnez le texte du détail.");}
  });

  setBusy(false);
  refreshState();
})();
