"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const state = {busy: false, mode: "demo", history: [], current: null, findings: [], selected: null, status: "attention", category: "all", search: "", available: false};
  const categoryNames = {mapping: "Mapping", schema: "Schéma", reference: "Références", decision: "À préciser", preparation: "Lecture"};
  const statusNames = {ERREUR: "Écart", ERROR: "Écart", A_VERIFIER: "À préciser", WARNING: "À préciser", PENDING: "À préciser", OK: "Conforme", INFO: "Info", NON_APPLICABLE: "Sans objet", "NOT-APPLICABLE": "Sans objet"};
  const severityKey = (value) => String(value || "INFO").toUpperCase();
  const findingStatus = (finding) => severityKey(finding.status || finding.severity);
  const isError = (f) => ["ERREUR", "ERROR"].includes(findingStatus(f));
  const isPending = (f) => ["A_VERIFIER", "WARNING", "PENDING"].includes(findingStatus(f));
  const attention = (f) => isError(f) || isPending(f);
  const symbol = (name) => {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", `#i-${name}`);
    svg.append(use);
    svg.setAttribute("aria-hidden", "true");
    return svg;
  };
  const numeric = (value) => typeof value === "number" && Number.isFinite(value) ? value.toLocaleString("fr-FR") : "—";
  const has = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
  const valueText = (value) => {
    if (value === undefined) return "Non renseignée dans ce constat";
    if (value && typeof value === "object" && value.absent === true && Object.keys(value).length === 1) return "Champ absent";
    return typeof value === "string" ? value : JSON.stringify(value, null, 2);
  };
  const dateText = (value) => {
    if (!value) return "Date non renseignée";
    const date = new Date(value);
    return Number.isNaN(date.valueOf()) ? String(value) : new Intl.DateTimeFormat("fr-FR", {day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit"}).format(date);
  };

  async function api(path, options = {}) {
    let response;
    try { response = await fetch(path, {...options, headers: {"Content-Type": "application/json", ...(options.headers || {})}}); }
    catch (_) { throw new Error("Le service local ne répond pas. Vérifiez que le lanceur de la V2 est toujours ouvert, puis réessayez."); }
    let data;
    try { data = await response.json(); }
    catch (_) { throw new Error("Le service local a renvoyé une réponse illisible. Vérifiez la fenêtre du lanceur."); }
    if (!response.ok) {
      const message = response.status === 409 ? "Un autre contrôle est déjà en cours. Attendez sa fin avant de relancer." : (data.detail || data.error || `Le contrôle n’a pas abouti (${response.status}).`);
      throw new Error(typeof message === "string" ? message : JSON.stringify(message));
    }
    return data;
  }

  function showNotice(message, title = "Le contrôle n’a pas pu être terminé") {
    $("notice-title").textContent = title;
    $("notice-message").textContent = message;
    $("notice").hidden = false;
    $("notice").scrollIntoView({behavior: "smooth", block: "nearest"});
  }

  function setBusy(busy, title = "Contrôle en cours…") {
    state.busy = busy;
    $("progress-title").textContent = title;
    $("progress-panel").hidden = !busy;
    ["run-demo", "run-corrected", "empty-run-demo"].forEach((id) => {$(id).disabled = busy || !state.available;});
    $("run-custom").disabled = busy;
    document.querySelectorAll("input[type=file], #run-label, #reset-references").forEach((el) => {el.disabled = busy;});
    document.querySelectorAll(".history-entry").forEach((el) => {el.disabled = busy;});
    $("workspace").setAttribute("aria-busy", String(busy));
  }

  function setMode(mode) {
    state.mode = mode;
    const demo = mode === "demo";
    $("mode-demo").classList.toggle("active", demo);
    $("mode-custom").classList.toggle("active", !demo);
    $("mode-demo").setAttribute("aria-selected", String(demo));
    $("mode-custom").setAttribute("aria-selected", String(!demo));
    $("demo-panel").hidden = !demo;
    $("custom-panel").hidden = demo;
  }

  async function filePayload(file) {
    // FileReader produit directement du base64 et préserve les fichiers binaires Excel/Avro.
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({name: file.name, content_base64: String(reader.result).split(",", 2)[1]});
      reader.onerror = () => reject(new Error(`Impossible de lire le fichier « ${file.name} ».`));
      reader.readAsDataURL(file);
    });
  }

  async function launch(mode) {
    if (state.busy) return;
    $("notice").hidden = true;
    let request = {mode};
    if (mode === "custom") {
      if (!$("custom-panel").reportValidity()) return;
      request.label = $("run-label").value.trim();
      request.files = {};
    }
    setBusy(true, mode === "demo-corrected" ? "Contrôle de la copie avec eventNature renseigné…" : "Comparaison des messages en cours…");
    try {
      if (mode === "custom") {
        for (const input of document.querySelectorAll("input[data-file-key]")) {
          if (input.files && input.files[0]) request.files[input.dataset.fileKey] = await filePayload(input.files[0]);
        }
      }
      const result = await api("/api/run", {method: "POST", body: JSON.stringify(request)});
      renderResult(result);
      await refreshState(true);
      $("results").scrollIntoView({behavior: "smooth", block: "start"});
    } catch (error) {showNotice(error.message);}
    finally {setBusy(false);}
  }

  let remoteBusyTimer;
  async function refreshState(silent = false) {
    try {
      const data = await api("/api/state");
      state.available = data.demo?.available !== false;
      state.history = Array.isArray(data.history) ? data.history : [];
      $("connection-status").classList.remove("offline");
      $("connection-status").replaceChildren(document.createElement("span"), document.createTextNode("Exécution locale"));
      renderHistory();
      setBusy(Boolean(data.busy));
      clearTimeout(remoteBusyTimer);
      if (data.busy) remoteBusyTimer = setTimeout(() => refreshState(true), 2000);
    } catch (error) {
      state.available = false;
      $("connection-status").classList.add("offline");
      $("connection-status").replaceChildren(document.createElement("span"), document.createTextNode("Service indisponible"));
      if (!silent) showNotice(error.message, "Connexion au service local impossible");
      setBusy(false);
    }
  }

  function renderHistory() {
    $("history-count").textContent = String(state.history.length);
    const list = $("history-list");
    list.replaceChildren();
    if (!state.history.length) {
      const p = document.createElement("p"); p.className = "empty-history";
      p.append(document.createTextNode("Vos contrôles apparaîtront ici."), document.createElement("br"), document.createTextNode("Chaque résultat est conservé séparément."));
      list.append(p); return;
    }
    state.history.slice(0, 8).forEach((run) => {
      const button = document.createElement("button");
      button.className = "history-entry";
      button.classList.toggle("active", String(run.id) === String(state.current?.run?.id));
      button.disabled = state.busy;
      const dot = document.createElement("span"); dot.className = "history-dot";
      const summary = run.summary || {};
      const errors = [summary.mapping_errors, summary.schema_errors, summary.reference_errors].filter((value) => typeof value === "number");
      if (errors.length && errors.every((value) => value === 0)) dot.classList.add("clean");
      const content = document.createElement("div");
      const strong = document.createElement("strong"); strong.textContent = run.label || "Contrôle enregistré";
      const small = document.createElement("small"); small.textContent = dateText(run.created_at);
      content.append(strong, small); button.append(dot, content, symbol("chevron"));
      button.addEventListener("click", () => loadHistory(run.id));
      list.append(button);
    });
  }

  async function loadHistory(id) {
    if (state.busy) return;
    setBusy(true, "Lecture du contrôle enregistré…");
    try {
      const result = await api(`/api/history/${encodeURIComponent(id)}`);
      renderResult(result);
      $("results").scrollIntoView({behavior: "smooth", block: "start"});
    } catch (error) {showNotice(error.message, "Impossible d’ouvrir ce contrôle");}
    finally {setBusy(false);}
  }

  function renderResult(result) {
    if (!result || !result.report || !result.report.v2 || !Array.isArray(result.report.v2.findings)) throw new Error("Le résultat ne contient pas les données attendues par la V2.");
    state.current = result;
    state.findings = result.report.v2.findings.map((finding, index) => ({...finding, _key: String(finding.id ?? index), _order: index}));
    state.selected = null;
    const summary = result.report.v2.summary || {};
    const correction = result.report.v2.demo_correction;
    const comparison = result.report.v2.comparison;
    const showCorrection = typeof correction?.description === "string" && correction.description.trim().length > 0;
    $("demo-correction").hidden = !showCorrection;
    $("demo-correction-description").textContent = showCorrection ? correction.description : "";
    const showComparison = showCorrection && comparison && ["corrected", "new", "unchanged"].every((key) => typeof comparison[key] === "number" && Number.isFinite(comparison[key]) && comparison[key] >= 0);
    $("demo-comparison").hidden = !showComparison;
    if (showComparison) {
      $("demo-corrected-count").textContent = `${numeric(comparison.corrected)} écart${comparison.corrected > 1 ? "s" : ""} corrigé${comparison.corrected > 1 ? "s" : ""}`;
      $("demo-new-count").textContent = `${numeric(comparison.new)} ${comparison.new > 1 ? "nouveaux écarts" : "nouvel écart"}`;
      $("demo-unchanged-count").textContent = `${numeric(comparison.unchanged)} écart${comparison.unchanged > 1 ? "s" : ""} inchangé${comparison.unchanged > 1 ? "s" : ""}`;
    }
    $("count-mapping").textContent = numeric(summary.mapping_errors);
    $("count-schema").textContent = numeric(summary.schema_errors);
    $("count-reference").textContent = numeric(summary.reference_errors);
    $("count-pending").textContent = numeric(summary.pending);
    $("count-ok").textContent = numeric(summary.ok);
    $("count-na").textContent = numeric(summary.not_applicable);
    $("count-rules").textContent = numeric(summary.selected_rules);
    const inputScope = summary.input_scope_only === true || result.report.decisions?.perimetre_comparaison === "sources_presentes_uniquement";
    const scopeParts = [];
    if (inputScope) {
      if (typeof summary.rules_in_scope === "number") scopeParts.push(`${numeric(summary.rules_in_scope)} correspondances issues des données présentes en entrée`);
      if (typeof summary.ignored_rules === "number") scopeParts.push(`${numeric(summary.ignored_rules)} hors comparaison (source absente, null ou non identifiée)`);
      scopeParts.push("Les autres données de sortie sont ignorées. Schémas et références sont contrôlés séparément.");
    }
    $("scope-summary").textContent = scopeParts.join(" · ");
    $("scope-summary").hidden = scopeParts.length === 0;
    if (summary.preparation_errors > 0) showNotice("Une erreur de lecture ou d’exécution figure dans les résultats. Consultez son détail avant de conclure sur le contrôle.", "Un problème d’exécution est à examiner");
    $("run-description").textContent = `${result.run?.label || "Contrôle terminé"} · ${dateText(result.run?.created_at)}`;
    $("results-title").textContent = "Les écarts, avec leur explication";
    $("coverage-bar").hidden = false;
    const morePending = [];
    if (summary.reference_pending) morePending.push(`${numeric(summary.reference_pending)} point${summary.reference_pending > 1 ? "s" : ""} sur les références`);
    if (summary.preparation_pending) morePending.push(`${numeric(summary.preparation_pending)} point${summary.preparation_pending > 1 ? "s" : ""} sur la lecture des fichiers`);
    $("additional-pending").textContent = morePending.length ? `À préciser également : ${morePending.join(" et ")}.` : "";
    $("additional-pending").hidden = morePending.length === 0;
    $("findings-empty").hidden = true;
    $("findings-content").hidden = false;
    document.querySelectorAll(".metric").forEach((el) => {el.disabled = false;});
    const id = result.run?.id;
    $("export-actions").hidden = !id;
    if (id) ["html", "csv", "json"].forEach((format) => {$("export-" + format).href = `/api/history/${encodeURIComponent(id)}/download?format=${format}`;});
    state.status = "attention"; state.category = "all"; state.search = "";
    $("search").value = "";
    closeDetail(); updateFilters(); renderFindings(); renderHistory();
    const visible = filteredFindings();
    const first = visible.find(isError) || visible.find(attention);
    if (first) selectFinding(first._key, false);
  }

  function badge(finding) {
    const value = findingStatus(finding);
    const span = document.createElement("span"); span.className = "status-badge";
    const kind = isError(finding) ? "error" : isPending(finding) ? "pending" : value === "OK" ? "ok" : "info";
    span.classList.add("status-" + kind);
    if (["error", "pending"].includes(kind)) span.append(symbol(kind === "error" ? "alert" : "info"));
    span.append(document.createTextNode(statusNames[value] || value));
    return span;
  }

  function filteredFindings() {
    const search = state.search.toLocaleLowerCase("fr-FR");
    const visible = state.findings.filter((finding) => {
      if (state.status === "attention" && !attention(finding)) return false;
      if (state.category !== "all" && finding.category !== state.category) return false;
      return !search || [finding.target, finding.source, finding.detail, finding.action, finding.excel_row, finding.code, finding.category].some((value) => String(value ?? "").toLocaleLowerCase("fr-FR").includes(search));
    });
    const categoryOrder = {mapping: 0, schema: 1, reference: 2, preparation: 3, decision: 4};
    const statusOrder = (finding) => isError(finding) ? 0 : isPending(finding) ? 1 : findingStatus(finding) === "OK" ? 2 : 3;
    return visible.sort((a, b) => statusOrder(a) - statusOrder(b)
      || (isError(a) ? (categoryOrder[a.category] ?? 5) - (categoryOrder[b.category] ?? 5) : 0)
      || a._order - b._order);
  }

  function renderFindings() {
    const rows = filteredFindings();
    const body = $("findings-body"); body.replaceChildren();
    const errorCount = rows.filter(isError).length;
    const pendingCount = rows.filter(isPending).length;
    $("visible-count").textContent = `${rows.length.toLocaleString("fr-FR")} contrôle${rows.length > 1 ? "s" : ""} affiché${rows.length > 1 ? "s" : ""} · ${errorCount} écart${errorCount > 1 ? "s" : ""}, ${pendingCount} à préciser`;
    $("no-match").hidden = rows.length !== 0;
    const fragment = document.createDocumentFragment();
    rows.forEach((finding) => {
      const row = document.createElement("tr"); row.tabIndex = 0; row.dataset.key = finding._key;
      row.classList.toggle("selected", state.selected === finding._key);
      const field = finding.target || finding.source || finding.code || "Contrôle global";
      row.setAttribute("aria-label", `${statusNames[findingStatus(finding)] || finding.severity}, ${field}. Afficher le détail.`);
      row.setAttribute("aria-selected", String(state.selected === finding._key));
      const status = document.createElement("td"); status.append(badge(finding));
      const category = document.createElement("td"); category.className = "category-name"; category.textContent = categoryNames[finding.category] || finding.category || "Contrôle";
      const destination = document.createElement("td"); const name = document.createElement("span"); name.className = "field-name"; name.textContent = field; destination.append(name);
      if (finding.excel_row !== null && finding.excel_row !== undefined && finding.excel_row !== "") {const line = document.createElement("span"); line.className = "field-line"; line.textContent = `Ligne Excel ${finding.excel_row}`; destination.append(line);}
      const detail = document.createElement("td"); detail.className = "row-detail"; detail.textContent = finding.detail || "";
      const end = document.createElement("td"); const arrow = symbol("chevron"); arrow.classList.add("row-chevron"); end.append(arrow);
      row.append(status, category, destination, detail, end);
      row.addEventListener("click", () => selectFinding(finding._key));
      row.addEventListener("keydown", (event) => {if (event.key === "Enter" || event.key === " ") {event.preventDefault(); selectFinding(finding._key);}});
      fragment.append(row);
    });
    body.append(fragment);
    if (state.selected && !rows.some((finding) => finding._key === state.selected)) closeDetail();
  }

  function selectFinding(key, scroll = true) {
    const finding = state.findings.find((item) => item._key === key);
    if (!finding) return;
    state.selected = key;
    $("detail-panel").hidden = false;
    $("findings-layout").classList.add("has-detail");
    $("detail-status").replaceChildren(badge(finding));
    $("detail-title").textContent = finding.target || finding.source || finding.code || "Contrôle global";
    $("detail-description").textContent = finding.detail || "";
    const meta = $("detail-meta"); meta.replaceChildren();
    [["Type", categoryNames[finding.category] || finding.category], ["Ligne Excel", finding.excel_row], ["Source", finding.source], ["Contrôle", finding.code || finding.id]].forEach(([label, value]) => {
      if (value === null || value === undefined || value === "") return;
      const dl = document.createElement("div"); const dt = document.createElement("dt"); dt.textContent = label;
      const dd = document.createElement("dd"); dd.textContent = String(value); dl.append(dt, dd); meta.append(dl);
    });
    $("detail-action").textContent = finding.action || "Consulter le détail de la règle et les fichiers de référence.";
    $("expected-block").hidden = has(finding, "has_expected") ? !finding.has_expected : !has(finding, "expected");
    $("actual-block").hidden = has(finding, "has_actual") ? !finding.has_actual : !has(finding, "actual");
    $("detail-expected").textContent = valueText(finding.expected);
    $("detail-actual").textContent = valueText(finding.actual);
    document.querySelectorAll("#findings-body tr").forEach((row) => {const selected = row.dataset.key === key; row.classList.toggle("selected", selected); row.setAttribute("aria-selected", String(selected));});
    if (scroll && window.matchMedia("(max-width: 620px)").matches) $("detail-panel").scrollIntoView({behavior: "smooth", block: "nearest"});
  }

  function closeDetail() {
    state.selected = null;
    $("detail-panel").hidden = true;
    $("findings-layout").classList.remove("has-detail");
    document.querySelectorAll("#findings-body tr.selected").forEach((row) => {row.classList.remove("selected"); row.setAttribute("aria-selected", "false");});
  }

  function updateFilters() {
    $("category-filter").value = state.category;
    document.querySelectorAll("[data-status]").forEach((button) => {const active = button.dataset.status === state.status; button.classList.toggle("active", active); button.setAttribute("aria-pressed", String(active));});
    document.querySelectorAll(".metric").forEach((button) => {const active = button.dataset.category === state.category; button.classList.toggle("active", active); button.setAttribute("aria-pressed", String(active));});
  }

  function resetFilters() {state.status = "attention"; state.category = "all"; state.search = ""; $("search").value = ""; updateFilters(); renderFindings();}

  const defaultCaptions = {entree: "Choisir un audit texte ou un message JSON / Avro", sortie: "Choisir le message de sortie correspondant", mapping: "Classeur fourni · sélection par colonne B", avro: "Schéma fourni", swagger: "Contrat fourni"};
  function updateFile(input) {
    const key = input.dataset.fileKey;
    const file = input.files?.[0];
    $("name-" + key).textContent = file ? file.name : defaultCaptions[key];
    const picker = input.closest(".file-picker");
    if (picker) picker.classList.toggle("has-file", Boolean(file));
  }

  let toastTimer;
  function toast(text) {$("toast").textContent = text; $("toast").hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => {$("toast").hidden = true;}, 3000);}

  $("mode-demo").addEventListener("click", () => setMode("demo"));
  $("mode-custom").addEventListener("click", () => setMode("custom"));
  ["mode-demo", "mode-custom"].forEach((id) => $(id).addEventListener("keydown", (event) => {if (["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) {event.preventDefault(); const mode = ["ArrowRight", "End"].includes(event.key) ? "custom" : "demo"; setMode(mode); $("mode-" + mode).focus();}}));
  $("run-demo").addEventListener("click", () => launch("demo"));
  $("empty-run-demo").addEventListener("click", () => launch("demo"));
  $("run-corrected").addEventListener("click", () => launch("demo-corrected"));
  $("custom-panel").addEventListener("submit", (event) => {event.preventDefault(); launch("custom");});
  $("notice-close").addEventListener("click", () => {$("notice").hidden = true;});
  document.querySelectorAll("input[data-file-key]").forEach((input) => input.addEventListener("change", () => updateFile(input)));
  $("reset-references").addEventListener("click", () => {["mapping", "avro", "swagger"].forEach((key) => {const input = $("file-" + key); input.value = ""; updateFile(input);});});
  document.querySelectorAll(".file-picker").forEach((picker) => {
    picker.addEventListener("dragover", (event) => {event.preventDefault(); if (!state.busy) picker.classList.add("dragging");});
    picker.addEventListener("dragleave", () => picker.classList.remove("dragging"));
    picker.addEventListener("drop", (event) => {event.preventDefault(); picker.classList.remove("dragging"); if (state.busy || !event.dataTransfer?.files.length) return; const input = picker.querySelector("input"); const transfer = new DataTransfer(); transfer.items.add(event.dataTransfer.files[0]); input.files = transfer.files; updateFile(input);});
  });
  document.querySelectorAll("[data-status]").forEach((button) => button.addEventListener("click", () => {state.status = button.dataset.status; updateFilters(); renderFindings();}));
  document.querySelectorAll(".metric").forEach((button) => button.addEventListener("click", () => {state.category = state.category === button.dataset.category ? "all" : button.dataset.category; state.status = "attention"; updateFilters(); renderFindings();}));
  $("category-filter").addEventListener("change", (event) => {state.category = event.target.value; updateFilters(); renderFindings();});
  $("search").addEventListener("input", (event) => {state.search = event.target.value; renderFindings();});
  $("reset-filters").addEventListener("click", resetFilters);
  $("close-detail").addEventListener("click", closeDetail);
  $("copy-detail").addEventListener("click", async () => {
    const finding = state.findings.find((item) => item._key === state.selected);
    if (!finding) return;
    const text = [finding.target || finding.source || "Contrôle global", finding.excel_row ? `Ligne Excel : ${finding.excel_row}` : "", finding.detail, `Action : ${finding.action || "À préciser"}`, (has(finding, "has_expected") ? finding.has_expected : has(finding, "expected")) ? `Attendu : ${valueText(finding.expected)}` : "", (has(finding, "has_actual") ? finding.has_actual : has(finding, "actual")) ? `Obtenu : ${valueText(finding.actual)}` : ""].filter(Boolean).join("\n");
    try {await navigator.clipboard.writeText(text); toast("Constat copié dans le presse-papiers.");}
    catch (_) {toast("La copie automatique n’est pas disponible. Sélectionnez le texte du détail.");}
  });

  setBusy(false);
  refreshState();
})();
