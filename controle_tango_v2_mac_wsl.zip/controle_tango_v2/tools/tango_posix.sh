#!/bin/bash
# Lanceur commun : Bash 3.2 (macOS) et Bash WSL, sans activation du venv.
rise_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)" || exit 2
cd "$rise_root" || exit 2
rise_action="$1"
shift

rise_python=""
if [ -n "${TANGO_PYTHON:-}" ]; then
  rise_python="$TANGO_PYTHON"
else
  for rise_candidate in python3.12 python3; do
    if command -v "$rise_candidate" >/dev/null 2>&1 && "$rise_candidate" -c 'import sys; sys.exit(sys.version_info[:2] != (3, 12))' >/dev/null 2>&1; then
      rise_python="$rise_candidate"
      break
    fi
  done
  if [ -z "$rise_python" ]; then
    for rise_candidate in "$rise_root/.venv-mac/bin/python" "$rise_root/.venv-wsl/bin/python" "$rise_root/.venv/bin/python"; do
      if [ -x "$rise_candidate" ] && "$rise_candidate" -c 'import sys; sys.exit(sys.version_info[:2] != (3, 12))' >/dev/null 2>&1; then
        rise_python="$rise_candidate"
        break
      fi
    done
  fi
fi

if [ -z "$rise_python" ]; then
  echo "Python 3.12 est nécessaire. Voir GUIDE_MAC_WSL.md (prérequis Mac ou Ubuntu/WSL)."
  echo "Si Python est installé ailleurs : TANGO_PYTHON=/chemin/vers/python3.12 bash Installer_V2_WSL.sh"
  exit 2
fi
exec "$rise_python" "$rise_root/tango_local.py" "$rise_action" "$@"
