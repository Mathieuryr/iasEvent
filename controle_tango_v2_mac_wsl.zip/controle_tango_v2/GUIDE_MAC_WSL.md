# TANGO V2 — Mac, WSL et réseau d'entreprise

Commencer par `DEMARRAGE_MAC_WSL.md`. Les règles de contrôle et l'utilisation de l'interface sont décrites dans `GUIDE_V2.md`. Le moteur `2.5-demo` compare uniquement les correspondances ayant une donnée source présente dans l'entrée Kafka. Cette livraison conserve l'installation Mac/WSL et les réglages réseau.

## 1. Prérequis et installation

La livraison `controle_tango_v2_mac_wsl.zip` inclut des paquets CPython 3.12 pour Mac Intel, Mac Apple Silicon et Linux x86_64 (WSL sur PC Intel/AMD). Les paquets Mac ciblent macOS 11 ou plus récent. WSL sur Windows ARM n'est pas couvert par ces paquets.

Python 3.12 est à installer sur chaque système. Sur Mac : utiliser une installation de Python 3.12 depuis le [site Python](https://www.python.org/downloads/macos/), ou celle déjà disponible. Sur WSL : utiliser le Python **Linux** de la distribution, avec `venv`. Le Python Windows installé avec `py` ne remplace pas le Python de WSL.

Avec Ubuntu 24.04, si les paquets ne sont pas déjà installés, leur installation via les dépôts de l'entreprise peut nécessiter l'IT :

```sh
sudo apt update
sudo apt install python3.12 python3.12-venv
```

Ces commandes système ont besoin de l'accès aux dépôts Ubuntu configurés et des droits du poste. L'installateur TANGO ne les exécute pas. Il n'installe ni WSL, ni Python, ni VPN. Sur une autre distribution/version, utiliser les paquets Python 3.12 prévus par l'IT.

Après extraction complète du ZIP, placer le dossier dans le dossier personnel du système utilisé. Dans WSL, préférer un dossier Linux tel que `~/applications/controle_tango_v2`. Exemple de copie depuis un ZIP déjà extrait par Windows (adapter le chemin et choisir une destination nouvelle) :

```sh
mkdir -p ~/applications
cp -R "/mnt/c/Users/VOTRE_COMPTE/Downloads/controle_tango_v2" ~/applications/
cd ~/applications/controle_tango_v2
bash Installer_V2_WSL.sh --hors-ligne
bash Lancer_V2_WSL.sh
```

Sur Mac, les commandes équivalentes sont :

```sh
bash Installer_V2_Mac.command --hors-ligne
bash Lancer_V2_Mac.command
```

Le double-clic sur les fichiers `.command` est également possible si macOS le permet. Les commandes avec `bash` fonctionnent sans dépendre du droit d'exécution conservé à l'extraction du ZIP.

Si Python 3.12 est installé dans un emplacement particulier, indiquer l'exécutable au lanceur :

```sh
TANGO_PYTHON="/chemin/vers/python3.12" bash Installer_V2_WSL.sh --hors-ligne
```

L'installateur crée `.venv-mac` ou `.venv-wsl` et vérifie les imports nécessaires. Il utilise les paquets inclus lorsque ceux de la cible sont présents. `--hors-ligne` impose cette méthode : un paquet absent, altéré ou prévu pour une autre cible interrompt l'installation, sans basculer vers Internet. Les versions indirectes sont figées dans `requirements-hors-ligne.txt`, avec leurs empreintes SHA-256. Les fichiers métier et `v2_runs` ne sont pas effacés par l'installation.

## 2. Utilisation quotidienne

Lancer le fichier du système utilisé, puis ouvrir **http://127.0.0.1:8792/**. Sous WSL, ouvrir l'adresse dans Edge, Chrome ou le navigateur Windows habituel. Le lanceur WSL n'a pas besoin d'exécuter PowerShell ou un navigateur Linux. L'accès de Windows au serveur WSL par `localhost` est [documenté par Microsoft](https://learn.microsoft.com/en-us/windows/wsl/networking).

Laisser le terminal ouvert. Ctrl+C arrête le serveur. Si le port est occupé :

```sh
bash Lancer_V2_WSL.sh --port 8793
```

Ouvrir alors http://127.0.0.1:8793/. Sur Mac, remplacer le nom du lanceur par `Lancer_V2_Mac.command`.

Le contrôle traite les fichiers sélectionnés localement ; il ne se connecte pas à un cluster Kafka, au SID ou à une API distante. Le VPN sert aux ressources d'entreprise dont le poste a besoin ; aucune connexion VPN n'est créée ou modifiée par TANGO.

## 3. Installer depuis le réseau d'entreprise

Cette section concerne une installation **en ligne**, par exemple si l'IT impose son dépôt Python :

```sh
bash Installer_V2_WSL.sh --en-ligne
```

Le programme conserve les variables de proxy et la configuration pip du poste. Il complète `NO_PROXY` et `no_proxy` avec `localhost`, `127.0.0.1` et `::1`, en préservant les exceptions de l'entreprise. Cela concerne le processus lancé ; les réglages du navigateur Windows restent ceux de Windows.

Si un réglage explicite est nécessaire :

```sh
cp reseau.exemple.ini reseau.local.ini
```

Modifier uniquement les paramètres fournis par l'IT :

```ini
[reseau]
proxy = http://proxy.entreprise.example:8080
index_url = https://paquets.entreprise.example/simple
certificat = /mnt/c/Users/VOTRE_COMPTE/Documents/ca-entreprise.pem
timeout = 30
```

Ces adresses sont des exemples. Laisser vide une valeur pour conserver le réglage existant. Un dépôt explicite remplace les index supplémentaires hérités. Les chemins sont ceux de **Linux sous WSL**, ceux de **macOS sur Mac**. Un certificat peut aussi être indiqué par un chemin relatif au fichier de configuration. Le paramètre `certificat` renseigne `PIP_CERT` et conserve la vérification HTTPS, conformément à la [documentation pip](https://pip.pypa.io/en/stable/topics/https-certificates/).

Ne pas mettre les identifiants dans une commande à conserver dans l'historique. Les identifiants d'entreprise ne sont pas fournis par le projet. Pour un proxy NTLM/Kerberos/SSO, utiliser la méthode approuvée par l'IT, ou les paquets hors ligne si cette installation est permise. Le script ne met pas en place d'authentification Windows intégrée. Le fichier `reseau.local.ini` et les certificats personnels sont exclus de la livraison.

## 4. Proxy automatique de Windows, PAC et VPN

Sur Windows 11 22H2 ou plus récent avec un WSL récent, `autoProxy=true` permet à WSL de reprendre les informations de proxy HTTP de Windows ; `dnsTunneling=true` peut aider la résolution des noms avec un VPN. Ces [réglages WSL](https://learn.microsoft.com/en-us/windows/wsl/networking) concernent le poste entier, pas seulement TANGO.

Le projet fournit `configuration/wslconfig.exemple`. Si nécessaire, fusionner ses options avec le fichier existant `%USERPROFILE%\.wslconfig`, selon les règles de votre IT. Ne pas remplacer un fichier existant. Après sauvegarde du travail des autres applications WSL, `wsl --shutdown` dans PowerShell applique les changements au prochain démarrage ; cette commande arrête toutes les distributions WSL.

Le mode réseau `mirrored` est présenté comme une option commentée dans l'exemple. Il peut améliorer certains cas VPN, mais ne convient pas à toutes les configurations. Le script ne change pas les routes, DNS, pare-feu ou politiques du VPN.

Si Windows fournit un fichier PAC, WSL peut exposer `WSL_PAC_URL`. pip ne sait pas interpréter ce fichier automatiquement. Ce cas est [décrit par Microsoft](https://learn.microsoft.com/en-us/windows/wsl/troubleshooting#considerations-when-using-autoproxy-for-httpproxy-mirroring-in-wsl). Utiliser les dépendances hors ligne, le dépôt interne accessible, ou l'adresse de proxy effective fournie par l'IT. Ne pas supposer qu'un navigateur Windows fonctionnel prouve l'accès de pip dans WSL.

## 5. Diagnostic

Diagnostic local, sans requête réseau :

```sh
bash Diagnostic_Mac_WSL.sh
```

Il vérifie l'environnement Python, l'intégrité des paquets disponibles et la présence de réglages proxy/PAC/certificat. Les adresses et identifiants réseau ne sont pas affichés. Il n'inspecte pas la connexion VPN et ne certifie pas le routage d'entreprise.

Test volontaire du dépôt Python, avec un petit téléchargement et sans fichier métier :

```sh
bash Diagnostic_Mac_WSL.sh --tester-reseau
```

| Message / symptôme | Action |
| --- | --- |
| Python 3.12 absent | Installer le Python du système concerné ; sous WSL il faut un Python Linux. |
| `ensurepip` / création du venv impossible | Sous Ubuntu, vérifier le paquet `python3.12-venv`. Si un environnement incomplet existe, le renommer puis relancer l'installateur. |
| `407 Proxy Authentication Required` | L'authentification proxy reste à configurer avec l'IT ; utiliser le mode hors ligne si permis. |
| `CERTIFICATE_VERIFY_FAILED` | Fournir le certificat PEM complet approuvé par l'entreprise ou installer la CA dans le magasin Linux avec l'IT. Les certificats Windows ne sont pas automatiquement ceux de WSL. |
| DNS, connexion refusée ou délai expiré en ligne | Vérifier les réglages VPN/proxy de WSL et l'accès au dépôt ; le diagnostic local ne suffit pas. |
| Paquets hors ligne incompatibles | Utiliser CPython 3.12 et la bonne architecture ; réextraire l'archive complète. |
| Interface inaccessible depuis Windows | Vérifier que le serveur est actif dans WSL, tester `curl --noproxy '*' http://127.0.0.1:8792/api/state` dans WSL, puis vérifier le transfert localhost et l'exception proxy locale du navigateur avec l'IT. |
| Port occupé | Utiliser `--port 8793` et ouvrir cette nouvelle adresse. |

Ne pas ouvrir le serveur sur `0.0.0.0` pour résoudre un problème de localhost. Le serveur est volontairement limité à `127.0.0.1`.

## 6. Préparer ou renouveler les dépendances hors ligne

Les trois cibles sont déjà incluses dans l'archive Mac/WSL. Pour les renouveler depuis un poste disposant d'un accès approuvé au dépôt :

```sh
bash Preparer_hors_ligne.sh --cible wsl-x86_64 --dossier-paquets /chemin/vers/nouveaux_paquets_wsl
```

Les autres cibles sont `mac-arm64` et `mac-x86_64`. Le dossier de destination doit être vide. La préparation respecte les réglages proxy/certificat et télécharge les paquets pour la cible demandée sans les exécuter. La méthode utilise les [options de téléchargement pip pour une autre plateforme](https://pip.pypa.io/en/stable/cli/pip_download/).

Transférer le dossier complet vers `hors_ligne/<cible>` de la livraison concernée. Il inclut les paquets `.whl`, le fichier de versions et `manifest.json`. Les paquets d'une cible ne remplacent pas ceux d'une autre. La présence de paquets Linux ne constitue pas une exécution validée sur WSL.

## 7. Mise à jour et limites vérifiées

Arrêter l'application, garder une copie de `v2_runs/`, extraire la nouvelle livraison dans un nouveau dossier et y recopier `v2_runs/` si l'historique doit être conservé. Recréer l'environnement avec le lanceur d'installation. Ne pas copier `.venv`, `.venv-mac` ou `.venv-wsl` entre ordinateurs.

L'archive est vérifiée après extraction. La préparation exécute une installation hors ligne propre sur le Mac disponible puis les tests du moteur et du serveur local. Les fichiers d'origine sont conservés. Il reste à vérifier le lancement réel sur le PC WSL et l'environnement VPN/proxy propre à l'entreprise. La livraison n'est ni un exécutable autonome, ni une garantie de compatibilité de tous les VPN.
