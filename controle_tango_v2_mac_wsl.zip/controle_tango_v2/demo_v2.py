#!/usr/bin/env python3
"""Démo locale V2 : python demo_v2.py --port 8792."""
from __future__ import annotations

import argparse
import base64
import binascii
import copy
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import uuid
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import v2_reporting

ROOT = Path(__file__).resolve().parent
VERSION = "2.1-demo"
MAX_FILE_BYTES = 12 * 1024 * 1024
MAX_REQUEST_BYTES = 48 * 1024 * 1024
RUN_ID = re.compile(r"[0-9]{8}T[0-9]{12}Z-[0-9a-f]{8}")
ALLOWED_FILES = {
    "entree": {".txt", ".json", ".avro"}, "sortie": {".txt", ".json"},
    "mapping": {".xlsm", ".xlsx"}, "avro": {".json", ".avsc"},
    "swagger": {".yaml", ".yml", ".json"},
}


class DemoError(ValueError):
    def __init__(self, message, status=400, detail=""):
        super().__init__(message)
        self.status = status
        self.detail = detail


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, data):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


class LocalApp:
    def __init__(self, data_dir, root=ROOT):
        self.root = Path(root).resolve()
        self.data_dir = Path(data_dir).resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.run_lock = threading.Lock()

    def history(self):
        runs = []
        for path in self.data_dir.glob("*/metadata.json"):
            if not RUN_ID.fullmatch(path.parent.name):
                continue
            try:
                metadata = read_json(path)
                if metadata.get("id") == path.parent.name and (path.parent / "rapport.json").is_file():
                    runs.append(metadata)
            except (OSError, ValueError):
                continue
        return sorted(runs, key=lambda run: run.get("created_at", ""), reverse=True)[:100]

    def state(self):
        return {"version": VERSION, "busy": self.run_lock.locked(),
                "demo": {"label": "Exemple fourni", "available": (self.root / "examples_reels/audit_KAFKA.txt").is_file()},
                "history": self.history()}

    def run_folder(self, run_id):
        if not RUN_ID.fullmatch(run_id):
            raise DemoError("Exécution introuvable.", 404)
        folder = self.data_dir / run_id
        if not (folder / "rapport.json").is_file() or not (folder / "metadata.json").is_file():
            raise DemoError("Exécution introuvable.", 404)
        return folder

    def result(self, run_id):
        folder = self.run_folder(run_id)
        return {"run": read_json(folder / "metadata.json"), "report": read_json(folder / "rapport.json")}

    def decode_files(self, supplied):
        if not isinstance(supplied, dict) or set(supplied) - set(ALLOWED_FILES):
            raise DemoError("La sélection de fichiers contient une référence inconnue.")
        decoded = {}
        for key, item in supplied.items():
            if not isinstance(item, dict) or not isinstance(item.get("name"), str) or not isinstance(item.get("content_base64"), str):
                raise DemoError(f"Le fichier {key} n'est pas lisible.")
            name = item["name"].replace("\\", "/").split("/")[-1]
            suffix = Path(name).suffix.lower()
            if suffix not in ALLOWED_FILES[key]:
                raise DemoError(f"Extension non prise en charge pour {key} : {suffix or 'absente'}.")
            if len(item["content_base64"]) > (MAX_FILE_BYTES + 2) // 3 * 4:
                raise DemoError(f"Le fichier {name} dépasse la limite de 12 Mo.", 413)
            try:
                content = base64.b64decode(item["content_base64"], validate=True)
            except (ValueError, binascii.Error):
                raise DemoError(f"Le contenu du fichier {name} est invalide.") from None
            if not content or len(content) > MAX_FILE_BYTES:
                raise DemoError(f"Le fichier {name} est vide ou dépasse la limite de 12 Mo.", 413)
            decoded[key] = (name, suffix, content)
        if not {"entree", "sortie"} <= set(decoded):
            raise DemoError("Sélectionner une entrée SAE et une sortie SID pour le même événement.")
        return decoded

    def corrected_copy(self, incoming_path, outgoing_path):
        # Le moteur calcule l'attendu depuis l'entrée et la décision ISOMTI.
        import fastavro
        import controle_mapping as cm
        import tango_engine as engine
        import tango_formats as formats
        from types import SimpleNamespace
        names = {}
        schema = fastavro.parse_schema(cm.load_document(self.root / "donnees_tango/avro.json"), named_schemas=names)
        source, _ = cm.avro_catalog(schema, names)
        incoming, _ = formats.read_input(incoming_path, schema, source)
        profile = cm.load_document(self.root / "profil_tango.json")
        line = SimpleNamespace(operation="event_nature", parameters={}, source="ISOMTI", presence="required", targets=[])
        expected = engine.expected(line, incoming, profile, {})
        output = copy.deepcopy(cm.load_document(outgoing_path))
        processing = output["eventProcessingData"]
        if "IssAuthorFullEventProcessingData" in processing:
            processing["IssAuthorFullEventProcessingData"]["eventNature"] = {"string": expected}
        else:
            processing["eventNature"] = expected
        write_json(outgoing_path, output)
        return {"chemin": "eventProcessingData.eventNature", "valeur_ajoutee": expected,
                "description": "Une seule valeur a été ajoutée à une copie de la sortie pour cette démonstration. Les fichiers d'origine restent inchangés."}

    def run(self, payload):
        if not isinstance(payload, dict):
            raise DemoError("Le lancement doit décrire une sélection de fichiers.")
        mode = payload.get("mode", "demo")
        if not isinstance(mode,str) or mode not in {"demo", "demo-corrected", "custom"}:
            raise DemoError("Scénario de démonstration inconnu.")
        if payload.get("options") not in ({}, None):
            raise DemoError("Les paramètres métier de cette démo sont lus dans le profil du projet.")
        label = payload.get("label", "")
        if not isinstance(label, str):
            raise DemoError("Le libellé doit être un texte.")
        label = label.strip()[:120] or {"demo": "Exemple fourni", "demo-corrected": "Copie avec eventNature corrigé", "custom": "Contrôle de mes fichiers"}[mode]
        decoded = self.decode_files(payload.get("files", {})) if mode == "custom" else {}
        if not self.run_lock.acquire(blocking=False):
            raise DemoError("Un contrôle est déjà en cours. Attendre sa fin avant de relancer.", 409)
        try:
            now = datetime.now(timezone.utc)
            run_id = now.strftime("%Y%m%dT%H%M%S%fZ") + "-" + uuid.uuid4().hex[:8]
            folder = self.data_dir / run_id
            folder.mkdir()
            input_dir = folder / "fichiers"
            input_dir.mkdir()
            paths, source_names = {}, {}
            if mode == "custom":
                for key, (name, suffix, content) in decoded.items():
                    path = input_dir / (key + suffix)
                    path.write_bytes(content)
                    paths[key] = path
                    source_names[key] = name
            else:
                for key, name in (("entree", "audit_KAFKA.txt"), ("sortie", "Kafka_audit_sortie.txt")):
                    path = input_dir / name
                    shutil.copy2(self.root / "examples_reels" / name, path)
                    paths[key] = path
                    source_names[key] = name
            correction = self.corrected_copy(paths["entree"], paths["sortie"]) if mode == "demo-corrected" else None
            report_path = folder / "rapport.json"
            command = [sys.executable, str(self.root / "controle_tango.py"), "--rapport", str(report_path)]
            for key, path in paths.items():
                command.extend(["--" + key, str(path)])
            try:
                completed = subprocess.run(command, cwd=self.root, capture_output=True, text=True, encoding="utf-8",
                                           env={**os.environ,"PYTHONIOENCODING":"utf-8"},timeout=90,stdin=subprocess.DEVNULL)
            except subprocess.TimeoutExpired:
                raise DemoError("Le contrôle a dépassé 90 secondes.", 504, "Aucune conformité n'est déduite de cette interruption.") from None
            if completed.returncode not in {0, 1, 2, 3} or not report_path.is_file():
                raise DemoError("Le moteur n'a pas pu produire de rapport.", 500, (completed.stderr or completed.stdout)[-2000:])
            report = v2_reporting.decorate_report(read_json(report_path))
            previous = next((item for item in self.history() if item.get("mode") == "demo" and item.get("version")==VERSION), None) if mode == "demo-corrected" else None
            if previous:
                report["v2"]["comparison"] = v2_reporting.comparison_with_previous(report, self.result(previous["id"])["report"])
                report["v2"]["comparison"]["previous_run_id"] = previous["id"]
            if correction:
                report["v2"]["demo_correction"] = correction
            metadata = {"id": run_id, "created_at": now.isoformat(), "label": label, "mode": mode,
                        "status": report.get("statut", "ERREUR_CONFIGURATION"), "summary": report["v2"]["summary"],
                        "version": VERSION, "source_names": source_names}
            write_json(report_path, report)
            v2_reporting.write_html(report_path.with_suffix(".html"), report, metadata)
            v2_reporting.write_csv(report_path.with_suffix(".csv"), report)
            write_json(folder / "metadata.json", metadata)
            return {"run": metadata, "report": report}
        finally:
            self.run_lock.release()


class DemoServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, app):
        self.app = app
        super().__init__(address, DemoHandler)


class DemoHandler(BaseHTTPRequestHandler):
    server_version = "TangoLocal/2"

    def setup(self):
        super().setup()
        self.connection.settimeout(30)

    def send_content(self, content, content_type, status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(content)

    def send_json(self, value, status=200):
        self.send_content(json.dumps(value, ensure_ascii=False, allow_nan=False).encode(), "application/json; charset=utf-8", status)

    def verify_local_request(self):
        port = self.server.server_address[1]
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if self.headers.get("Host") not in hosts:
            raise DemoError("Cette démo est accessible uniquement depuis l'adresse locale affichée.", 403)
        origin = self.headers.get("Origin")
        if origin is not None and origin not in {f"http://{host}" for host in hosts}:
            raise DemoError("Origine de la requête non autorisée.", 403)

    def do_GET(self):
        try:
            self.verify_local_request()
            route = urlparse(self.path)
            if route.path == "/api/state":
                return self.send_json(self.server.app.state())
            match = re.fullmatch(r"/api/history/([^/]+)(/download)?", route.path)
            if match:
                run_id = match[1]
                if not match[2]:
                    return self.send_json(self.server.app.result(run_id))
                extension = parse_qs(route.query).get("format", ["html"])[0]
                if extension not in {"html", "csv", "json"}:
                    raise DemoError("Format d'export inconnu.")
                path = self.server.app.run_folder(run_id) / ("rapport." + extension)
                if not path.is_file():
                    raise DemoError("Cet export n'est pas disponible.", 404)
                content_type = {"html": "text/html; charset=utf-8", "csv": "text/csv; charset=utf-8", "json": "application/json; charset=utf-8"}[extension]
                return self.send_content(path.read_bytes(), content_type, filename=f"controle-{run_id}.{extension}")
            filename = {"/": "index.html", "/index.html": "index.html", "/app.js": "app.js", "/style.css": "style.css"}.get(route.path)
            if filename:
                content_type = {"index.html": "text/html; charset=utf-8", "app.js": "text/javascript; charset=utf-8", "style.css": "text/css; charset=utf-8"}[filename]
                return self.send_content((self.server.app.root / "v2_ui" / filename).read_bytes(), content_type)
            raise DemoError("Page introuvable.", 404)
        except DemoError as exc:
            self.send_json({"error": str(exc), "detail": exc.detail}, exc.status)
        except (OSError, ValueError) as exc:
            self.send_json({"error": "Impossible de lire cette ressource locale.", "detail": str(exc)}, 500)

    do_HEAD = do_GET

    def do_POST(self):
        try:
            self.verify_local_request()
            if urlparse(self.path).path != "/api/run":
                raise DemoError("Action introuvable.", 404)
            if self.headers.get_content_type() != "application/json":
                raise DemoError("La sélection doit être envoyée au format JSON.", 415)
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                raise DemoError("Taille de requête invalide.") from None
            if not 0 < length <= MAX_REQUEST_BYTES:
                raise DemoError("La sélection dépasse la taille autorisée ou est vide.", 413)
            try:
                payload = json.loads(self.rfile.read(length))
            except (ValueError, UnicodeDecodeError):
                raise DemoError("La sélection n'est pas un JSON valide.") from None
            self.send_json(self.server.app.run(payload))
        except DemoError as exc:
            self.send_json({"error": str(exc), "detail": exc.detail}, exc.status)
        except Exception as exc:
            self.send_json({"error": "Le contrôle n'a pas pu être lancé.", "detail": f"{type(exc).__name__} : {exc}"}, 500)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8792)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--data-dir", type=Path, default=ROOT / "v2_runs")
    arguments = parser.parse_args(argv)
    if not 1 <= arguments.port <= 65535:
        parser.error("Le port doit être compris entre 1 et 65535")
    app = LocalApp(arguments.data_dir)
    try:
        server = DemoServer(("127.0.0.1", arguments.port), app)
    except OSError as exc:
        print(f"Impossible d'ouvrir la démo sur le port {arguments.port} : {exc}", file=sys.stderr)
        return 2
    url = f"http://127.0.0.1:{arguments.port}"
    print(f"Démo V2 disponible : {url}\nCtrl+C pour arrêter. Historique local : {app.data_dir}", flush=True)
    if not arguments.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDémo arrêtée.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
