"""Installation macOS / WSL, proxy hérité et dépendances hors ligne de TANGO V2.

Ce module utilise uniquement la bibliothèque standard pour pouvoir créer le venv.
Les paramètres réseau ne concernent que l'installation, jamais les contrôles.
"""
from __future__ import annotations

import argparse
import configparser
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import tempfile
import venv
from email.parser import BytesParser
from pathlib import Path
from zipfile import ZipFile


ROOT = Path(__file__).resolve().parent
TARGETS = {
    "wsl-x86_64": ["manylinux2014_x86_64"],
    "mac-arm64": ["macosx_11_0_arm64"],
    "mac-x86_64": ["macosx_10_15_x86_64", "macosx_11_0_x86_64"],
}
IMPORTS = "import fastavro, openpyxl, yaml, openapi_schema_validator, jsonschema, referencing"
LOOPBACK = ("localhost", "127.0.0.1", "::1")
PROXY_KEYS = {"http_proxy", "https_proxy", "all_proxy", "no_proxy", "wsl_pac_url"}


class LocalError(Exception):
    pass


def target_name():
    machine = platform.machine().lower()
    if sys.platform == "darwin":
        if machine in {"arm64", "aarch64"}:
            return "mac-arm64"
        if machine in {"x86_64", "amd64"}:
            return "mac-x86_64"
    if sys.platform.startswith("linux") and machine in {"x86_64", "amd64"}:
        return "wsl-x86_64"
    raise LocalError("Cette livraison couvre Mac Intel/Apple Silicon et WSL Linux x86_64 avec CPython 3.12.")


def require_python():
    if sys.version_info[:2] != (3, 12) or platform.python_implementation() != "CPython":
        raise LocalError("Python 3.12 (CPython) est nécessaire. Consulter GUIDE_MAC_WSL.md.")


def environment_python(root=ROOT):
    name = ".venv-mac" if sys.platform == "darwin" else ".venv-wsl"
    return root / name / "bin" / "python"


def loopback_environment(source=None):
    result = dict(os.environ if source is None else source)
    # Conserver les exceptions de l'entreprise et les deux variantes de casse.
    items = []
    for raw in (result.get("no_proxy", ""), result.get("NO_PROXY", ""), *LOOPBACK):
        for item in raw.split(","):
            if item.strip() and item.strip() not in items:
                items.append(item.strip())
    result["NO_PROXY"] = result["no_proxy"] = ",".join(items)
    result["PYTHONIOENCODING"] = "utf-8"
    return result


def read_config(path):
    parser = configparser.ConfigParser(interpolation=None)
    if path.exists():
        try:
            with path.open(encoding="utf-8-sig") as stream:
                parser.read_file(stream)
            if set(parser.sections()) != {"reseau"} or parser.defaults():
                raise ValueError
            if set(parser["reseau"]) - {"proxy", "index_url", "certificat", "timeout"}:
                raise ValueError
        except (OSError, ValueError, configparser.Error):
            raise LocalError("Configuration réseau illisible. Reprendre reseau.exemple.ini ; les valeurs ne sont pas affichées.") from None
    section = parser["reseau"] if parser.has_section("reseau") else {}
    return {key: value.strip() for key, value in section.items()}


def network_environment(config_path, source=None):
    result = loopback_environment(source)
    config = read_config(config_path)
    proxy = config.get("proxy", "")
    index = config.get("index_url", "")
    for value, label in ((proxy, "proxy"), (index, "index_url")):
        if value and (not value.startswith(("http://", "https://")) or any(c.isspace() for c in value)):
            raise LocalError(f"Le paramètre {label} doit être une URL http:// ou https:// sans espaces.")
    if proxy:
        for key in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY", "PIP_PROXY"):
            result[key] = proxy
    if index:
        result["PIP_INDEX_URL"] = index
        # Un dépôt interne explicite remplace les index supplémentaires hérités.
        result.pop("PIP_EXTRA_INDEX_URL", None)
    cert = config.get("certificat", "")
    if cert:
        certificate = Path(os.path.expandvars(cert)).expanduser()
        if not certificate.is_absolute():
            certificate = config_path.parent / certificate
        if not certificate.is_file():
            raise LocalError("Le certificat PEM configuré est introuvable. Vérifier son chemin Mac ou Linux.")
        result["PIP_CERT"] = str(certificate.resolve())
    timeout = config.get("timeout", "") or "30"
    if not timeout.isdigit() or not 1 <= int(timeout) <= 300:
        raise LocalError("Le timeout réseau doit être un entier compris entre 1 et 300 secondes.")
    result["PIP_DEFAULT_TIMEOUT"] = timeout
    result["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    result["PIP_NO_INPUT"] = "1"
    return result


def offline_environment(source=None):
    # --no-index n'annule pas PIP_FIND_LINKS : ignorer aussi les configurations pip.
    result = {key: value for key, value in (os.environ if source is None else source).items()
              if not key.upper().startswith("PIP_") and key.lower() not in PROXY_KEYS}
    result["PIP_CONFIG_FILE"] = os.devnull
    return loopback_environment(result)


def sanitized(message, environment):
    # Ne jamais recopier les identifiants d'une URL de proxy/dépôt dans l'affichage.
    result = re.sub(r"(https?://)[^\s/@]+(?::[^\s/@]*)?@", r"\1***@", message)
    for key, value in environment.items():
        if value and ("proxy" in key.lower() or key in {"PIP_INDEX_URL", "PIP_EXTRA_INDEX_URL"}):
            result = result.replace(value, "[adresse réseau masquée]")
    return result


def run_pip(python, arguments, environment, root=ROOT):
    command = [str(python), "-m", "pip", "--disable-pip-version-check", *arguments]
    try:
        process = subprocess.Popen(command, cwd=root, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, encoding="utf-8", errors="replace")
        with process.stdout:
            for line in process.stdout:
                print(sanitized(line.rstrip(), environment), flush=True)
        code = process.wait()
    except OSError:
        raise LocalError("Impossible de démarrer pip avec ce Python. Relancer l'installation de Python 3.12 et venv.") from None
    if code:
        raise LocalError("Installation/téléchargement non terminé. Voir le message ci-dessus et le dépannage de GUIDE_MAC_WSL.md.")


def check_environment(python, root=ROOT, dependencies=True):
    if not python.is_file():
        raise LocalError("L'environnement de ce système est absent. Lancer d'abord Installer_V2_Mac.command ou Installer_V2_WSL.sh.")
    probe = "import json,sys; print(json.dumps([list(sys.version_info[:2]),sys.platform,sys.prefix]))"
    result = subprocess.run([str(python), "-c", probe], cwd=root, capture_output=True, text=True)
    try:
        version, system, prefix = json.loads(result.stdout)
        valid = result.returncode == 0 and version == [3, 12] and system == sys.platform and Path(prefix).resolve() == python.parent.parent.resolve()
    except (ValueError, TypeError):
        valid = False
    if not valid:
        raise LocalError("L'environnement Python appartient à un autre système ou à un ancien emplacement. Le renommer puis relancer l'installateur ; conserver v2_runs.")
    if dependencies:
        result = subprocess.run([str(python), "-c", IMPORTS], cwd=root, capture_output=True)
        if result.returncode:
            raise LocalError("Des dépendances manquent. Relancer l'installateur de ce système.")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_wheel_manifest(folder, target, root=ROOT):
    """Figer toutes les dépendances résolues, y compris les dépendances indirectes."""
    wheels = sorted(folder.glob("*.whl"))
    if not wheels:
        raise LocalError("Le dossier de paquets ne contient aucun fichier .whl.")
    files = {}
    locked = []
    seen = set()
    for wheel in wheels:
        with ZipFile(wheel) as archive:
            candidates = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
            if len(candidates) != 1:
                raise LocalError("Un paquet contient des métadonnées incohérentes.")
            metadata = BytesParser().parsebytes(archive.read(candidates[0]))
        name, version = metadata["Name"], metadata["Version"]
        if not name or not version or not re.fullmatch(r"[A-Za-z0-9_.-]+", name) or not re.fullmatch(r"[A-Za-z0-9_.+!-]+", version):
            raise LocalError("Nom ou version de paquet non reconnu.")
        canonical = name.lower().replace("_", "-")
        if canonical in seen:
            raise LocalError("Le dossier contient plusieurs versions d'un même paquet ; utiliser un dossier vide.")
        seen.add(canonical)
        sha = digest(wheel)
        files[wheel.name] = sha
        extra = "[format]" if canonical == "jsonschema" else ""
        locked.append(f"{name}{extra}=={version} --hash=sha256:{sha}")
    lock = folder / "requirements-hors-ligne.txt"
    lock.write_text("# Dépendances complètes pour CPython 3.12 / " + target + "\n" + "\n".join(sorted(locked)) + "\n", encoding="utf-8")
    files[lock.name] = digest(lock)
    manifest = {"cible": target, "python": "3.12", "requirements_sha256": digest(root / "requirements.txt"), "fichiers": files}
    (folder / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def verify_wheels(folder, target, root=ROOT):
    try:
        manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
        if manifest["cible"] != target or manifest["python"] != "3.12":
            raise ValueError
        if manifest["requirements_sha256"] != digest(root / "requirements.txt"):
            raise ValueError
        files = manifest["fichiers"]
        if "requirements-hors-ligne.txt" not in files or not any(name.endswith(".whl") for name in files):
            raise ValueError
        for name, expected in files.items():
            if Path(name).name != name or name not in {"requirements-hors-ligne.txt"} and not name.endswith(".whl"):
                raise ValueError
            if digest(folder / name) != expected:
                raise ValueError
        if set(path.name for path in folder.glob("*.whl")) != {name for name in files if name.endswith(".whl")}:
            raise ValueError
    except (OSError, KeyError, ValueError, TypeError, AttributeError):
        raise LocalError("Paquets hors ligne incomplets, modifiés ou prévus pour un autre système. Réextraire la livraison complète ou préparer les paquets de la bonne cible.") from None
    return folder / "requirements-hors-ligne.txt"


def install(arguments, root=ROOT):
    target = target_name()
    folder = (arguments.dossier_paquets or root / "hors_ligne" / target).resolve()
    offline = arguments.hors_ligne or not arguments.en_ligne and (folder / "manifest.json").exists()
    if offline:
        lock = verify_wheels(folder, target, root)
        environment = offline_environment()
    else:
        environment = network_environment(arguments.config)
        warn_pac(environment)
    python = environment_python(root)
    if not python.parent.parent.exists():
        print("Création de l'environnement Python local…", flush=True)
        try:
            venv.EnvBuilder(with_pip=True).create(python.parent.parent)
        except (OSError, subprocess.SubprocessError):
            raise LocalError("La création de l'environnement a échoué. Sous Ubuntu/WSL, vérifier que python3.12-venv est installé. Consulter le guide.") from None
    check_environment(python, root, dependencies=False)
    if offline:
        print("Installation hors ligne : aucun dépôt réseau n'est consulté.", flush=True)
        options = ["--no-index", "--find-links", str(folder), "--require-hashes", "-r", str(lock)]
    else:
        print("Installation en ligne avec les réglages réseau locaux.", flush=True)
        options = ["--retries", "1", "-r", str(root / "requirements.txt")]
    run_pip(python, ["install", "--no-input", "--no-cache-dir", "--only-binary=:all:", *options], environment, root)
    run_pip(python, ["check"], offline_environment(), root)
    check_environment(python, root)
    print("Installation terminée. Lancer_V2_Mac.command ou bash Lancer_V2_WSL.sh ouvre l'application locale.")


def warn_pac(environment):
    has_proxy = any(environment.get(key) for key in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY", "PIP_PROXY"))
    if environment.get("WSL_PAC_URL") and not has_proxy:
        print("Un réglage automatique PAC de Windows est détecté. pip ne lit pas ce fichier : utiliser les paquets hors ligne, un dépôt interne accessible, ou l'adresse de proxy fournie par l'IT.", flush=True)


def prepare(arguments, root=ROOT):
    target = arguments.cible or target_name()
    folder = (arguments.dossier_paquets or root / "hors_ligne" / target).resolve()
    if folder.exists() and any(folder.iterdir()):
        raise LocalError("Le dossier de destination contient déjà des fichiers. Choisir un dossier vide pour la préparation.")
    folder.mkdir(parents=True, exist_ok=True)
    environment = network_environment(arguments.config)
    warn_pac(environment)
    options = ["download", "--no-cache-dir", "--only-binary=:all:", "--implementation", "cp", "--python-version", "3.12", "--abi", "cp312", "--retries", "1"]
    for value in TARGETS[target]:
        options.extend(["--platform", value])
    options.extend(["--dest", str(folder), "-r", str(root / "requirements.txt")])
    run_pip(sys.executable, options, environment, root)
    write_wheel_manifest(folder, target, root)
    print(f"Paquets préparés pour {target}. Transférer ce dossier dans hors_ligne/{target} de la livraison cible.")


def diagnostic(arguments, root=ROOT):
    target = target_name()
    environment = network_environment(arguments.config)
    print(f"Système : {target} ; Python : {platform.python_version()}")
    print("Application : http://127.0.0.1:8792/ ; écoute limitée à cet ordinateur.")
    try:
        check_environment(environment_python(root), root)
        print("Environnement et dépendances : prêts.")
    except LocalError as exc:
        print(str(exc))
    proxies = any(environment.get(key) for key in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY", "PIP_PROXY"))
    print("Proxy dans l'environnement : " + ("présent (adresse masquée)." if proxies else "absent ; une configuration pip peut aussi s'appliquer."))
    print("PAC Windows : " + ("détecté." if environment.get("WSL_PAC_URL") else "non détecté."))
    print("Certificat pip explicite : " + ("configuré." if environment.get("PIP_CERT") else "non configuré ; certificats système selon la version de pip."))
    warn_pac(environment)
    try:
        verify_wheels((arguments.dossier_paquets or root / "hors_ligne" / target).resolve(), target, root)
        print("Dépendances hors ligne : intégrité vérifiée pour ce système.")
    except LocalError as exc:
        print(str(exc))
    if arguments.tester_reseau:
        print("Test explicite du dépôt Python : téléchargement d'un petit paquet, sans données métier.")
        with tempfile.TemporaryDirectory(prefix="tango_reseau_") as temporary:
            run_pip(sys.executable, ["download", "--no-cache-dir", "--no-deps", "--only-binary=:all:", "--timeout", "15", "--retries", "0", "--dest", temporary, "rfc3339-validator==0.1.4"], environment, root)
        print("Accès au dépôt Python : réussi.")
    else:
        print("Diagnostic local uniquement. Ajouter --tester-reseau pour vérifier l'accès au dépôt.")


def launch(arguments, root=ROOT):
    python = environment_python(root)
    check_environment(python, root)
    environment = loopback_environment()
    command = [str(python), str(root / "demo_v2.py"), "--port", str(arguments.port)]
    if arguments.no_browser or sys.platform.startswith("linux"):
        command.append("--no-browser")
    if arguments.data_dir:
        command.extend(["--data-dir", str(arguments.data_dir.expanduser().resolve())])
    print(f"Ouvrir http://127.0.0.1:{arguments.port}/ dans le navigateur de ce Mac ou de Windows.\nGarder ce terminal ouvert. Ctrl+C arrête l'application.", flush=True)
    os.chdir(root)
    os.execve(str(python), command, environment)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("installer", "lancer", "diagnostic", "preparer-hors-ligne"))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--hors-ligne", action="store_true", help="Installation sans réseau, avec les paquets de la cible")
    mode.add_argument("--en-ligne", action="store_true", help="Utiliser le proxy/dépôt réseau même si des paquets sont inclus")
    parser.add_argument("--config", type=Path, default=ROOT / "reseau.local.ini")
    parser.add_argument("--dossier-paquets", type=Path)
    parser.add_argument("--cible", choices=sorted(TARGETS))
    parser.add_argument("--tester-reseau", action="store_true")
    parser.add_argument("--port", type=int, default=8792)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--data-dir", type=Path)
    arguments = parser.parse_args(argv)
    if not 1 <= arguments.port <= 65535:
        parser.error("Le port doit être compris entre 1 et 65535")
    arguments.config = arguments.config.expanduser().resolve()
    try:
        require_python()
        {"installer": install, "lancer": launch, "diagnostic": diagnostic, "preparer-hors-ligne": prepare}[arguments.action](arguments)
    except LocalError as exc:
        print(f"\n{exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nOpération arrêtée.")
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
