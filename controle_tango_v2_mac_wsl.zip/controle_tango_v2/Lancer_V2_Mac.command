#!/bin/bash
cd "$(dirname "$0")" || exit 2
bash tools/tango_posix.sh lancer "$@"
rise_v2_exit=$?
if [ "$rise_v2_exit" -ne 0 ]; then
  if [ -t 0 ]; then read -r -p "Appuyer sur Entrée pour fermer..."; fi
fi
exit "$rise_v2_exit"
