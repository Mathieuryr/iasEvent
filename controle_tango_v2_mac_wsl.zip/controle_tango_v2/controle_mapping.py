#!/usr/bin/env python3
"""Rapprochement local Avro / Excel / Swagger et messages SAE / SID."""
from __future__ import annotations

import argparse
import base64
import csv
import json
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Any

import fastavro
import openpyxl
import yaml
from fastavro.validation import validate as validate_avro
from fastavro.validation import ValidationError as AvroValidationError
from jsonschema import Draft4Validator
from openapi_schema_validator import OAS30Validator, OAS31Validator
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT4, DRAFT202012


class ConfigurationError(ValueError):
    pass


MISSING = object()
COPY = {"copie", "copy", "direct"}
RESULT_TYPES = {
    "majuscules": {"string"}, "minuscules": {"string"}, "trim": {"string"},
    "chaine": {"string"}, "entier": {"integer"}, "nombre": {"number"},
    "decimal": {"string"}, "date_iso": {"string"}, "timestamp_iso": {"string"},
}
AVRO_TYPES = {
    "int": "integer", "long": "integer", "float": "number", "double": "number",
    "boolean": "boolean", "string": "string", "bytes": "bytes", "fixed": "bytes",
    "enum": "string", "record": "object", "map": "object", "array": "array", "null": "null",
}


def strict_json(text: str) -> Any:
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ConfigurationError(f"Clé JSON dupliquée : {key}")
            result[key] = value
        return result

    def invalid(value):
        raise ConfigurationError(f"Nombre JSON non fini : {value}")

    return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid)


class UniqueSafeLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        # Explicit duplicate keys are errors; normal YAML merge-key overrides remain supported.
        seen = set()
        for key_node, _ in node.value:
            if key_node.tag == "tag:yaml.org,2002:merge":
                continue
            key = self.construct_object(key_node, deep=False)
            if key in seen:
                raise ConfigurationError(f"Clé YAML dupliquée : {key}")
            seen.add(key)
        return super().construct_mapping(node, deep=deep)


def load_document(path: Path) -> Any:
    text = path.read_text(encoding="utf-8-sig")
    if path.suffix.lower() in {".yaml", ".yml"}:
        return yaml.load(text, Loader=UniqueSafeLoader)
    return strict_json(text)


def pointer(document: Any, ref: str) -> Any:
    if ref == "#":
        return document
    if not ref.startswith("#/"):
        raise ConfigurationError(f"Référence externe non prise en charge : {ref}. Fournir un Swagger regroupé.")
    current = document
    try:
        for token in ref[2:].split("/"):
            current = current[token.replace("~1", "/").replace("~0", "~")]
    except (KeyError, TypeError) as exc:
        raise ConfigurationError(f"Référence introuvable : {ref}") from exc
    return current


def normalize_path(value: Any) -> str:
    result = str("" if value is None else value).strip().removeprefix("$.").replace("[*]", "[]")
    if result and not re.fullmatch(r"[^.\[\]\s]+(?:\[\])*(?:\.[^.\[\]\s]+(?:\[\])*)*", result):
        raise ConfigurationError(f"Chemin non pris en charge : {value}. Exemple : paiements[].montant")
    return result


@dataclass
class Rule:
    row: int
    source: str
    target: str
    operation: str = "copie"
    params: Any = None
    tolerance: Decimal = Decimal(0)


def read_mapping(path: Path, sheet: str | None, header_row: int, columns: dict[str, str]) -> list[Rule]:
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ConfigurationError("Le mapping doit être un fichier .xlsx ou .xlsm.")
    book = openpyxl.load_workbook(path, read_only=True, data_only=False)
    try:
        if sheet is None:
            if "Mapping" in book.sheetnames:
                sheet = "Mapping"
            elif len(book.sheetnames) == 1:
                sheet = book.sheetnames[0]
            else:
                raise ConfigurationError("Plusieurs onglets : préciser --onglet.")
        if sheet not in book.sheetnames:
            raise ConfigurationError(f"Onglet introuvable : {sheet}")
        rows = book[sheet].iter_rows(min_row=header_row)
        header = next(rows, None)
        if header is None:
            raise ConfigurationError("Mapping vide.")
        names = [str(cell.value or "").strip().casefold() for cell in header]
        indices = {}
        for role, name in columns.items():
            matches = [i for i, label in enumerate(names) if label == name.casefold()]
            if len(matches) > 1:
                raise ConfigurationError(f"En-tête dupliqué : {name}")
            if not matches and role in {"source", "target"}:
                raise ConfigurationError(f"Colonne absente : {name}. Adapter --colonne-{role}.")
            indices[role] = matches[0] if matches else None
        rules = []
        for number, row in enumerate(rows, header_row + 1):
            values = {}
            for role, index in indices.items():
                cell = row[index] if index is not None and index < len(row) else None
                if cell is not None and cell.data_type == "f":
                    raise ConfigurationError(f"Ligne {number} : remplacer la formule Excel par sa règle explicite.")
                values[role] = cell.value if cell is not None else None
            if all(v is None or v == "" for v in values.values()):
                continue
            operation = str(values["operation"] or "copie").strip().casefold()
            params = values["params"]
            if operation == "constante" and (params is None or params == ""):
                raise ConfigurationError(f"Ligne {number} : valeur constante manquante ; écrire null explicitement si nécessaire.")
            if params is not None and params != "":
                try:
                    params = strict_json(str(params))
                except (ValueError, TypeError) as exc:
                    raise ConfigurationError(f"Ligne {number} : parametres doit contenir du JSON valide : {exc}") from exc
            else:
                params = None
            try:
                tolerance = Decimal(str(values["tolerance"] or 0))
                if not tolerance.is_finite() or tolerance < 0:
                    raise ValueError()
            except (InvalidOperation, ValueError) as exc:
                raise ConfigurationError(f"Ligne {number} : tolérance numérique positive ou nulle requise.") from exc
            rule = Rule(number, normalize_path(values["source"]), normalize_path(values["target"]), operation, params, tolerance)
            if not rule.target or (not rule.source and operation != "constante"):
                raise ConfigurationError(f"Ligne {number} : source/cible manquante (source vide permise pour constante).")
            validate_rule(rule)
            rules.append(rule)
        if not rules:
            raise ConfigurationError("Aucune règle dans le mapping.")
        return rules
    finally:
        book.close()


def validate_rule(rule: Rule):
    params, op = rule.params, rule.operation
    if op == "dictionnaire" and (not isinstance(params, dict) or not params):
        raise ConfigurationError(f"Ligne {rule.row} : dictionnaire requiert un objet JSON non vide.")
    if op == "decimal" and (not isinstance(params, dict) or type(params.get("decimales")) is not int or not 0 <= params["decimales"] <= 18 or params.get("arrondi", "ROUND_HALF_UP") != "ROUND_HALF_UP"):
        raise ConfigurationError(f"Ligne {rule.row} : decimal requiert decimales (0 à 18) ; seul ROUND_HALF_UP est pris en charge.")
    if op == "date_iso" and (not isinstance(params, dict) or not isinstance(params.get("format"), str) or not params["format"]):
        raise ConfigurationError(f"Ligne {rule.row} : date_iso requiert un format de date explicite.")
    if op == "timestamp_iso" and (not isinstance(params, dict) or params.get("unite") not in {"secondes", "millisecondes"}):
        raise ConfigurationError(f"Ligne {rule.row} : timestamp_iso requiert une unité explicite.")
    if op == "constante" and "[]" in rule.target:
        raise ConfigurationError(f"Ligne {rule.row} : une constante par élément de tableau nécessite une règle dédiée.")


@dataclass
class Field:
    types: set[str] = field(default_factory=set)
    required: bool = False
    enum: list | None = None


def avro_catalog(schema: Any, names: dict) -> tuple[dict[str, Field], list[str]]:
    result, limits = {}, []

    def domain(node):
        if isinstance(node, str) and node in names:
            return domain(names[node])
        if node == "null":
            return [None]
        if isinstance(node, dict) and node.get("type") == "enum":
            return list(node["symbols"])
        if isinstance(node, list):
            domains = [domain(branch) for branch in node]
            return None if any(item is None for item in domains) else [value for item in domains for value in item]
        return None

    def visit(node, path, required, stack=()):
        if isinstance(node, list):
            for branch in node:
                visit(branch, path, required, stack)
            result[path].enum = domain(node)
            # A child of a union may be absent in another branch.
            if len(node) > 1:
                for key, value in result.items():
                    if key.startswith(path + ".") or key.startswith(path + "[]"):
                        value.required = False
            return
        if isinstance(node, str):
            if node in names:
                visit(names[node], path, required, stack)
                return
            kind, details = node, {}
        else:
            kind, details = node["type"], node
        if isinstance(kind, (dict, list)):
            visit(kind, path, required, stack)
            return
        if kind in names:
            visit(names[kind], path, required, stack)
            return
        if kind not in AVRO_TYPES:
            raise ConfigurationError(f"Type Avro inconnu : {kind}")
        entry = result.setdefault(path, Field(required=required))
        entry.types.add(AVRO_TYPES[kind])
        if kind == "enum":
            entry.enum = list(details["symbols"]) if entry.enum is None else list(set(entry.enum) | set(details["symbols"]))
        if kind == "record":
            name = details["name"]
            if name in stack:
                limits.append(f"Récursion Avro à {path or '$'} : couverture des descendants non exhaustive.")
                return
            for child in details["fields"]:
                visit(child["type"], f"{path}.{child['name']}".lstrip("."), required, stack + (name,))
        elif kind == "array":
            visit(details["items"], path + "[]", required, stack)
        elif kind == "map":
            limits.append(f"Map Avro à {path} : clés dynamiques à contrôler par une règle dédiée.")

    visit(schema, "", True)
    return result, limits


def swagger_catalog(document: dict, schema: Any) -> tuple[dict[str, Field], list[str]]:
    result, limits = {}, []
    version31 = str(document.get("openapi", "")).startswith("3.1.")

    def visit(node, path, required, refs=()):
        if not isinstance(node, dict):
            limits.append(f"Schéma libre/booléen à {path or '$'} : contrôle structurel incomplet.")
            return
        if "$ref" in node:
            ref = node["$ref"]
            if ref in refs:
                limits.append(f"Récursion Swagger à {path or '$'} : couverture des descendants non exhaustive.")
                return
            visit(pointer(document, ref), path, required, refs + (ref,))
            annotations = {"$ref", "description", "title", "deprecated", "example", "examples", "$comment", "summary"}
            constraints = {key for key in node if key not in annotations and not key.startswith("x-")}
            if version31 and constraints:
                limits.append(f"Contraintes voisines de $ref à {path or '$'} : vérifier leur combinaison.")
            return
        for composition in ("oneOf", "anyOf", "allOf"):
            if composition in node:
                # Do not flatten mutually exclusive/overlapping branches into a fake contract.
                limits.append(f"{composition} à {path or '$'} : structure à vérifier ; validation des valeurs conservée.")
                return
        kind = node.get("type")
        if kind is None:
            kind = "object" if "properties" in node else "array" if "items" in node else None
        types = set(kind if isinstance(kind, list) else [kind]) if kind else set()
        if node.get("nullable") is True:
            types.add("null")
        if not types:
            limits.append(f"Type non explicite à {path or '$'}.")
        result[path] = Field(types, required, node.get("enum"))
        if "object" in types:
            for name, child in node.get("properties", {}).items():
                visit(child, f"{path}.{name}".lstrip("."), required and name in node.get("required", []) and "null" not in types, refs)
            if isinstance(node.get("additionalProperties"), dict):
                limits.append(f"Propriétés dynamiques à {path or '$'} : couverture non exhaustive.")
        if "array" in types:
            visit(node.get("items", {}), path + "[]", required, refs)

    visit(schema, "", True)
    return result, limits


def json_type(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, (float, Decimal)):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "inconnu"


def extract(message: Any, path: str) -> Any:
    parts = path.replace("[]", ".[]").split(".")

    def walk(value, remaining):
        if not remaining:
            return value
        part, *tail = remaining
        if part == "[]":
            return [walk(item, tail) for item in value] if isinstance(value, list) else MISSING
        if not isinstance(value, dict) or part not in value:
            return MISSING
        return walk(value[part], tail)

    return walk(message, parts)


def transform(value: Any, rule: Rule) -> Any:
    op, params = rule.operation, rule.params
    if op == "constante":
        return params
    if value is MISSING:
        return MISSING
    if isinstance(value, list):
        return [transform(item, rule) for item in value]
    if op in COPY:
        return value
    if op in {"majuscules", "minuscules", "trim"}:
        if not isinstance(value, str):
            raise ValueError(f"{op} attend une chaîne")
        return {"majuscules": str.upper, "minuscules": str.lower, "trim": str.strip}[op](value)
    if op == "chaine":
        if isinstance(value, (dict, bool)) or value is None:
            raise ValueError("chaine attend une chaîne ou un nombre ; déclarer les autres conversions explicitement")
        return str(value)
    if op in {"entier", "nombre", "decimal"}:
        if isinstance(value, bool) or value is None:
            raise ValueError("Valeur numérique attendue")
        number = Decimal(str(value))
        if not number.is_finite():
            raise ValueError("Valeur numérique non finie")
        if op == "entier":
            if number != number.to_integral_value():
                raise ValueError("Conversion entier avec perte de décimales interdite")
            return int(number)
        if op == "nombre":
            return number
        if not isinstance(params, dict) or type(params.get("decimales")) is not int or not 0 <= params["decimales"] <= 18:
            raise ValueError('decimal requiert {"decimales": 2} (0 à 18)')
        if params.get("arrondi", "ROUND_HALF_UP") != "ROUND_HALF_UP":
            raise ValueError("Seul ROUND_HALF_UP est pris en charge")
        return format(number.quantize(Decimal(1).scaleb(-params["decimales"]), rounding=ROUND_HALF_UP), "f")
    if op == "dictionnaire":
        if not isinstance(params, dict) or str(value) not in params:
            raise ValueError(f"Valeur sans correspondance dans le dictionnaire : {value!r}")
        return params[str(value)]
    if op == "date_iso":
        if isinstance(value, (date, datetime)):
            return value.date().isoformat() if isinstance(value, datetime) else value.isoformat()
        if not isinstance(params, dict) or "format" not in params:
            raise ValueError('date_iso requiert {"format": "%d/%m/%Y"}')
        return datetime.strptime(value, params["format"]).date().isoformat()
    if op == "timestamp_iso":
        if isinstance(value, datetime):
            moment = value
        else:
            unit = params.get("unite") if isinstance(params, dict) else None
            if unit not in {"secondes", "millisecondes"}:
                raise ValueError('timestamp_iso requiert unite = secondes ou millisecondes')
            moment = datetime.fromtimestamp(float(value) / (1000 if unit == "millisecondes" else 1), timezone.utc)
        if moment.tzinfo is None:
            raise ValueError("Le timestamp doit préciser son fuseau")
        return moment.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    raise NotImplementedError(f"Règle non automatisée : {op}")


def differences(expected: Any, actual: Any, tolerance: Decimal, path: str = "") -> list[dict]:
    if expected is MISSING or actual is MISSING:
        return [{"chemin": path, "attendu": visible(expected), "obtenu": visible(actual), "motif": "champ absent"}]
    if isinstance(expected, list) and isinstance(actual, list):
        if len(expected) != len(actual):
            return [{"chemin": path, "attendu": len(expected), "obtenu": len(actual), "motif": "taille de tableau"}]
        return [issue for i, (left, right) in enumerate(zip(expected, actual)) for issue in differences(left, right, tolerance, f"{path}[{i}]")]
    if isinstance(expected, dict) and isinstance(actual, dict):
        return [issue for key in sorted(set(expected) | set(actual)) for issue in differences(expected.get(key, MISSING), actual.get(key, MISSING), tolerance, f"{path}.{key}".lstrip("."))]
    numeric = lambda x: isinstance(x, (int, float, Decimal)) and not isinstance(x, bool)
    if numeric(expected) and numeric(actual):
        equal = abs(Decimal(str(expected)) - Decimal(str(actual))) <= tolerance
    else:
        equal = type(expected) is type(actual) and expected == actual
    return [] if equal else [{"chemin": path, "attendu": visible(expected), "obtenu": visible(actual), "motif": "valeur ou type différent"}]


def visible(value):
    if value is MISSING:
        return {"absent": True}
    if isinstance(value, (Decimal, date, datetime)):
        return str(value)
    if isinstance(value, bytes):
        return {"type": "bytes", "base64": base64.b64encode(value).decode("ascii")}
    if value is None or isinstance(value, (str, int, float, bool, dict, list)):
        return value
    return {"type": type(value).__name__, "representation": str(value)}


class Audit:
    def __init__(self):
        self.findings = []
        self.coverage = {}

    def add(self, scope, status, code, detail, rule=None, **extra):
        self.findings.append({"niveau": scope, "statut": status, "code": code,
                              "ligne_excel": rule.row if rule else None,
                              "source": rule.source if rule else "", "cible": rule.target if rule else "",
                              "detail": detail, **extra})

    def structures(self, source, target, rules, source_limits=(), target_limits=()):
        leaves = lambda fields: {path for path, item in fields.items() if path and not item.types & {"object", "array"}}
        source_leaves, target_leaves = leaves(source), leaves(target)
        self.coverage = {"sources_non_mappees": sorted(source_leaves - {rule.source for rule in rules}),
                         "cibles_non_mappees": sorted(target_leaves - {rule.target for rule in rules}),
                         "note": "Les champs non mappés restent hors comparaison des valeurs ; les cibles obligatoires non mappées sont des erreurs."}
        for detail in (*source_limits, *target_limits):
            self.add("structure", "A_VERIFIER", "STRUCTURE_COMPLEXE", detail)
        seen = set()
        for rule in rules:
            before = len(self.findings)
            if rule.target in seen:
                self.add("structure", "ERREUR", "CIBLE_DUPLIQUEE", "Plusieurs lignes alimentent la même cible ; préciser une règle d'agrégation/condition.", rule)
            seen.add(rule.target)
            src, dst = source.get(rule.source), target.get(rule.target)
            if dst is None:
                self.add("structure", "A_VERIFIER" if target_limits else "ERREUR", "CIBLE_ABSENTE", "Cible non retrouvée dans le modèle Swagger sélectionné.", rule)
            if rule.operation != "constante" and src is None:
                self.add("structure", "A_VERIFIER" if source_limits else "ERREUR", "SOURCE_ABSENTE", "Source non retrouvée dans le schéma Avro.", rule)
            predicted = None
            if rule.operation in COPY:
                predicted = src.types if src else None
            elif rule.operation == "constante":
                predicted = {json_type(rule.params)}
            elif rule.operation == "dictionnaire":
                if not isinstance(rule.params, dict) or not rule.params:
                    raise ConfigurationError(f"Ligne {rule.row} : dictionnaire requiert un objet JSON non vide.")
                predicted = {json_type(v) for v in rule.params.values()}
                if src and src.enum is not None:
                    absent = [x for x in src.enum if str(x) not in rule.params]
                    if absent:
                        self.add("structure", "ERREUR", "DICTIONNAIRE_INCOMPLET", f"Codes Avro sans correspondance : {absent}", rule)
            else:
                predicted = RESULT_TYPES.get(rule.operation)
                if predicted is None:
                    self.add("structure", "A_VERIFIER", "REGLE_NON_AUTOMATISEE", f"Règle à implémenter : {rule.operation}", rule)
            if rule.operation != "constante" and rule.source.count("[]") != rule.target.count("[]"):
                self.add("structure", "A_VERIFIER", "CARDINALITE", "Nombre de niveaux de tableaux différent : agrégation/éclatement à préciser.", rule)
            if predicted and dst and dst.types:
                accepted = dst.types | ({"integer"} if "number" in dst.types else set())
                if not predicted <= accepted:
                    self.add("structure", "ERREUR", "TYPE_INCOMPATIBLE", f"Type produit {sorted(predicted)} ; cible {sorted(dst.types)}.", rule)
                if predicted & {"array", "object"}:
                    self.add("structure", "A_VERIFIER", "CONTENEUR", "Décomposer le mapping en champs élémentaires pour vérifier tous les descendants.", rule)
                if dst.enum is not None:
                    values = ([rule.params] if rule.operation == "constante" else list(rule.params.values()) if rule.operation == "dictionnaire" else src.enum if src and rule.operation in COPY else None)
                    if values is None:
                        self.add("structure", "A_VERIFIER", "ENUM_NON_PROUVEE", "La source ne garantit pas les valeurs autorisées par l'enum cible.", rule)
                    elif any(value not in dst.enum for value in values):
                        self.add("structure", "ERREUR", "ENUM_INCOMPATIBLE", f"Des valeurs produites sont hors de l'enum cible {dst.enum}.", rule)
                if dst.required and src and not src.required:
                    self.add("structure", "A_VERIFIER", "PRESENCE_NON_GARANTIE", "Une source conditionnelle alimente une cible obligatoire.", rule)
            if len(self.findings) == before:
                self.add("structure", "OK", "CHAMPS_ET_TYPES", "Champs présents et types compatibles avec la règle déclarée.", rule)
        for path, entry in target.items():
            if not path or not entry.required or entry.types & {"object", "array"}:
                continue
            if path not in seen:
                self.add("structure", "ERREUR", "CIBLE_OBLIGATOIRE_NON_MAPPEE", f"Champ cible obligatoire sans règle : {path}", cible=path)

    def values(self, message_in, message_out, rules):
        for rule in rules:
            try:
                if rule.operation != "constante" and rule.source.count("[]") != rule.target.count("[]"):
                    self.add("valeurs", "A_VERIFIER", "CARDINALITE", "Comparaison suspendue : appariement des tableaux à préciser.", rule)
                    continue
                expected = transform(extract(message_in, rule.source) if rule.source else None, rule)
                actual = extract(message_out, rule.target)
                issues = differences(expected, actual, rule.tolerance, rule.target)
                if issues:
                    for issue in issues:
                        self.add("valeurs", "ERREUR", "ECART_MAPPING", issue.pop("motif"), rule, **issue)
                else:
                    self.add("valeurs", "OK", "VALEUR_CONFORME", "Valeur conforme à la règle et à la tolérance déclarées.", rule)
            except NotImplementedError as exc:
                self.add("valeurs", "A_VERIFIER", "REGLE_NON_AUTOMATISEE", str(exc), rule)
            except (ValueError, TypeError, ArithmeticError, OverflowError) as exc:
                self.add("valeurs", "ERREUR", "TRANSFORMATION_IMPOSSIBLE", str(exc), rule)

    def result(self, mode, inputs):
        counts = Counter(item["statut"] for item in self.findings)
        code = 1 if counts["ERREUR"] else 3 if counts["A_VERIFIER"] else 0
        return code, {"statut": {0: "CONFORME_AUX_CONTROLES_EXECUTES", 1: "ECARTS_DETECTES", 3: "VERIFICATION_INCOMPLETE"}[code],
                      "mode": mode, "fichiers": inputs,
                      "couverture": self.coverage,
                      "portee": {"structure": "Champs, types, enums, doublons et couverture des cibles obligatoires.",
                                 "valeurs": "Validation Avro/Swagger et comparaison des champs mappés, si les deux messages sont fournis.",
                                 "limites": "Les contraintes pattern/longueur/bornes ne sont pas prouvées pour toutes les entrées possibles. Les règles métier non implémentées restent A_VERIFIER. Pas de certification ISO 20022."},
                      "compteurs": {key: counts[key] for key in ("OK", "ERREUR", "A_VERIFIER")}, "controles": self.findings}


def make_output_validator(document, ref):
    if document.get("swagger") == "2.0":
        cls, specification = Draft4Validator, DRAFT4
    elif str(document.get("openapi", "")).startswith("3.0."):
        cls, specification = OAS30Validator, DRAFT4
    elif str(document.get("openapi", "")).startswith("3.1."):
        cls, specification = OAS31Validator, DRAFT202012
    else:
        raise ConfigurationError("Versions acceptées : Swagger 2.0, OpenAPI 3.0 et 3.1.")
    selected = pointer(document, ref)
    if not isinstance(selected, (dict, bool)):
        raise ConfigurationError("--schema-sortie doit désigner un schéma, pas une opération ou un message d'exemple.")
    cls.check_schema(selected)
    registry = Registry().with_resource("urn:sae-sid:swagger", Resource.from_contents(document, default_specification=specification))
    wrapper = {"$ref": "urn:sae-sid:swagger" + ref}
    return cls(wrapper, registry=registry, format_checker=cls.FORMAT_CHECKER), selected


def read_input(path: Path, schema):
    if path.suffix.lower() == ".avro":
        with path.open("rb") as stream:
            records = fastavro.reader(stream, reader_schema=schema)
            first = next(records, MISSING)
            if first is MISSING or next(records, MISSING) is not MISSING:
                raise ConfigurationError("Fournir un fichier Avro contenant exactement un événement par exécution.")
            return first
    if path.suffix.lower() != ".json":
        raise ConfigurationError("Entrée : JSON décodé ou fichier conteneur .avro. Un export Kafka brut doit d'abord être décodé.")
    return load_document(path)


def write_report(path: Path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=visible, allow_nan=False) + "\n", encoding="utf-8")
    with path.with_suffix(".csv").open("w", encoding="utf-8-sig", newline="") as stream:
        columns = ["niveau", "statut", "code", "ligne_excel", "source", "cible", "detail", "chemin", "attendu", "obtenu"]
        writer = csv.DictWriter(stream, columns, extrasaction="ignore", delimiter=";")
        writer.writeheader()
        for item in report.get("controles", []):
            # Prevent Excel from evaluating a source value as a formula when opening the report.
            safe = {key: json.dumps(value, ensure_ascii=False, default=visible) if isinstance(value, (dict, list)) else value for key, value in item.items()}
            writer.writerow({key: "'" + value if isinstance(value, str) and value.startswith(("=", "+", "-", "@")) else value for key, value in safe.items()})


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--avro", type=Path, required=True, help="Schéma .avsc")
    parser.add_argument("--mapping", type=Path, required=True, help="Mapping Excel .xlsx")
    parser.add_argument("--swagger", type=Path, required=True, help="Swagger/OpenAPI JSON ou YAML")
    parser.add_argument("--schema-sortie", required=True, help="Ex. #/components/schemas/EvenementSID")
    parser.add_argument("--entree", type=Path, help="Un événement SAE JSON ou conteneur Avro à un enregistrement")
    parser.add_argument("--sortie", type=Path, help="Message SID JSON correspondant")
    parser.add_argument("--onglet")
    parser.add_argument("--ligne-entete", type=int, default=1)
    for role, name in [("source", "source"), ("target", "cible"), ("operation", "regle"), ("params", "parametres"), ("tolerance", "tolerance")]:
        parser.add_argument(f"--colonne-{name}", dest=f"colonne_{role}", default=name)
    parser.add_argument("--rapport", type=Path, default=Path("rapport.json"))
    args = parser.parse_args(argv)
    if bool(args.entree) != bool(args.sortie):
        parser.error("--entree et --sortie doivent être fournis ensemble.")
    if args.ligne_entete < 1:
        parser.error("--ligne-entete doit être >= 1.")
    if args.rapport.suffix.lower() != ".json":
        parser.error("--rapport doit porter l'extension .json (le CSV est généré à côté).")
    inputs = [args.avro, args.mapping, args.swagger, args.entree, args.sortie]
    if any(p and p.resolve() in {args.rapport.resolve(), args.rapport.with_suffix('.csv').resolve()} for p in inputs):
        parser.error("Le rapport ne peut pas écraser un fichier d'entrée.")
    return args


def main(argv=None):
    args = arguments(argv)
    try:
        names = {}
        avro = fastavro.parse_schema(load_document(args.avro), named_schemas=names)
        swagger = load_document(args.swagger)
        validator, selected = make_output_validator(swagger, args.schema_sortie)
        rules = read_mapping(args.mapping, args.onglet, args.ligne_entete, {role: getattr(args, f"colonne_{role}") for role in ("source", "target", "operation", "params", "tolerance")})
        source, source_limits = avro_catalog(avro, names)
        target, target_limits = swagger_catalog(swagger, selected)
        audit = Audit()
        audit.structures(source, target, rules, source_limits, target_limits)
        if args.entree:
            message_in = read_input(args.entree, avro)
            if args.sortie.suffix.lower() != ".json":
                raise ConfigurationError("Sortie prise en charge : JSON. Un message ISO XML nécessite un adaptateur et son XSD.")
            message_out = load_document(args.sortie)
            try:
                validate_avro(message_in, avro, strict=True)
                audit.add("valeurs", "OK", "ENTREE_AVRO", "Message d'entrée valide selon le schéma Avro.")
            except (AvroValidationError, ValueError, TypeError) as exc:
                audit.add("valeurs", "ERREUR", "ENTREE_AVRO_INVALIDE", str(exc))
            errors = list(validator.iter_errors(message_out))
            for error in errors:
                audit.add("valeurs", "ERREUR", "SORTIE_SWAGGER_INVALIDE", error.message, chemin=".".join(map(str, error.absolute_path)))
            if not errors:
                audit.add("valeurs", "OK", "SORTIE_SWAGGER", "Message de sortie valide selon le modèle Swagger sélectionné.")
            audit.values(message_in, message_out, rules)
        code, report = audit.result("structures_et_valeurs" if args.entree else "structures", {key: str(getattr(args, key)) for key in ("avro", "mapping", "swagger", "entree", "sortie") if getattr(args, key)})
        write_report(args.rapport, report)
        print(f"{report['statut']} : {report['compteurs']}\nRapports : {args.rapport} et {args.rapport.with_suffix('.csv')}")
        return code
    except Exception as exc:
        # Unreadable files, unresolved references and invalid schemas must never yield a PASS.
        report = {"statut": "ERREUR_CONFIGURATION", "detail": f"{type(exc).__name__} : {exc}", "controles": []}
        try:
            write_report(args.rapport, report)
        except OSError:
            pass
        print(report["detail"], file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
