"""Données de lecture côte à côte, sans intervenir dans les décisions d'audit.

Les valeurs d'entrée sont celles du message normalisé, avant transformation.
L'attendu reste distinct de la sortie réellement reçue.
"""
from __future__ import annotations

import controle_mapping as cm
import tango_engine as engine
import tango_presence as presence


def serializable(value):
    if isinstance(value, dict):
        return {key: serializable(child) for key, child in value.items()}
    if isinstance(value, list):
        return [serializable(child) for child in value]
    return cm.visible(value)


def datum(path, value=cm.MISSING, *, state=None):
    state = state or ("absent" if value is cm.MISSING else "null" if value is None else "present")
    result = {"path": path, "state": state}
    if state in {"present", "null"}:
        result["value"] = serializable(value)
    return result


def extract_entries(message, path):
    """Extraire un chemin documenté en conservant les indices des occurrences."""
    if not path:
        return []
    parts = path.replace("[]", ".[]").split(".")

    def walk(value, remaining, concrete):
        if not remaining:
            return [datum(concrete, value)]
        head, *tail = remaining
        if head == "[]":
            if not isinstance(value, list):
                return [datum(concrete + "[]" + ("." + ".".join(tail) if tail else ""), value if value is None else cm.MISSING)]
            if not value:
                return []
            return [entry for i, child in enumerate(value) for entry in walk(child, tail, f"{concrete}[{i}]")]
        next_path = concrete + ("." if concrete else "") + head
        child = value.get(head, cm.MISSING) if isinstance(value, dict) else cm.MISSING
        return walk(child, tail, next_path)

    return walk(message, parts, "")


def _primary_source_entries(line, incoming, profile):
    op, params = line.operation, line.parameters
    if op == "event_nature":
        path = profile.get("decisions", {}).get("event_nature_source", "")
        return extract_entries(incoming, path) if path in {"ISOMTI", "MTI"} else []
    if op == "minimum_disponible":
        return [entry for path in params.get("sources", []) for entry in extract_entries(incoming, path)]
    if op in {"limites", "controles_emetteur"}:
        selection = params.get("_selection", {})
        sources = selection.get("sources", {}) if op == "controles_emetteur" else {line.source: selection.get("fields", [])}
        result = []
        for path, fields in sources.items():
            items = cm.extract(incoming, path)
            if not isinstance(items, list):
                result.extend(extract_entries(incoming, path))
                continue
            for index, item in enumerate(items):
                if not isinstance(item, dict):
                    result.append(datum(f"{path}[{index}]", item))
                    continue
                if op == "limites" and item.get("limitId") not in engine.LIMIT_CODES:
                    continue
                names = list(dict.fromkeys(("resultCode" if field == "responseCode" else "controlName")
                                           if op == "controles_emetteur" else engine.LIMIT_SOURCES[field]
                                           for field in fields))
                for name in names:
                    value = item.get(name, cm.MISSING)
                    if presence.has_data(value):
                        result.append(datum(f"{path}[{index}].{name}", value))
        return result
    if op in {"groupe_montant", "minimum_autorisable"}:
        items = cm.extract(incoming, line.source)
        if not isinstance(items, list):
            return extract_entries(incoming, line.source)
        result = []
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            if op == "groupe_montant":
                if item.get("amountType") != params.get("code"):
                    continue
                names = ("value", "currencyCode")
            else:
                if item.get("limitId") not in {300, 301, 302}:
                    continue
                names = ("minTransAmt",)
            result.extend(datum(f"{line.source}[{i}].{name}", item.get(name, cm.MISSING)) for name in names)
            if op == "minimum_autorisable":
                break
        return result
    return extract_entries(incoming, line.source)



def source_entries(line, incoming, profile):
    result = _primary_source_entries(line, incoming, profile)
    if not any(entry["state"] == "present" for entry in result):
        return result
    currency_path = None
    if line.operation == "montant":
        default = "transCurrencyCode" if line.targets and line.targets[0].startswith("transaction.authorisedAmount.") else "billingCurrency" if "billing" in line.source.casefold() else "currency"
        currency_path = profile.get("monnaie", {}).get("devises_par_source", {}).get(line.source, default)
    elif line.operation in {"minimum_disponible", "minimum_autorisable"}:
        currency_path = "currency"
    elif line.operation == "limites" and any(entry["path"].endswith((".maxTotalAmt", ".newTotalAmt")) for entry in result):
        currency_path = "currency"
    if currency_path and currency_path not in {entry["path"] for entry in result}:
        result.extend(extract_entries(incoming, currency_path))
    return result


def _project(actual, template):
    if isinstance(actual, dict) and isinstance(template, dict):
        return {key: _project(actual[key], value) for key, value in template.items()
                if not engine.absent(value) and key in actual}
    return actual


def _selected_outputs(line, incoming, outgoing, expected):
    """Même recherche sans ordre que le moteur, sans afficher les extras de sortie.

    En l'absence d'un appariement certain, la vue ne prétend pas identifier une
    occurrence : elle indique explicitement l'ambiguïté.
    """
    path = line.targets[0]
    actual = cm.extract(outgoing, path)
    if not isinstance(actual, list):
        return [datum(path, actual)], ""
    assertions = presence.group_records(line, incoming)
    known = isinstance(expected, engine.SelectedRecords)
    wanted = expected if known else assertions
    candidates = []
    for index, (value, identity) in enumerate(zip(wanted, wanted.identities)):
        fields = wanted.masks[index]
        compatible = [j for j, item in enumerate(actual) if engine.matches_identity(item, identity)]
        if known:
            compatible = [j for j in compatible if not engine.input_differences(
                value, {field: actual[j][field] for field in fields if field in actual[j]}, money_fields=wanted.money_fields)]
        candidates.append(compatible)
    matched = {}

    def assign(index, visited):
        for j in candidates[index]:
            if j in visited:
                continue
            visited.add(j)
            if j not in matched or assign(matched[j], visited):
                matched[j] = index
                return True
        return False

    # With a pending transformation only a unique identity match proves routing.
    if known:
        for i in range(len(wanted)):
            assign(i, set())
    else:
        for i, options in enumerate(candidates):
            if len(options) == 1 and options[0] not in matched:
                matched[options[0]] = i
    assignment = {i: j for j, i in matched.items()}
    used = set(matched)
    ambiguous = False
    diagnostic = False
    entries = []
    for i, (value, fields, identity) in enumerate(zip(wanted, wanted.masks, wanted.identities)):
        j = assignment.get(i)
        if j is None:
            available = [index for index, item in enumerate(actual) if index not in used and engine.matches_identity(item, identity)]
            # A unique identity candidate may contain the very missing/wrong value.
            if len(available) == 1:
                j = available[0]
                diagnostic |= not identity or any(key not in actual[j] for key in identity)
            elif known and available:
                costs = {index: len(engine.input_differences(value, {field: actual[index][field] for field in fields if field in actual[index]}, money_fields=wanted.money_fields)) for index in available}
                best = min(costs.values())
                closest = [index for index, cost in costs.items() if cost == best]
                if len(closest) == 1:
                    j = closest[0]
                    diagnostic = True
            if j is None:
                state = "unavailable" if available else "absent"
                ambiguous |= bool(available)
                identity_text = ", ".join(f"{key}={val}" for key, val in identity.items()) or f"occurrence source {i + 1}"
                entries.extend(datum(f"{path}[{identity_text}].{field}", state=state) for field in fields)
                continue
        used.add(j)
        if not known and (not identity or any(key not in actual[j] for key in identity)):
            diagnostic = True
        for field in fields:
            actual_value = actual[j].get(field, cm.MISSING)
            template = value.get(field) if known else None
            entries.append(datum(f"{path}[{j}].{field}", _project(actual_value, template) if known else actual_value))
    note = "Occurrences retrouvées sans imposer l’ordre des listes ; les autres occurrences de sortie ne sont pas affichées."
    if diagnostic:
        note += " Un rapprochement par valeur ou sans identifiant complet est présenté comme candidat de diagnostic ; son appariement reste à confirmer."
    if ambiguous:
        note += " Certaines correspondances ne peuvent pas être identifiées de façon univoque ; leurs valeurs de sortie restent indisponibles."
    return entries, note


def output_entries(line, incoming, outgoing, headers, expected):
    if not line.targets:
        return [], "La cible de sortie reste à préciser."
    target = line.targets[0]
    if line.location == "headers":
        if headers is None:
            return [datum(target, state="unavailable")], "Les en-têtes de sortie n’ont pas été fournis."
        lowered = {key.casefold(): value for key, value in headers.items()}
        return [datum(target, lowered.get(target.casefold(), cm.MISSING))], ""
    if line.operation in {"limites", "controles_emetteur"}:
        return _selected_outputs(line, incoming, outgoing, expected)
    if line.operation == "score":
        items = cm.extract(outgoing, "riskScoringList")
        if not isinstance(items, list):
            return [datum("riskScoringList", items)], ""
        matches = [(i, item) for i, item in enumerate(items) if isinstance(item, dict) and item.get("serviceId") == line.parameters.get("code")]
        return ([datum(f"riskScoringList[{i}].serviceData", item.get("serviceData", cm.MISSING)) for i, item in matches]
                or [datum(f"riskScoringList[serviceId={line.parameters.get('code')}].serviceData")]), ""
    entries = extract_entries(outgoing, target)
    if not entries:
        entries = [datum(target, [])] if "[]" in target else [datum(target)]
    if isinstance(expected, dict):
        entries = [datum(entry["path"], _project(entry["value"], expected)) if entry["state"] == "present" else entry for entry in entries]
    note = ""
    if "[]" in line.source or "[]" in target or isinstance(expected, list):
        note = "Vue des valeurs du champ mappé. Les positions affichées sont celles des fichiers ; elles n’établissent pas un appariement par ordre."
    return entries, note


def build(line, incoming, outgoing, headers, profile, context, *, applicable, expected=cm.MISSING,
          expected_attempted=False, allow_expected=False):
    inputs = source_entries(line, incoming, profile)
    result = {"applicable": applicable is True, "inputs": inputs, "outputs": [], "expected": {"state": "unavailable"}}
    if applicable is not True:
        result["note"] = "Correspondance hors comparaison : la sortie n’est pas examinée car aucune donnée source exploitable n’a été retenue."
        return result
    if allow_expected and not expected_attempted:
        try:
            expected = engine.expected(line, incoming, profile, context)
        except Exception:
            expected = cm.MISSING
    result["expected"] = {"state": "pending"} if expected is cm.MISSING else {"state": "known", "value": serializable(expected)}
    result["outputs"], result["note"] = output_entries(line, incoming, outgoing, headers, expected)
    return result


def attach(rows, line, incoming, outgoing, headers, profile, context, *, applicable, expected, expected_attempted, allow_expected=False):
    """Un défaut de présentation ne doit jamais modifier un constat du moteur."""
    values = [row for row in rows if row.get("niveau") == "valeurs"]
    if not values:
        return
    try:
        view = build(line, incoming, outgoing, headers, profile, context, applicable=applicable,
                     expected=expected, expected_attempted=expected_attempted,
                     allow_expected=allow_expected and any(row["code"] == "ECART_PRESENCE" for row in values))
    except Exception:
        view = {"applicable": applicable is True, "inputs": [], "outputs": [], "expected": {"state": "unavailable"},
                "note": "La visualisation détaillée est indisponible pour cette règle. Le constat du contrôle reste inchangé."}
    for row in values:
        row["visualisation"] = view
