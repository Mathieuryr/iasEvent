"""Présence des données Kafka, contrôlée indépendamment de leur transformation.

Aucun filtre de typologie, MTI, processingCode ou amountType n'est ajouté ici.
Les identifiants d'occurrences servent uniquement à retrouver la donnée mappée.
"""
from __future__ import annotations

from dataclasses import dataclass

import controle_mapping as cm
import tango_engine as engine


@dataclass(frozen=True)
class PresenceExpectation:
    required: bool | None
    reason: str
    sources: tuple[str, ...] = ()


def has_data(value):
    # Une chaîne ou collection vide reste un champ fourni. Zéro et False aussi.
    return value is not cm.MISSING and value is not None


def expected_presence(line, incoming, profile):
    if line.operation in {"limites", "controles_emetteur"}:
        wanted = group_records(line, incoming)
        return PresenceExpectation(bool(wanted), "Seuls les sous-champs fournis dans les occurrences sources sont retenus.")
    if not line.source:
        return PresenceExpectation(None, "Aucune correspondance source Kafka ne permet de comparer cette présence.")
    paths = tuple(line.parameters.get("sources", [])) if line.operation == "minimum_disponible" else (line.source,)
    if line.operation == "event_nature":
        source = profile.get("decisions", {}).get("event_nature_source")
        if source not in {"ISOMTI", "MTI"}:
            return PresenceExpectation(None, "La source du calcul n'est pas définie.")
        paths = (source,)
    if line.operation == "groupe_montant":
        values = cm.extract(incoming, line.source)
        if not has_data(values):
            return PresenceExpectation(False, "La liste source est absente ou null.", paths)
        items = engine.record_items(values, line.source)
        matches = [item for item in items if item.get("amountType") == line.parameters.get("code")]
        if not matches:
            return PresenceExpectation(False, "Aucune occurrence ne porte la donnée source de ce montant.", paths)
        return PresenceExpectation(any(has_data(item.get("value", cm.MISSING)) for item in matches),
                                   "Présence du montant source dans l'occurrence correspondante.", paths)
    if line.operation == "minimum_autorisable":
        values=cm.extract(incoming,line.source)
        if not has_data(values):
            return PresenceExpectation(False,"La donnée source est absente ou null.",paths)
        matches=[item for item in engine.record_items(values,line.source) if item.get("limitId") in {300,301,302}]
        return PresenceExpectation(bool(matches) and has_data(matches[0].get("minTransAmt",cm.MISSING)),
                                   "Présence de minTransAmt dans l'occurrence source correspondante.",paths)
    if "[]" in line.source:
        values = cm.extract(incoming, line.source)
        if isinstance(values, list):
            return PresenceExpectation(any(has_data(item) for item in values), "Présence des données sources correspondantes.", paths)
    return PresenceExpectation(any(has_data(cm.extract(incoming, path)) for path in paths),
                               "Seule la présence de la donnée dans l'entrée Kafka détermine sa présence en sortie.", paths)


def output_value(line, outgoing, headers):
    value = engine.observed(line, outgoing, headers)
    if line.operation == "conversion_ancienne" or line.targets and "[]" in line.targets[0]:
        if isinstance(value, list):
            supplied = [item for item in value if item is not cm.MISSING]
            if not supplied:
                return cm.MISSING
            if all(item is None for item in supplied):
                return None
    return value


def group_records(line, incoming):
    """Construire les assertions de présence depuis les données entrantes seules."""
    selection = line.parameters.get("_selection", {})
    if selection.get("unresolved"):
        raise engine.Pending("La correspondance des sous-champs sélectionnés doit être précisée.")
    wanted, masks, identities = [], [], []
    if line.operation == "controles_emetteur":
        selected = selection.get("sources", {})
        for path, fields in selected.items():
            values = cm.extract(incoming, path)
            if not has_data(values):
                continue
            for item in engine.record_items(values, path):
                entry = {field: True for field in fields if has_data(item.get("resultCode" if field == "responseCode" else "controlName", cm.MISSING))}
                if entry:
                    wanted.append(entry)
                    masks.append(list(entry))
                    name=item.get("controlName")
                    identities.append(engine.control_identity(name,entry))
    else:
        fields = selection.get("fields", [])
        values = cm.extract(incoming, line.source)
        items = engine.record_items(values, line.source) if has_data(values) else []
        sources = engine.LIMIT_SOURCES
        for item in items:
            # Identifier l'occurrence mappée, sans condition de typologie.
            if item.get("limitId") not in engine.LIMIT_CODES:
                continue
            entry = {field: True for field in fields if has_data(item.get(sources[field], cm.MISSING))}
            if entry:
                wanted.append(entry)
                masks.append(list(entry))
                identities.append({"code":engine.LIMIT_CODES[item["limitId"]]})
    return engine.SelectedRecords(wanted, masks, allow_extra=True, identities=identities)


def _group_issues(line, incoming, outgoing, headers):
    expected = group_records(line, incoming)
    if not expected:
        return []
    actual = engine.observed(line, outgoing, headers)
    if not has_data(actual):
        actual_items = []
    elif not isinstance(actual, list):
        raise ValueError(f"{line.targets[0]} doit être un tableau")
    else:
        actual_items = actual
    fields={field for mask in expected.masks for field in mask}
    observed=[]
    for item in actual_items:
        if not isinstance(item,dict):
            observed.append({})
            continue
        entry = {field: True for field in fields if has_data(item.get(field, cm.MISSING))}
        # Les identifiants sont utilisés pour l'appariement, sans être des assertions ajoutées.
        observed.append({**entry, "_identity":{key:item[key] for key in ("code","controlCode") if key in item}})
    # Conserver les vraies valeurs d'identité à côté des booléens de présence.
    expected.identities=[{"_identity":identity} for identity in expected.identities]
    issues = engine.selected_differences(expected, observed, line.targets[0])
    for issue in issues:
        issue["motif"] = "Présence différente de la donnée source Kafka : " + issue["motif"]
        for key in ("attendu", "obtenu"):
            if type(issue.get(key)) is bool:
                issue[key] = {"presence": "présente" if issue[key] else "absente"}
    return issues


def check(line, incoming, outgoing, headers, profile, expectation=None):
    """Retourner l'attendu de présence et ses écarts, sans calculer de valeur."""
    expectation = expectation or expected_presence(line, incoming, profile)
    if expectation.required is not True:
        return expectation, []
    if line.operation in {"limites", "controles_emetteur"}:
        return expectation, _group_issues(line, incoming, outgoing, headers)
    if expectation.required is None or not line.targets:
        return expectation, []
    actual = output_value(line, outgoing, headers)
    path = line.targets[0]
    if expectation.required:
        if not has_data(actual):
            return expectation, [{"chemin": path, "motif": "Donnée présente dans l'entrée Kafka mais absente ou null en sortie.",
                                  "attendu": {"presence": "présente"}, "obtenu": cm.visible(actual)}]
        if line.operation == "score" and not has_data(actual.get("serviceData", cm.MISSING)):
            return expectation, [{"chemin": path + "[].serviceData", "motif": "Le score source est présent, mais sa donnée est absente ou null dans l'occurrence de sortie.",
                                  "attendu": {"presence": "présente"}, "obtenu": cm.visible(actual.get("serviceData", cm.MISSING))}]
    return expectation, []
