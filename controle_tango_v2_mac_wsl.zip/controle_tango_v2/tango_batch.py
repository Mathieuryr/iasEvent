"""Appariement explicite des événements SAE et SID pour le contrôle par lot."""
from __future__ import annotations

import csv
import html
import json
from collections import Counter
from pathlib import Path

import fastavro
import controle_mapping as cm
import tango_formats as formats

PAIRS = (("operationRefId", "transaction.context.operationReferenceId"),
         ("transRefId", "transaction.identification.endToEndTransId"))


def references(avro_path, swagger_path, profile_path):
    names = {}
    schema = fastavro.parse_schema(cm.load_document(avro_path), named_schemas=names)
    source, _ = cm.avro_catalog(schema, names)
    document = cm.load_document(swagger_path)
    profile = cm.load_document(profile_path)
    _, selected = cm.make_output_validator(document, profile["schema_sortie"])
    return schema, source, document, selected


def input_identity(path, refs):
    schema, source, _, _ = refs
    message, _ = formats.read_input(path, schema, source)
    return {left: value for left, _ in PAIRS
            if isinstance((value := cm.extract(message, left)), str) and value.strip()}


def output_identity(path, refs):
    _, _, document, selected = refs
    message = cm.load_document(path)
    if isinstance(message, dict) and "body" in message and set(message) <= {"body", "headers"}:
        message = message["body"]
        if isinstance(message, str):
            message = cm.strict_json(message)
    message, _ = formats.normalize_output(message, document, selected)
    return {right: value for _, right in PAIRS
            if isinstance((value := cm.extract(message, right)), str) and value.strip()}


def match(inputs, outputs):
    """Ne retenir qu'une paire unique, avec au moins un ID égal et aucun ID contraire."""
    candidates = {}
    for i, source in enumerate(inputs):
        options = []
        for j, target in enumerate(outputs):
            comparisons = [(source[left] == target[right]) for left, right in PAIRS
                           if left in source and right in target]
            if comparisons and all(comparisons):
                options.append(j)
        candidates[i] = options
    reverse = Counter(j for options in candidates.values() for j in options)
    matched = {i: options[0] for i, options in candidates.items()
               if len(options) == 1 and reverse[options[0]] == 1}
    input_status = ["appariée" if i in matched else
                    "sans identifiant" if not source else
                    "ambiguë" if len(candidates[i]) > 1 or any(reverse[j] > 1 for j in candidates[i]) else
                    "sans correspondance"
                    for i, source in enumerate(inputs)]
    used = set(matched.values())
    output_status = ["appariée" if j in used else
                     "sans identifiant" if not target else
                     "ambiguë" if reverse[j] > 1 else
                     "sans correspondance"
                     for j, target in enumerate(outputs)]
    return matched, input_status, output_status


def write_exports(folder: Path, report, metadata):
    rows = report["v2"]["batch"]["items"]
    columns = ["statut", "entree", "sortie", "identifiants_entree", "identifiants_sortie", "ecarts_mapping", "erreurs_schema", "rapport_individuel"]
    with (folder / "rapport.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter=";")
        writer.writeheader()
        for item in rows:
            flat = {key: json.dumps(item[key], ensure_ascii=False) if key.startswith("identifiants") else item.get(key, "") for key in columns}
            writer.writerow({key: "'" + str(value) if str(value).startswith(("=", "+", "-", "@")) else value for key, value in flat.items()})
    escape = lambda x: html.escape(str(x), quote=True)
    table = "".join("<tr>" + "".join(f"<td>{escape(json.dumps(item.get(key), ensure_ascii=False) if key.startswith('identifiants') else item.get(key, ''))}</td>" for key in columns) + "</tr>" for item in rows)
    document = "<!doctype html><html lang='fr'><meta charset='utf-8'><title>Contrôle par lot SAE → SID</title><style>body{font:14px system-ui;margin:30px;color:#243746}table{border-collapse:collapse;width:100%}th,td{padding:10px;border-bottom:1px solid #ccd6dc;text-align:left;overflow-wrap:anywhere}tr:nth-child(even){background:#f4f7f9}small{color:#617586}</style><h1>Contrôle par lot SAE → SID</h1>" + f"<p>{escape(metadata['label'])} · {len(rows)} ligne(s)</p><small>Les messages sans paire unique ne sont pas comparés. Les rapports individuels sont dans l'historique local.</small><table><thead><tr>" + "".join(f"<th>{escape(key.replace('_',' '))}</th>" for key in columns) + "</tr></thead><tbody>" + table + "</tbody></table></html>"
    (folder / "rapport.html").write_text(document, encoding="utf-8")
