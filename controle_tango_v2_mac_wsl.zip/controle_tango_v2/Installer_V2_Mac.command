#!/bin/bash
cd "$(dirname "$0")" || exit 2
bash tools/tango_posix.sh installer "$@"
rise_exit=$?
if [ -t 0 ]; then read -r -p "Appuyer sur Entrée pour fermer…"; fi
exit "$rise_exit"
