# Démo locale TANGO V2

La V2 propose une interface locale pour choisir les fichiers d'un événement SAE et de sa sortie SID, lancer le contrôle, examiner les écarts et retrouver les exécutions précédentes. Elle utilise le moteur Python du projet et les documents de référence fournis dans le dossier.

**Mac et PC d'entreprise via WSL :** suivre `DEMARRAGE_MAC_WSL.md`, puis `GUIDE_MAC_WSL.md` pour le VPN/proxy. L'archive `controle_tango_v2_mac_wsl.zip` ajoute des paquets hors ligne pour Mac Intel, Apple Silicon et WSL x86_64.

Deux règles sont conservées : **ISOMTI pilote `eventNature`** et **seules les lignes marquées `x` dans la colonne B « Compteur données à mapper » produisent des comparaisons de mapping**. Les validations globales des schémas Avro et Swagger sont identifiées séparément.

## Présence : seul le fichier Kafka d'entrée fait foi

Pour les correspondances du mapping ayant une source Kafka identifiée, aucune condition de typologie, de MTI, de processingCode ou de montant débit/crédit n'est ajoutée au contrôle de présence.

| Donnée en entrée Kafka | Donnée en sortie | Résultat |
| --- | --- | --- |
| Présente | Présente avec une valeur | Présence conforme ; la valeur transformée est ensuite contrôlée. |
| Présente | Champ absent ou `null` | Erreur de présence. |
| Champ absent ou `null` | Champ présent, même vide ou `null` | Erreur de présence : le champ de sortie doit être omis. |
| Champ absent ou `null` | Champ omis | Absence conforme. |

`0`, `false`, une chaîne vide et une collection vide restent des valeurs fournies. Les conteneurs nécessaires à d'autres champs ne sont pas assimilés à la présence d'un sous-champ absent. Dans les listes regroupées, chaque sous-champ sélectionné est contrôlé en conservant les occurrences et les doublons.

Une conversion de date ou de montant encore indéterminée ne masque plus une absence en sortie. Lorsque les deux données sont présentes mais que la valeur attendue ne peut pas être calculée, seule la validation de valeur reste à préciser. Si une ancienne règle prévoit une omission malgré une source présente, elle est signalée comme règle de valeur à réexaminer ; elle ne constitue pas un filtre de présence.

Les données calculées sans copie directe et les enrichissements sans correspondance Kafka identifiée restent attachés à leurs règles documentées. Une source non identifiée n'est pas une absence prouvée. Des headers non capturés ne sont pas déclarés absents : ils restent à vérifier. Les anciennes exécutions restent consultables avec leur politique d'origine ; les scénarios corrigés sont comparés à une exécution de la même version.

## Installer sur un autre PC Windows

1. Transférer l'archive `controle_tango_v2_demo.zip`, puis extraire **tout son contenu** dans un dossier local.
2. Installer Python 3.12, avec la commande `py`, depuis le [site officiel Python pour Windows](https://www.python.org/downloads/windows/). Si le gestionnaire Python est déjà installé, la commande `py install 3.12` permet d'installer cette version. Le script d'installation du projet n'installe pas Python lui-même.
3. Dans le dossier extrait `controle_tango_v2`, double-cliquer sur **`Installer_V2_Windows.cmd`**. Cette étape crée l'environnement `.venv` et installe les dépendances de `requirements.txt`. Elle nécessite l'accès au dépôt de paquets Python configuré sur le PC.
4. Quand l'installation est terminée, double-cliquer sur **`Lancer_V2_Windows.cmd`**.

Pour les utilisations suivantes, seule la quatrième étape est nécessaire. Il faut conserver tous les fichiers du dossier ensemble. L'environnement `.venv` doit être recréé sur chaque PC ; il n'est pas fourni dans l'archive.

La fenêtre du lanceur reste ouverte pendant l'utilisation. **Ctrl+C dans cette fenêtre arrête la démo.** Fermer uniquement l'onglet du navigateur n'arrête pas le programme.

## Lancer sur Mac

Python 3.12 doit être disponible. Pour une première installation, double-cliquer sur **`Installer_V2_Mac.command`**, puis sur **`Lancer_V2_Mac.command`**. Ou utiliser Terminal dans le dossier extrait :

```sh
bash Installer_V2_Mac.command
bash Lancer_V2_Mac.command
```

Le dossier `.venv-mac` est créé pour ce Mac. Les utilisations suivantes passent uniquement par le lanceur. Dans la livraison Mac/WSL, l'installation utilise les paquets inclus ; `--hors-ligne` impose cette méthode. Voir `GUIDE_MAC_WSL.md` pour une installation en ligne derrière un proxy.

## Essayer la démonstration

Le navigateur s'ouvre sur **`http://127.0.0.1:8792`**. L'interface fonctionne avec le programme Python lancé sur ce même ordinateur. Elle n'a pas besoin d'être publiée sur Internet.

- **Exemple fourni** : lance le contrôle de la paire `audit_KAFKA.txt` / `Kafka_audit_sortie.txt` incluse dans `examples_reels`, avec le mapping et les schémas fournis.
- **Exemple avec une valeur corrigée** : ajoute `eventNature` à une copie de la sortie pour illustrer la disparition de l'écart correspondant. Cette variante est un scénario de démonstration. Elle ne corrige pas les autres écarts et ne modifie aucun fichier original.

Les résultats sont calculés au lancement. Les zones sans résultat n'indiquent pas une conformité. Les décisions métier non définies restent à vérifier ; les exemples ne servent pas à inventer une convention de transformation.

## Contrôler ses propres fichiers

1. Sélectionner le fichier **d'entrée SAE** et le fichier **de sortie SID** correspondant au même événement.
2. Si nécessaire, remplacer les références dans la zone dédiée : **mapping Excel**, **schéma Avro d'entrée** et **Swagger de sortie**. Sinon, la démo utilise les références incluses dans `donnees_tango` et le profil du projet.
3. Donner un libellé à l'exécution, puis lancer le contrôle.
4. Filtrer les constats par catégorie ou statut. Ouvrir le détail pour consulter le chemin concerné, la ligne Excel, les valeurs attendue et obtenue et l'action proposée.

Les formats d'entrée pris en charge par le moteur incluent le JSON décodé et l'audit texte TANGO. Les enveloppes JSON Avro de sortie connues sont lues avant la validation du corps logique. Un format non reconnu reste signalé ; les valeurs ne sont pas remplacées automatiquement.

Un nouveau mapping peut modifier une règle existante. Le moteur vérifie ses signatures et demande une révision lorsque la règle a changé. Il ne réutilise pas silencieusement une ancienne transformation sur une règle différente.

## Rapports et historique

Chaque contrôle dispose d'un identifiant et d'une entrée dans l'historique local. Cliquer sur une exécution permet de consulter à nouveau son résultat. Les exports **HTML**, **CSV** et **JSON** sont disponibles depuis le résultat affiché.

- Le **HTML** permet de lire les constats et les actions proposées dans un navigateur. Les filtres sont disponibles dans l'interface de la démo.
- Le **CSV** permet de reprendre les constats dans un tableur.
- Le **JSON** conserve le détail structuré du contrôle et les informations de traçabilité.

Les fichiers choisis, les résultats et l'historique restent sur l'ordinateur qui exécute la démo. Le serveur écoute uniquement l'adresse locale `127.0.0.1`. Les fichiers sont transmis au processus Python local pour être contrôlés ; aucun service distant de traitement n'est utilisé.

Pour choisir un dossier d'historique distinct ou ne pas ouvrir automatiquement le navigateur :

```sh
python demo_v2.py --port 8792 --no-browser --data-dir "mon_historique"
```

Utiliser le Python du système concerné dans cette commande : `.venv\Scripts\python.exe` sous Windows natif, `./.venv-mac/bin/python` sur Mac ou `./.venv-wsl/bin/python` dans WSL. L'ancien environnement de développement `.venv` reste utilisable directement s'il existe déjà.

## Portée de cette V2 de démonstration

- Une exécution compare **une paire de messages**. Le traitement d'un dossier complet d'événements et leur appariement automatique restent des évolutions futures.
- L'interface et les lanceurs utilisent Python. Cette livraison n'est pas un exécutable Windows autonome. Les lanceurs Windows n'ont pas été exécutés sur un PC Windows lors de la préparation sur Mac.
- Les conventions de dates, les unités monétaires, les headers et certaines références d'enrichissement doivent être validés par le métier pour terminer tous les contrôles concernés.
- Le schéma Avro du transport de sortie n'est pas fourni. La validation de sortie porte sur le corps logique décrit par le Swagger.
- Une anomalie de format, un écart de mapping et une décision manquante demandent des actions différentes. Un statut à vérifier ne vaut pas validation.

## Vérifier l'installation

Depuis le dossier de la démo, utiliser le Python de `.venv` :

```sh
python -m unittest discover -s tests -q
```

Les tests du moteur et de la démo sont aussi exécutés à partir d'une extraction propre lors de la création de l'archive. Cette vérification ne remplace pas un passage sur le système d'exploitation du PC destinataire.
