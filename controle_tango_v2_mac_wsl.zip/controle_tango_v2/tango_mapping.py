"""Lecture du mapping Notification Forwarding et résolution des chemins réels."""
from __future__ import annotations

import hashlib
import json
import re
import warnings
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

import openpyxl
import controle_mapping as cm

PARENTS = {
    "transactionDetails": "transaction", "transactionContext": "transaction.context",
    "transactionIdentification": "transaction.identification", "originalTransactionData": "originalTransaction",
    "response": "transaction.response", "eMV": "transaction.eMV", "threeDs": "transaction.threeDs",
    "issuerProcessingData": "transaction.issuerProcessingData", "additionalResponseData": "transaction.additionalResponseData",
    "cardContext": "card.context", "cardAgreement": "card", "posAgreement": "merchant",
    "executionContract": "merchant", "acceptanceChannel": "merchant", "executionContractSchemeId": "merchant",
    "issuerControlList": "transaction.issuerControlList[]", "usageCurrentValueList": "card.usageCurrentValueList[]",
    "conversionRateList": "transaction.conversionRateList[]", "acceptanceSysComponent": "terminal.acceptanceSysComponent",
    "additionalElectronicCommerceDataElementsList": "transaction.additionalElectronicCommerceDataElementsList[]",
    "exchangeRateInformation": "transaction.exchangeRateInformationList[]", "cardRepository": "card",
    "riskScoringList": "riskScoringList[]",
}
# These names differ in the supplied Excel and Avro; every use is reported.
SOURCE_ALIASES = {"additionalResponseInfo": "aditionalResponseInfo"}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def text(value):
    return "" if value is None else str(value).strip()


@dataclass
class Line:
    row: int
    raw_source: str
    raw_object: str
    raw_attribute: str
    reference: str
    marked: bool
    presence: str
    comment: str
    source_values: str
    declared_type: str
    source: str = ""
    targets: list[str] = field(default_factory=list)
    location: str = "body"
    operation: str = "a_definir"
    parameters: dict = field(default_factory=dict)
    notes: list[dict] = field(default_factory=list)
    candidates: list[str] = field(default_factory=list)
    signature: str = ""
    source_format: str = ""
    source_description: str = ""

    def note(self, status, code, detail):
        self.notes.append({"statut": status, "code": code, "detail": detail})


def read_sheets(path: Path):
    if path.suffix.lower() not in {".xlsm", ".xlsx"}:
        raise cm.ConfigurationError("Le profil TANGO attend un classeur .xlsm ou .xlsx.")
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Data Validation extension is not supported.*", category=UserWarning)
        book = openpyxl.load_workbook(path, read_only=True, data_only=False)
        try:
            required = {"Notification Forwarding", "Iss-OA3_001 & Iss-OA3_002"}
            if not required <= set(book.sheetnames):
                raise cm.ConfigurationError(f"Onglets attendus absents : {sorted(required - set(book.sheetnames))}")
            return {sheet.title: [(number, {openpyxl.utils.get_column_letter(i): cell.value for i, cell in enumerate(row, 1) if cell.value is not None}) for number, row in enumerate(sheet.iter_rows(), 1)] for sheet in book}
        finally:
            book.close()


def source_resolution(name: str, current: str, catalog):
    clean = name.rstrip("*").strip()
    alias = SOURCE_ALIASES.get(clean, clean)
    parents = [current]
    while parents[-1]:
        parents.append(parents[-1].rsplit(".", 1)[0] if "." in parents[-1] else "")
    for parent in parents:
        candidate = f"{parent}.{alias}".lstrip(".")
        matches = [key for key in catalog if key.casefold() == candidate.casefold()]
        if len(matches) == 1:
            return matches[0], [], clean != matches[0].split(".")[-1]
    matches = [key for key in catalog if key.split(".")[-1].casefold() == alias.casefold()]
    if len(matches) == 1:
        return matches[0], [], clean != matches[0].split(".")[-1]
    return "", matches, False


def parent_candidates(name: str, target):
    canonical = PARENTS.get(name, name)
    if canonical in target:
        return [canonical]
    return [key for key, entry in target.items() if entry.types & {"object"} and key.split(".")[-1].removesuffix("[]") == name]


def target_resolution(line: Line, dictionary, target):
    parent = line.raw_object
    attr = line.raw_attribute
    possible = []
    if re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", attr):
        possible = [f"{owner}.{attr}" for owner in parent_candidates(parent, target) if f"{owner}.{attr}" in target]
    if len(possible) == 1:
        return possible, "attribut"
    refs = re.findall(r"\d{12}", line.reference)
    entries = [entry for ref in refs for entry in dictionary.get(ref, [])]
    possible = []
    for entry in entries:
        if text(entry.get("J")).casefold() != "body":
            continue
        owners = parent_candidates(text(entry.get("Q")), target)
        for owner in owners:
            name = text(entry.get("P"))
            candidate = f"{owner}.{name}"
            if candidate in target:
                possible.append(candidate)
    possible = list(dict.fromkeys(possible))
    if len(possible) == 1:
        return possible, "reference_dictionnaire"
    if possible:
        return possible, "references_multiples"
    return [], "non_resolu"


def leaf_target(line: Line, target):
    if len(line.targets) != 1:
        return
    root = line.targets[0]
    if not target[root].types & {"object"}:
        return
    name = line.source.split(".")[-1] if line.source else line.raw_source
    known = {
        "streetAddress": "streetName", "addressLine1": "streetName", "dataLocCardholderAddress": "streetName",
        "postalCode": "postCode", "dataLocCardholderPostCode": "postCode", "city": "townName",
        "country": "countryCode", "acquirerCountry": "countryCode", "state": "countrySubdivisionMajorCode",
        "currency": "currency", "billingCurrency": "currency", "transCurrencyCode": "currency", "currencyCode": "currency",
        "transactionAmt": "amount", "billingTransactionAmt": "amount", "billingActualTransactionAmt": "amount",
        "transactionFeeAmt": "amount", "actualTransactionAmt": "amount", "amtAuthorized": "amount", "amtOther": "amount",
        "TDSAuthenticationAmt": "amount", "cardholderTotalAmt": "amount",
    }
    leaf = known.get(name)
    if leaf and f"{root}.{leaf}" in target:
        line.targets = [f"{root}.{leaf}"]
        if name == "state" and "countryName" in line.comment:
            line.note("A_VERIFIER", "SOUS_CHAMP_ADRESSE", "Le commentaire indique countryName mais le Swagger propose countrySubdivisionMajorCode.")


def import_mapping(path: Path, source, target):
    sheets = read_sheets(path)
    header = dict(sheets["Notification Forwarding"][1][1])
    expected = {"A": "Donnée", "B": "Compteur données à mapper", "P": "Commentaire", "R": "Objet", "S": "Attribut", "V": "Référence"}
    if any(text(header.get(key)) != value for key, value in expected.items()):
        raise cm.ConfigurationError("La disposition de Notification Forwarding a changé : vérifier les colonnes avant le contrôle.")
    dictionary = defaultdict(list)
    for _, cells in sheets["Iss-OA3_001 & Iss-OA3_002"][1:]:
        dictionary[text(cells.get("A"))].append(cells)
    current, lines, inactive, containers = "", [], [], []
    marked_count = 0
    marked_containers = []
    for number, cells in sheets["Notification Forwarding"][2:]:
        name, attr = text(cells.get("A")), text(cells.get("S"))
        if not name and not attr and not cells.get("B"):
            continue
        item = Line(number, name, text(cells.get("R")), attr, text(cells.get("V")), text(cells.get("B")).casefold() == "x",
                    text(cells.get("C")), text(cells.get("P")), text(cells.get("O")), text(cells.get("H")))
        marked_count += int(item.marked)
        item.source_format = text(cells.get("K"))
        item.source_description = text(cells.get("N"))
        item.signature = hashlib.sha256(json.dumps({key: cells.get(key) for key in ("A", "B", "C", "H", "K", "M", "N", "O", "P", "Q", "R", "S", "T", "V")}, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()
        if name and name != "N.A.":
            item.source, item.candidates, renamed = source_resolution(name, current, source)
            if item.source:
                info = source[item.source]
                is_container = bool(info.types & {"object"}) or ("array" in info.types and "object" in source.get(item.source + "[]", cm.Field()).types)
                if is_container:
                    current = item.source + ("[]" if "array" in info.types else "")
                    containers.append({"ligne": number, "source": item.source, "libelle": name})
                elif "." in item.source:
                    current = item.source.rsplit(".", 1)[0]
                else:
                    current = ""
                if renamed:
                    item.note("INFO", "NOM_SOURCE_DIFFERENT", f"Nom Excel {name!r} ; nom exact Avro {item.source!r}. La comparaison utilise le nom Avro.")
                declared = {"int":"integer", "integer":"integer", "long":"integer", "string":"string", "array":"array", "record":"object"}.get(item.declared_type.casefold())
                if declared and info.types - {"null"} != {declared}:
                    item.note("A_VERIFIER", "TYPE_SOURCE_EXCEL_DIFFERENT", f"Type annoncé dans l'Excel : {item.declared_type} ; Avro : {sorted(info.types)}.")
            else:
                is_container = text(cells.get("H")).casefold() in {"record", "array"} and name.endswith("*")
                if item.candidates:
                    item.note("A_VERIFIER", "SOURCE_AMBIGUE", f"Plusieurs chemins Avro possibles : {item.candidates}")
                else:
                    item.note("ERREUR", "SOURCE_ABSENTE", f"Champ non retrouvé dans l'Avro : {name}")
        else:
            is_container = False
        if text(cells.get("Q")).casefold() == "header":
            item.location = "headers"
            item.targets = ["X-Event-Type" if number == 3 else attr]
        elif attr:
            item.targets, method = target_resolution(item, dictionary, target)
            if method == "references_multiples":
                item.note("A_VERIFIER", "CIBLES_MULTIPLES", "Plusieurs cibles sont associées aux références de cette ligne.")
            if not item.targets:
                item.note("ERREUR", "CIBLE_ABSENTE", f"Cible non retrouvée : {item.raw_object}.{attr} ; référence {item.reference}.")
            else:
                leaf_target(item, target)
        elif item.marked:
            item.note("A_VERIFIER", "CIBLE_NON_RENSEIGNEE", "Ligne marquée x sans cible explicite ; rattachement à une règle composée à vérifier.")
        # La sélection vient exclusivement de la marque de cette ligne en colonne B.
        # Les parents non marqués servent seulement à reconstruire les chemins.
        active = item.marked and not (is_container and not attr)
        if item.marked and is_container and not attr:
            marked_containers.append({"ligne":number,"source":item.source,"libelle":name})
        if active:
            if not item.source and not item.notes and number != 3:
                item.note("A_VERIFIER", "SOURCE_EXTERNE", "Donnée enrichie ou source non décrite ; un contexte de référence est nécessaire.")
            lines.append(item)
        elif attr or item.marked:
            inactive.append(asdict(item))
    return lines, {"lignes_hors_perimetre": inactive, "conteneurs": containers,
                   "selection":{"colonne":"B","libelle":"Compteur données à mapper","marque":"x",
                                "lignes_marquees":marked_count,"titres_conteneurs_marques":marked_containers},
                   "perimetre": "Uniquement les lignes marquées x dans la colonne B « Compteur données à mapper », hors titres de conteneurs sans cible propre", "sheets": sheets}


def extract_specification(path: Path | None):
    if path is None:
        return {"fourni": False, "champs": []}
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    with ZipFile(path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    tables = []
    for table in root.findall(".//w:tbl", ns):
        rows = [["\n".join("".join(t.text or "" for t in p.findall(".//w:t", ns)) for p in cell.findall("./w:p", ns)) for cell in row.findall("./w:tc", ns)] for row in table.findall("./w:tr", ns)]
        if rows and rows[0][:3] == ["Data Element", "Pres.", "AVRO Type"]:
            tables.append(rows)
    if len(tables) != 1:
        raise cm.ConfigurationError("La table Message format de la spécification Word n'est pas identifiée de manière unique.")
    return {"fourni": True, "sha256": sha256(path), "champs": [{"nom": row[0].strip(), "presence": row[1], "type": row[2], "format": row[3], "regle": row[4], "condition_mti": row[5]} for row in tables[0][1:]]}
