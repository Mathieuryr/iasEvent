"""Vue métier des résultats, sans modifier les constats du moteur."""
from __future__ import annotations

import hashlib
import html
import json
import csv
from collections import Counter


def category(row):
    code = row.get("code", "")
    if code in {"ENTREE_AVRO", "ENTREE_AVRO_INVALIDE", "SORTIE_SWAGGER", "SORTIE_SWAGGER_INVALIDE"}:
        return "schema"
    if row.get("niveau") in {"structure", "specification"}:
        return "reference"
    if row.get("niveau") in {"preparation", "configuration", "interne"}:
        return "preparation"
    return "decision" if row.get("statut") == "A_VERIFIER" else "mapping"


def suggested_action(row, *, input_scope=False):
    code = row.get("code", "")
    status = row.get("statut")
    target = row.get("chemin") or row.get("cible") or "ce champ"
    if status in {"OK", "NON_APPLICABLE", "INFO"}:
        return "Aucune action demandée par ce contrôle."
    if code == "SORTIE_SWAGGER_INVALIDE":
        if "is not a 'date'" in row.get("detail", ""):
            return "Vérifier la conversion de la date vers le format AAAA-MM-JJ attendu par le Swagger. Confirmer la convention source avant correction."
        return f"Vérifier le type, le format ou les valeurs autorisées pour {target} dans le Swagger."
    if code == "ENTREE_AVRO_INVALIDE":
        return "Vérifier la structure et les types du message d'entrée selon l'Avro. Les comparaisons dépendant de données invalides ne prouvent pas une conformité."
    if code == "ECART_MAPPING":
        return f"Comparer l'alimentation de {target} avec la ligne Excel indiquée, puis relancer sur la même paire de messages."
    if code == "ECART_PRESENCE":
        if input_scope:
            return f"Retrouver et renseigner {target} à partir de la donnée Kafka présente en entrée, selon la ligne du mapping indiquée. Les données sans source fournie restent hors comparaison."
        return f"Aligner la présence de {target} sur la donnée Kafka correspondante : source présente → cible présente ; source absente ou null → champ de sortie omis."
    if code in {"TRANSCODIFICATION_HORS_ENUM", "CIBLE_ABSENTE", "TYPE_INCOMPATIBLE"}:
        return "Rapprocher le mapping et le Swagger avec leurs responsables pour établir la version et la correspondance à retenir."
    if code in {"REGLE_MODIFIEE", "REGLE_A_COMPLETER", "ATTENDU_NON_DETERMINABLE", "ECHELLE_MONETAIRE", "CONTENEUR_VIDE_OPTIONNEL","REGLE_VALEUR_A_REVOIR"}:
        return "Préciser ou valider la règle métier décrite dans le constat, puis renseigner le profil ou la référence indépendante. Ne pas déduire l'attendu de la sortie testée."
    if code == "PRIORITE_NON_DEFINIE":
        return "Définir la priorité entre les sources qui alimentent cette cible."
    if code == "DONNEE_OU_TRANSFORMATION":
        return "Vérifier la donnée source, la forme de chaque occurrence et la règle appliquée à la ligne indiquée."
    if code == "ERREUR_INTERNE_REGLE":
        return "Faire examiner ce défaut du moteur avec le code du contrôle et la ligne Excel. Les autres résultats restent disponibles."
    if code == "ERREUR_CONFIGURATION":
        return "Vérifier les fichiers choisis et le détail de l'interruption avant de relancer."
    return "Examiner le constat et la référence associée avant de conclure sur ce contrôle."


def decorate_report(report):
    findings = []
    identifiers = Counter()
    input_scope = report.get("decisions", {}).get("perimetre_comparaison") == "sources_presentes_uniquement"
    coverage = report.get("couverture", {})
    for row in report.get("controles", []):
        current_category = category(row)
        target = row.get("chemin") or row.get("cible") or ""
        identity = json.dumps([row.get("niveau"), row.get("code"), row.get("ligne_excel"), row.get("source"), target], ensure_ascii=False)
        digest = hashlib.sha256(identity.encode()).hexdigest()[:16]
        ordinal = identifiers[digest]
        identifiers[digest] += 1
        detail=row.get("detail", "")
        if row.get("code")=="SORTIE_SWAGGER_INVALIDE" and "is not a 'date'" in detail:
            detail=f"La valeur {row.get('obtenu', 'fournie')!r} ne respecte pas le format de date attendu (AAAA-MM-JJ)."
        findings.append({
            "id": f"{digest}-{ordinal}", "category": current_category,
            "severity": {"ERREUR": "error", "A_VERIFIER": "pending", "OK": "ok", "INFO": "info", "NON_APPLICABLE": "not-applicable"}.get(row.get("statut"), "info"),
            "status": row.get("statut", "INFO"), "code": row.get("code", ""),
            "excel_row": row.get("ligne_excel"), "source": row.get("source", ""), "target": target,
            "detail": detail, "expected": row.get("attendu"), "actual": row.get("obtenu"),
            "has_expected": "attendu" in row, "has_actual": "obtenu" in row,
            "action": suggested_action(row, input_scope=input_scope),
        })
    summary = {
        "mapping_errors": sum(item["category"] == "mapping" and item["severity"] == "error" for item in findings),
        "schema_errors": sum(item["category"] == "schema" and item["severity"] == "error" for item in findings),
        "reference_errors": sum(item["category"] == "reference" and item["severity"] == "error" for item in findings),
        "preparation_errors": sum(item["category"] == "preparation" and item["severity"] == "error" for item in findings),
        "pending": sum(item["category"] == "decision" and item["severity"] == "pending" for item in findings),
        "reference_pending": sum(item["category"] == "reference" and item["severity"] == "pending" for item in findings),
        "preparation_pending": sum(item["category"] == "preparation" and item["severity"] == "pending" for item in findings),
        "ok": sum(row.get("niveau") == "valeurs" and row.get("statut") == "OK" for row in report.get("controles", [])),
        "not_applicable": sum(row.get("niveau") == "valeurs" and row.get("statut") == "NON_APPLICABLE" for row in report.get("controles", [])),
        "selected_rules": report.get("couverture", {}).get("lignes_actives", 0),
        "input_scope_only": input_scope,
        "rules_in_scope": coverage.get("regles_avec_source_presente"),
        "ignored_rules": (coverage.get("regles_ignorees_source_absente", 0) + coverage.get("regles_ignorees_source_non_identifiee", 0)) if input_scope else None,
        "ignored_missing_source": coverage.get("regles_ignorees_source_absente"),
        "ignored_unidentified_source": coverage.get("regles_ignorees_source_non_identifiee"),
        "total_errors": sum(item["severity"] == "error" for item in findings),
        "total_pending": sum(item["severity"] == "pending" for item in findings),
    }
    report["v2"] = {"summary": summary, "findings": findings}
    return report


def comparison_with_previous(current, previous):
    """Comparer les identités de constats, sans assimiler leur nombre à des causes."""
    previous_issues = {item["id"] for item in previous.get("v2", {}).get("findings", []) if item["severity"] == "error"}
    current_issues = {item["id"] for item in current.get("v2", {}).get("findings", []) if item["severity"] == "error"}
    return {"corrected": len(previous_issues - current_issues), "new": len(current_issues - previous_issues), "unchanged": len(previous_issues & current_issues)}


def write_csv(path, report):
    columns=["statut","type_controle","ligne_excel","source","cible","code","constat","attendu","obtenu","action"]
    with path.open("w",encoding="utf-8-sig",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=columns,delimiter=";")
        writer.writeheader()
        for item in report["v2"]["findings"]:
            row={"statut":item["status"],"type_controle":item["category"],"ligne_excel":item["excel_row"],
                 "source":item["source"],"cible":item["target"],"code":item["code"],"constat":item["detail"],
                 "attendu":json.dumps(item["expected"],ensure_ascii=False) if item["has_expected"] else "",
                 "obtenu":json.dumps(item["actual"],ensure_ascii=False) if item["has_actual"] else "","action":item["action"]}
            writer.writerow({key:"'"+value if isinstance(value,str) and value.startswith(("=","+","-","@")) else value for key,value in row.items()})


def write_html(path, report, metadata):
    """Export autonome, sans code ni ressources distantes."""
    escape = lambda value: html.escape(str(value), quote=True)
    summary = report["v2"]["summary"]
    scope = ""
    if summary.get("input_scope_only"):
        scope = "<p>Seules les correspondances dont la source est fournie dans l’entrée Kafka sont comparées. Les données supplémentaires en sortie restent hors comparaison. Les contrôles des schémas et des références sont présentés séparément.</p>"
        if summary.get("rules_in_scope") is not None:
            scope += f"<p>{escape(summary['rules_in_scope'])} correspondances issues de l’entrée ; {escape(summary.get('ignored_rules', 0))} hors comparaison (source absente, null ou non identifiée).</p>"
    labels = {"mapping": "Mapping", "schema": "Format du message", "reference": "Références", "decision": "Décision métier", "preparation": "Exécution"}
    rows = []
    for item in report["v2"]["findings"]:
        if item["severity"] not in {"error", "pending"}:
            continue
        details = ""
        for field, label in (("expected", "Attendu"), ("actual", "Obtenu")):
            if item["has_" + field]:
                details += f"<p><b>{label}</b></p><pre>{escape(json.dumps(item[field], ensure_ascii=False, indent=2))}</pre>"
        rows.append(f"<tr><td>{escape(item['status'])}<br><small>{escape(labels[item['category']])}</small></td>"
                    f"<td>{escape(item['excel_row'] or '—')}</td><td><code>{escape(item['source'])}</code></td>"
                    f"<td><code>{escape(item['target'])}</code></td><td><b>{escape(item['code'])}</b><p>{escape(item['detail'])}</p>{details}"
                    f"<p class='action'>{escape(item['action'])}</p></td></tr>")
    document = f"""<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Contrôle SAE · SID — V2</title><style>body{{font:15px system-ui;margin:0;background:#f5f7fa;color:#223044}}main{{max-width:1400px;margin:36px auto;padding:24px}}h1{{font-size:28px}}.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:24px 0}}.card{{padding:18px;background:white;border:1px solid #dce3ec;border-radius:10px;min-width:145px}}.card b{{font-size:28px;display:block}}table{{width:100%;border-collapse:collapse;background:white}}th,td{{padding:14px;border-bottom:1px solid #dce3ec;text-align:left;vertical-align:top}}th{{font-size:12px;color:#5a687c}}td{{font-size:13px;overflow-wrap:anywhere}}code{{font-size:12px}}pre{{white-space:pre-wrap;max-width:640px;overflow-wrap:anywhere;font-size:12px}}.action{{padding:12px;background:#eef4fa;border-radius:6px}}small{{color:#6b778b}}.table{{overflow:auto}}</style>
<main><h1>Contrôle SAE · SID</h1><p>{escape(metadata.get('label', 'Contrôle V2'))} — {escape(metadata.get('created_at', ''))}</p>
<p>{escape(report.get('portee', ''))}</p><p>ISOMTI fait foi pour eventNature. Les décisions métier manquantes restent à vérifier.</p>
{scope}
<div class="cards"><div class="card"><b>{summary['mapping_errors']}</b>Écarts de mapping</div><div class="card"><b>{summary['schema_errors']}</b>Erreurs de format</div><div class="card"><b>{summary['reference_errors']}</b>Erreurs de référence</div><div class="card"><b>{summary['pending']}</b>Décisions sur les valeurs</div><div class="card"><b>{summary['selected_rules']}</b>Règles sélectionnées</div></div>
<p>{summary['reference_pending']} contrôles de référence et {summary['preparation_pending']} contrôles de préparation restent également à vérifier. Les nombres comptent des constats, pas des causes indépendantes.</p>
<div class="table"><table><thead><tr><th>Statut</th><th>Ligne Excel</th><th>Source</th><th>Cible</th><th>Constat et action</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></main></html>"""
    path.write_text(document, encoding="utf-8")
