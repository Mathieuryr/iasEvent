"""Exécution des règles TANGO documentées. Les règles incertaines restent explicites."""
from __future__ import annotations

import json
import re
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import controle_mapping as cm


class Pending(ValueError):
    """Le contrat ou une référence ne permet pas de déterminer une valeur attendue."""


ABSENT = cm.MISSING


CONTROL_FIELDS = {
    "code": "code",
    "controlCode": "controlCode",
    "controlResponseCode": "responseCode",
    "responseCode": "responseCode",
}
LIMIT_FIELDS = {
    "usageCurrentValueCode": "code",
    "usageCurrentValueLimitNumber": "limitNumber",
    "usageCurrentValueLimitAmount": "limitAmount",
    "usageCurrentValueAmount": "amount",
    "usageCurrentValueCategory": "category",
}


class SelectedRecords(list):
    """Occurrences projetées avec leur masque, sans supprimer les doublons."""

    def __init__(self, values, masks, *, allow_extra=False, money_fields=False):
        super().__init__(values)
        self.masks = masks
        self.allow_extra = allow_extra
        self.money_fields = money_fields


def prepare_selected_lines(lines):
    """Préparer les règles composées depuis les seules lignes actives.

    L'appel est explicite : les anciens appels unitaires d'expected() continuent
    de calculer la règle complète lorsqu'aucune sélection n'a été préparée.
    Les copies évitent de modifier le profil ou les lignes de l'importeur.
    """
    result = deepcopy(list(lines))
    selections = {}
    for line in result:
        if not getattr(line, "marked", True) or line.operation not in {"controles_emetteur", "limites"}:
            continue
        key = (line.operation, tuple(line.targets))
        selection = selections.setdefault(key, {"operation": line.operation})
        if line.operation == "controles_emetteur":
            field = CONTROL_FIELDS.get(line.raw_attribute)
            source = line.source.split("[]", 1)[0]
            known_sources = list(line.parameters.get("sources", []))
            selection.setdefault("all_sources", known_sources)
            if field is None or source not in known_sources:
                selection.setdefault("unresolved", []).append(line.row)
                continue
            fields = selection.setdefault("sources", {}).setdefault(source, [])
        else:
            field = LIMIT_FIELDS.get(line.raw_attribute)
            if field is None:
                selection.setdefault("unresolved", []).append(line.row)
                continue
            fields = selection.setdefault("fields", [])
        if field not in fields:
            fields.append(field)
    for line in result:
        key = (line.operation, tuple(line.targets))
        if key in selections:
            line.parameters["_selection"] = deepcopy(selections[key])
    return result


def record_items(value, path):
    """Valider la forme avant d'accéder aux champs d'une occurrence."""
    if not isinstance(value, list):
        raise ValueError(f"{path} doit être un tableau")
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            raise ValueError(f"{path}[{index}] doit être un objet, reçu {cm.json_type(item)}")
    return value


def normalize_money_tree(value, key=""):
    if isinstance(value, dict):
        return {name: normalize_money_tree(child, name) for name, child in value.items()}
    if isinstance(value, list):
        return [normalize_money_tree(child) for child in value]
    if key == "amount" and isinstance(value, str):
        return numeric(value)
    return value


def selected_differences(expected_value, actual, path):
    """Apparier les projections sans ordre et avec multiplicité.

    Une liste source non sélectionnée peut contribuer des occurrences à la
    sortie fusionnée. Ses occurrences supplémentaires restent hors comparaison.
    Lorsque toutes les listes sont sélectionnées, la cardinalité est contrôlée.
    """
    if actual is ABSENT:
        if not expected_value:
            return []
        return [{"chemin": path, "motif": "tableau de sortie absent", "attendu": list(expected_value), "obtenu": cm.visible(actual)}]
    record_items(actual, path)

    def projection(item, fields):
        value = {name: item[name] for name in fields if name in item}
        return normalize_money_tree(value) if expected_value.money_fields else value

    normalized = [normalize_money_tree(item) if expected_value.money_fields else item for item in expected_value]
    candidates = [[index for index, observed in enumerate(actual)
                   if not cm.differences(wanted, projection(observed, fields), Decimal(0))]
                  for wanted, fields in zip(normalized, expected_value.masks)]
    matched = {}

    def assign(wanted_index, visited):
        for actual_index in candidates[wanted_index]:
            if actual_index in visited:
                continue
            visited.add(actual_index)
            if actual_index not in matched or assign(matched[actual_index], visited):
                matched[actual_index] = wanted_index
                return True
        return False

    unmatched = [index for index in range(len(normalized)) if not assign(index, set())]
    issues = []
    diagnosed=set()
    for index in unmatched:
        available = [i for i in range(len(actual)) if i not in matched and i not in diagnosed]
        if available:
            fields = expected_value.masks[index]
            best = min(available, key=lambda i: len(cm.differences(normalized[index], projection(actual[i], fields), Decimal(0))))
            diagnosed.add(best)
            issues.extend(cm.differences(normalized[index], projection(actual[best], fields), Decimal(0), f"{path}[{best}]"))
        else:
            issues.append({"chemin": path, "motif": "occurrence attendue absente (doublons conservés)",
                           "attendu": cm.visible(expected_value[index]), "obtenu": {"absent": True}})
    if not expected_value.allow_extra and len(actual) != len(expected_value):
        issues.append({"chemin": path, "motif": "nombre d'occurrences différent sur les sources sélectionnées",
                       "attendu": len(expected_value), "obtenu": len(actual)})
    return issues


def absent(value):
    return value is ABSENT or value is None


def string(value):
    if isinstance(value, bytes):
        return value.decode("ascii")
    if not isinstance(value, str):
        raise ValueError("Une chaîne est attendue pour ce découpage/transcodage")
    return value


def cut(value, start, end):
    value = string(value)
    if start >= 0 and len(value) < start or end is not None and len(value) < end or start < 0 and len(value) < abs(start):
        raise ValueError(f"Champ trop court ({len(value)}) pour les positions {start}:{end}")
    return value[start:end]


def numeric(value):
    if isinstance(value, bool) or absent(value):
        raise ValueError("Montant numérique attendu")
    value = Decimal(str(value))
    if not value.is_finite():
        raise ValueError("Montant non fini")
    return value


def money(value, currency, profile, source_path):
    settings = profile.get("monnaie", {})
    unit = settings.get("unites_par_source", {}).get(source_path, settings.get("unite_source"))
    if unit not in {"majeure", "mineure"}:
        raise Pending(f"Unité monétaire à renseigner pour {source_path} (majeure ou mineure).")
    amount = numeric(value)
    if unit == "mineure":
        exponent = settings.get("exposants", {}).get(str(currency))
        if type(exponent) is not int or not 0 <= exponent <= 8:
            raise Pending(f"Exposant de devise non fourni pour {currency!r}.")
        amount = amount.scaleb(-exponent)
    return format(amount, "f")


def pipeline(value, parameters):
    for step in parameters.get("etapes", []):
        op = step["operation"]
        if op == "decoupage":
            try:
                value = cut(value, step["debut"], step.get("fin"))
            except ValueError:
                if "defaut" not in parameters:
                    raise
                value = parameters["defaut"]
            if value in parameters.get("omettre_valeurs", []):
                return ABSENT
        elif op == "dictionnaire":
            key = str(value)
            if key not in step["valeurs"]:
                if "defaut" not in step:
                    raise ValueError(f"Code {key!r} non couvert par la transcodification documentée")
                value = step["defaut"]
            else:
                value = step["valeurs"][key]
        elif op == "constante":
            value = step["valeur"]
        else:
            raise Pending(f"Étape non implémentée : {op}")
    return value


def packed_rate(value):
    value = string(value)
    if len(value) != 8 or not value.isdigit():
        raise ValueError("Le taux compact doit comporter exactement huit chiffres")
    return format(Decimal(value[1:]).scaleb(-int(value[0])), "f")


def exchange_rates(value, boolean_mapping=None):
    """Une occurrence, seule représentation non ambiguë du champ string Avro fourni."""
    value = string(value)
    if not value:
        return []
    if value[0] == "1":
        if len(value) != 85:
            raise Pending("Occurrence VISA attendue sur 85 positions ; répétition/délimiteur non défini par le schéma string.")
        provider, table, rate, eligible = value[1:71].rstrip(), value[71:76].rstrip(), value[76:84], value[84]
        result = {"network":"VISA", "exchangeRateOrigin":"ECBR" if "ECB" in provider else "SCHR"}
        if provider:
            result["exchangeRateProvider"] = provider
        if table:
            result["rateTableId"] = table
        if rate.strip():
            result["exchangeRate"] = packed_rate(rate)
        if eligible.strip():
            if not isinstance(boolean_mapping,dict) or eligible not in boolean_mapping or type(boolean_mapping[eligible]) is not bool:
                raise Pending("Conversion vers le booléen persistentFxEligibleIndicator non définie pour ce caractère.")
            result["persistentFxEligibleIndicator"] = boolean_mapping[eligible]
        return [result]
    if value[0] == "2":
        if len(value) != 16:
            raise Pending("Occurrence Mastercard attendue sur 16 positions.")
        result = {"network":"MACD", "exchangeRateOrigin":"ECBR"}
        if value[1:9].strip():
            result["exchangeRate"] = packed_rate(value[1:9])
        if value[9].strip():
            result["rateDiffSign"] = "CRDT" if value[9] == "C" else "DEBT"
        if value[10:16].strip():
            result["rateDiffPercent"] = value[10:16]
        return [result]
    raise ValueError("Nomenclature de taux différente de 1 (VISA) ou 2 (Mastercard)")


def expected(line, message, profile, context):
    op, p = line.operation, line.parameters
    selection = p.get("_selection")
    if selection and selection.get("unresolved"):
        raise Pending(f"Sous-champs du groupe non résolus pour les lignes {selection['unresolved']}")
    value = cm.extract(message, line.source) if line.source else ABSENT
    if op == "decision_header":
        decided = profile.get("decisions", {}).get("event_type")
        if decided is None:
            raise Pending("X-Event-Type : Excel = iss-authorisation-processed ; Swagger = DCMTransactionEvents. Décision attendue.")
        return decided
    if op == "categorie_service":
        return "ISW_ONLINE_AUTH" if absent(value) else "IAS_ONLINE_AUTH"
    if op == "contexte":
        target = line.targets[0] if line.targets else ""
        if target not in context:
            raise Pending(f"Référence indépendante non fournie : {target}")
        return context[target]
    if op == "couvert_par_groupe":
        raise Pending("Champ couvert par la règle composée, sans comparaison séparée.")
    if absent(value) and op not in {"controles_emetteur", "minimum_disponible"}:
        if op=="conversion_ancienne":
            return []
        if line.presence.casefold() == "required" and ("." not in line.source or not absent(cm.extract(message, line.source.rsplit(".",1)[0]))):
            raise ValueError("Source déclarée obligatoire dans le mapping mais absente ou null")
        return ABSENT
    if p.get("condition"):
        test = p["condition"]
        if cm.extract(message, test["source"]) != test["egale"]:
            return ABSENT
    if p.get("condition_prefixe") and not string(value).startswith(p["condition_prefixe"]):
        return ABSENT
    if op == "copie":
        return value
    if op == "pipeline":
        return pipeline(value, p)
    if op == "event_nature":
        source_name = profile.get("decisions", {}).get("event_nature_source")
        if source_name not in {"MTI", "ISOMTI"}:
            raise Pending("Le champ pilotant eventNature n'est pas décidé")
        number = cm.extract(message, source_name)
        if type(number) is not int:
            raise ValueError(f"{source_name} doit être un entier non null pour eventNature")
        groups = {100:"AUTHORISATION",101:"AUTHORISATION",110:"AUTHORISATION",120:"ADVICE",121:"ADVICE",130:"ADVICE",
                  400:"REVERSAL",401:"REVERSAL",410:"REVERSAL",420:"REVERSAL ADVICE",421:"REVERSAL ADVICE",430:"REVERSAL ADVICE",
                  300:"FILE_REQUEST",301:"FILE_REQUEST",310:"FILE_REQUEST",320:"FILE_ADVICE",321:"FILE_ADVICE",330:"FILE_ADVICE"}
        if number not in groups:
            raise ValueError(f"ISOMTI/MTI non couvert par le mapping : {number}")
        return "IAS_ONLINE_AUTH_" + groups[number]
    if op == "adresse_verification":
        value = string(value)
        if len(value) != 2:
            raise ValueError("cardholderAddressCheckInfo doit avoir une nomenclature et un résultat")
        tables={"0":{"A":"PAFM","B":"PAPM","C":"PANM","D":"NPAD","R":"RTRY"},
                "1":{"A":"PAPM","N":"PANM","R":"RTRY","U":"NPAD","Y":"PAFM","Z":"PAPM"},
                "2":{"A":"PAPM","N":"PANM","R":"RTRY","S":"NPAD","U":"NPAD","W":"PAPM","X":"PAFM","Y":"PAFM","Z":"PAPM"}}
        try:
            return tables[value[0]][value[1]]
        except KeyError as exc:
            raise ValueError("Code adresse non couvert par le mapping") from exc
    if op == "champ_incorrect":
        value = string(value)
        if len(value) not in {4,6,8}:
            raise ValueError("ISO44incorrectField doit comporter 4, 6 ou 8 caractères")
        if p["partie"] == "numero":
            return value[:3]
        if p["partie"] == "sous_champ":
            return ABSENT if len(value)==4 else value[3:-1]
        return pipeline(value[-1], {"etapes":[{"operation":"dictionnaire","valeurs":{"1":"VAER","2":"FRER","3":"MMFI","4":"FRMT","5":"WRPF"}}]})
    if op == "montant":
        default_currency="transCurrencyCode" if line.targets and line.targets[0].startswith("transaction.authorisedAmount.") else "billingCurrency" if "billing" in line.source.casefold() else "currency"
        currency_path=profile.get("monnaie",{}).get("devises_par_source",{}).get(line.source,default_currency)
        currency = cm.extract(message,currency_path)
        return money(value,currency,profile,line.source)
    if op == "groupe_montant":
        items = record_items(value, "additionalAmtList")
        matches=[item for item in items if item.get("amountType")==p["code"]]
        if not matches:
            return ABSENT
        if len(matches)!=1:
            raise Pending(f"Plusieurs montants de type {p['code']} : critère d'appairage accountType non documenté.")
        item=matches[0]
        if absent(item.get("value",ABSENT)) or absent(item.get("currencyCode",ABSENT)):
            raise ValueError("Montant composé sans value ou currencyCode")
        return {"amount":money(item["value"],item["currencyCode"],profile,"additionalAmtList[].value"),"currency":item["currencyCode"]}
    if op == "conversion_ancienne":
        return [string(value)[1:]] if string(value).startswith(p["reseau"]) else []
    if op == "taux_change":
        return exchange_rates(value,profile.get("booleens_taux_change"))
    if op == "score":
        return {"serviceId":p["code"],"serviceData":value}
    if op == "minimum_disponible":
        values=[cm.extract(message,path) for path in p["sources"]]
        if all(absent(item) for item in values):
            return ABSENT
        if any(absent(item) for item in values):
            raise Pending("La règle min nécessite les deux valeurs ; aucun repli n'est documenté.")
        currency=cm.extract(message,"currency")
        amounts=[numeric(money(item,currency,profile,path)) for item,path in zip(values,p["sources"])]
        return {"amount":format(min(amounts),"f"),"currency":currency}
    if op == "minimum_autorisable":
        items = record_items(value, "processingInfo.limitResultList")
        matches=[item for item in items if item.get("limitId") in {300,301,302}]
        if not matches:
            return ABSENT
        amount=matches[0].get("minTransAmt",ABSENT)
        if absent(amount):
            raise ValueError("Première limite 300/301/302 sans minTransAmt")
        return {"amount":money(amount,cm.extract(message,"currency"),profile,"processingInfo.limitResultList[].minTransAmt")}
    if op == "limites":
        codes={22:"WGRD",23:"WNGD",27:"WNGI",28:"WGRI",30:"WTOT",31:"PDOM",32:"PINT",33:"PTOT"}
        currency=cm.extract(message,"currency")
        fields = set(selection["fields"]) if selection else {"code", "category", "limitNumber", "limitAmount", "amount"}
        result=[]
        for item in record_items(value, "processingInfo.limitResultList"):
            if item.get("limitId") not in codes:
                continue
            category = None
            if fields & {"category", "amount"}:
                category={10:"AMNT",20:"NUBR"}.get(item.get("limittype"))
                if category is None:
                    raise Pending("limittype absent/inconnu pour une limite financière retenue")
            entry={}
            if "code" in fields:
                entry["code"] = codes[item["limitId"]]
            if "category" in fields:
                entry["category"] = category
            if "limitNumber" in fields and not absent(item.get("maxTotalNbr",ABSENT)):
                entry["limitNumber"]=str(item["maxTotalNbr"])
            if "limitAmount" in fields and not absent(item.get("maxTotalAmt",ABSENT)):
                entry["limitAmount"]={"amount":money(item["maxTotalAmt"],currency,profile,"processingInfo.limitResultList[].maxTotalAmt"),"currency":currency}
            if "amount" in fields and category!="AMNT" and not absent(item.get("newTotalAmt",ABSENT)) and profile.get("politique_presence")=="entree_kafka_uniquement":
                raise Pending("La donnée newTotalAmt est présente ; sa conversion dans ce cas doit être précisée, sans condition supplémentaire de présence.")
            if "amount" in fields and category=="AMNT" and not absent(item.get("newTotalAmt",ABSENT)):
                entry["amount"]={"amount":money(item["newTotalAmt"],currency,profile,"processingInfo.limitResultList[].newTotalAmt"),"currency":currency}
            result.append(entry)
        if selection and result:
            return SelectedRecords(result, [list(fields)] * len(result), money_fields=True)
        return result if result else ABSENT
    if op == "controles_emetteur":
        result=[]
        masks=[]
        selected_sources = selection["sources"] if selection else {path:["code", "controlCode", "responseCode"] for path in p["sources"]}
        for path, fields in selected_sources.items():
            items=cm.extract(message,path)
            if absent(items):
                continue
            for index, item in enumerate(record_items(items, path)):
                entry={}
                if set(fields) & {"code", "controlCode"}:
                    name=item.get("controlName",ABSENT)
                    if not absent(name) and not isinstance(name,str):
                        raise ValueError(f"{path}[{index}].controlName doit être une chaîne")
                    if "code" in fields and not absent(name):
                        entry["code"]=name.split("_",1)[0][:10]
                    if "controlCode" in fields and not absent(name):
                        entry["controlCode"]=name
                if "responseCode" in fields:
                    code=item.get("resultCode",ABSENT)
                    if not absent(code) and type(code) is not int:
                        raise ValueError(f"{path}[{index}].resultCode doit être un entier")
                    if not absent(code):
                        entry["responseCode"]=str(code)
                if entry or not selection:
                    result.append(entry)
                    masks.append(list(fields))
        if selection:
            allow_extra = set(selected_sources) != set(selection.get("all_sources", []))
            if result or allow_extra:
                return SelectedRecords(result, masks, allow_extra=allow_extra)
        return result if result else ABSENT
    if op == "date_a_confirmer":
        config=profile.get("formats_dates",{}).get(line.source)
        if not config:
            raise Pending(p.get("raison","Format de date source à confirmer"))
        if config.get("entree")=="epoch-ms":
            if config.get("sortie")!="iso-utc-ms":
                raise Pending("Une date epoch-ms exige le format de sortie explicite iso-utc-ms")
            if not re.fullmatch(r"-?[0-9]+",string(value)):
                raise ValueError("Timestamp en millisecondes entier attendu")
            instant=datetime(1970,1,1,tzinfo=timezone.utc)+timedelta(milliseconds=int(value))
            return instant.isoformat(timespec="milliseconds").replace("+00:00","Z")
        return datetime.strptime(string(value),config["entree"]).strftime(config["sortie"])
    raise Pending(p.get("raison",f"Règle non définie : {op}"))


def observed(line, body, headers):
    if line.location=="headers":
        if headers is None:
            raise Pending("Headers de sortie non fournis")
        return {key.casefold():value for key,value in headers.items()}.get(line.targets[0].casefold(),ABSENT)
    if not line.targets:
        raise Pending("Cible non résolue")
    if line.operation=="conversion_ancienne":
        items=cm.extract(body,"transaction.conversionRateList")
        if absent(items):
            return []
        return [item[line.parameters["attribut"]] for item in record_items(items, "transaction.conversionRateList") if line.parameters["attribut"] in item]
    if line.operation=="score":
        items=cm.extract(body,"riskScoringList")
        if absent(items):
            return ABSENT
        matches=[item for item in record_items(items, "riskScoringList") if item.get("serviceId")==line.parameters["code"]]
        if len(matches)>1:
            raise ValueError("Plusieurs scores portent le même serviceId")
        return matches[0] if matches else ABSENT
    value = cm.extract(body,line.targets[0])
    if line.operation in {"limites", "controles_emetteur"} and not absent(value):
        record_items(value, line.targets[0])
    return value


def diff(expected_value, actual, line):
    if isinstance(expected_value, SelectedRecords):
        return selected_differences(expected_value, actual, line.targets[0] if line.targets else "")
    if expected_value is ABSENT:
        return [] if actual is ABSENT else [{"motif":"Champ/occurrence à omettre pour cette entrée","attendu":{"absent":True},"obtenu":cm.visible(actual)}]
    if line.operation in {"controles_emetteur","limites","taux_change"} and isinstance(expected_value,list) and isinstance(actual,list):
        # The mapping states concatenation/creation of occurrences, without specifying output order.
        sort=lambda rows:sorted(rows,key=lambda item:json.dumps(item,sort_keys=True,ensure_ascii=False,default=cm.visible))
        expected_value,actual=sort(expected_value),sort(actual)
    if line.operation in {"montant","groupe_montant","minimum_disponible","minimum_autorisable","limites"}:
        def normalize(value,key=""):
            if isinstance(value,dict):
                return {name:normalize(child,name) for name,child in value.items()}
            if isinstance(value,list):
                return [normalize(child) for child in value]
            if key=="amount" and isinstance(value,str):
                return numeric(value)
            return value
        if line.operation=="montant" and isinstance(expected_value,str) and isinstance(actual,str):
            expected_value,actual=numeric(expected_value),numeric(actual)
        else:
            expected_value,actual=normalize(expected_value),normalize(actual)
    return cm.differences(expected_value,actual,Decimal(0),line.targets[0] if line.targets else "")
