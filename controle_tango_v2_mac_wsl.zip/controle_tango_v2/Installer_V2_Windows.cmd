@echo off
setlocal
cd /d "%~dp0"

echo Installation locale de la demo TANGO V2
echo.

if not exist "requirements.txt" goto incomplet
if not exist "demo_v2.py" goto incomplet

rem Ce controle ne doit pas declencher une installation automatique de Python.
set "PYTHON_MANAGER_AUTOMATIC_INSTALL=0"
where py >nul 2>&1
if errorlevel 1 goto python_absent
py --list 2>&1 | findstr /c:"3.12" >nul
if errorlevel 1 goto python_absent
py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>&1
if errorlevel 1 goto python_absent

if exist ".venv\Scripts\python.exe" goto dependances
echo Creation de l'environnement Python de ce dossier...
py -3.12 -m venv ".venv"
if errorlevel 1 goto echec

:dependances
".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>&1
if errorlevel 1 goto environnement_incompatible
echo Installation des dependances du controle...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "requirements.txt"
if errorlevel 1 goto echec
echo.
echo Installation terminee.
echo Double-cliquer ensuite sur Lancer_V2_Windows.cmd.
pause
exit /b 0

:python_absent
echo Python 3.12 avec la commande py est necessaire.
echo Installer Python depuis le site officiel, puis relancer ce fichier.
echo Si le gestionnaire Python est installe : py install 3.12
echo Guide : GUIDE_V2.md
pause
exit /b 2

:environnement_incompatible
echo Un environnement .venv different de Python 3.12 existe dans ce dossier.
echo Extraire l'archive dans un nouveau dossier puis relancer l'installation.
pause
exit /b 2

:incomplet
echo Le dossier est incomplet. Extraire toute l'archive avant de lancer ce fichier.
pause
exit /b 2

:echec
echo.
echo L'installation n'a pas abouti. Le detail est affiche ci-dessus.
echo Verifier l'acces au depot de paquets Python puis relancer l'installation.
pause
exit /b 2
