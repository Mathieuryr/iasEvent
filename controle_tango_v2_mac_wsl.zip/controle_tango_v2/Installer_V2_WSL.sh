#!/bin/bash
cd "$(dirname "$0")" || exit 2
exec bash tools/tango_posix.sh installer "$@"
