#!/bin/bash
cd "$(dirname "$0")" || exit 2

if [ ! -x ".venv/bin/python" ]; then
  echo "L'environnement Python de ce dossier doit être installé. Consulter GUIDE_V2.md."
  if [ -t 0 ]; then read -r -p "Appuyer sur Entrée pour fermer..."; fi
  exit 2
fi
if ! ".venv/bin/python" -c "import fastavro, openpyxl, yaml, openapi_schema_validator, jsonschema, referencing" >/dev/null 2>&1; then
  echo "Les dépendances doivent être installées. Consulter GUIDE_V2.md."
  if [ -t 0 ]; then read -r -p "Appuyer sur Entrée pour fermer..."; fi
  exit 2
fi

echo "Démo locale TANGO V2"
echo "L'interface va s'ouvrir dans le navigateur."
echo "Garder cette fenêtre ouverte pendant l'utilisation."
echo "Pour arrêter la démo : Ctrl+C dans cette fenêtre."
echo
".venv/bin/python" demo_v2.py --port 8792
rise_v2_exit=$?
if [ "$rise_v2_exit" -ne 0 ]; then
  echo "La démo s'est arrêtée. Le détail est affiché ci-dessus."
  if [ -t 0 ]; then read -r -p "Appuyer sur Entrée pour fermer..."; fi
fi
exit "$rise_v2_exit"
