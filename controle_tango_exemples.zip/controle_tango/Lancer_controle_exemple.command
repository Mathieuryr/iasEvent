#!/bin/bash
# Lancer le contrôle local de la paire d'exemples fournie.
cd "$(dirname "$0")" || exit 2
if [ ! -x .venv/bin/python ]; then
  echo "L'environnement Python doit être installé. Consulter GUIDE_TANGO.md, section Démarrer."
  exit 2
fi
./.venv/bin/python controle_tango.py \
  --entree examples_reels/audit_KAFKA.txt \
  --sortie examples_reels/Kafka_audit_sortie.txt \
  --rapport rapports_tango/exemple_reel.json
audit_code=$?
if [ -f rapports_tango/exemple_reel.html ]; then
  open rapports_tango/exemple_reel.html
fi
if [ "$audit_code" -eq 2 ]; then
  echo "Le contrôle a été interrompu. Voir le rapport pour le détail."
else
  echo "Contrôle terminé. Le rapport présente les écarts et les points à vérifier."
fi
exit "$audit_code"
