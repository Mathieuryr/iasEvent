#!/usr/bin/env python3
"""Contrôler le mapping réel SAE/TANGO, l'Avro 1.8 et le webhook IssAuthorFull 1.4."""
from __future__ import annotations

import argparse
import html
import json
import re
import sys
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path

import fastavro
from fastavro.validation import ValidationError as AvroValidationError, validate as validate_avro

import controle_mapping as cm
import tango_mapping as tm
import tango_engine as engine
import tango_formats as formats

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "donnees_tango"
GROUPS = {"score", "limites", "controles_emetteur", "minimum_disponible"}
MONEY_OPS = {"montant", "groupe_montant", "minimum_disponible", "minimum_autorisable", "limites"}


def configure(lines, profile, source, target):
    for line in lines:
        setting=profile.get("regles",{}).get(str(line.row))
        if setting:
            if setting.get("signature")!=line.signature:
                line.operation="a_definir"
                line.parameters={"raison":"La ligne a changé depuis l'analyse : règle métier à réexaminer."}
                line.note("A_VERIFIER","REGLE_MODIFIEE","Signature de ligne différente ; l'ancienne règle n'est pas exécutée.")
                continue
            line.operation=setting["operation"]
            line.parameters={key:value for key,value in setting.items() if key not in {"signature","operation","source","cibles","note","a_confirmer"}}
            if "source" in setting:
                line.source=setting["source"]
                line.notes=[note for note in line.notes if note["code"] not in {"SOURCE_ABSENTE","SOURCE_AMBIGUE"}]
            if "cibles" in setting:
                line.targets=setting["cibles"]
                line.notes=[note for note in line.notes if note["code"] not in {"CIBLE_ABSENTE","CIBLES_MULTIPLES","CIBLE_NON_RENSEIGNEE"}]
            if "note" in setting:
                line.note("INFO","REGLE_DOCUMENTEE",setting["note"])
            if "a_confirmer" in setting:
                line.note("A_VERIFIER","CORRESPONDANCE_A_CONFIRMER",setting["a_confirmer"])
            if line.operation=="couvert_par_groupe":
                line.notes=[note for note in line.notes if note["code"]!="CIBLE_NON_RENSEIGNEE"]
        elif line.source and len(line.targets)==1 and not line.comment and not line.source_values:
            src=source.get(line.source)
            dst=target.get(line.targets[0])
            accepted=dst.types|({"integer"} if "number" in dst.types else set()) if dst else set()
            if src and dst and src.types-{"null"} <= accepted and not src.types & {"object","array"}:
                line.operation="copie"
            else:
                line.parameters={"raison":"La différence de type ou de cardinalité nécessite une transformation explicite."}
        else:
            line.parameters={"raison":"Règle/commentaire sans interprétation automatisée validée."}
    return lines


def produced_types(line, source):
    op=line.operation
    if op=="copie":
        return source[line.source].types-{"null"} if line.source in source else set()
    if op=="pipeline":
        stages=line.parameters.get("etapes",[])
        if stages and stages[-1]["operation"]=="dictionnaire":
            return {cm.json_type(value) for value in stages[-1]["valeurs"].values()}
        if stages and stages[-1]["operation"]=="constante":
            return {cm.json_type(stages[-1]["valeur"])}
        return {"string"}
    if op in {"event_nature","categorie_service","adresse_verification","champ_incorrect","montant","date_a_confirmer","decision_header"}:
        return {"string"}
    if op in {"groupe_montant","minimum_disponible","minimum_autorisable"}:
        return {"object"}
    if op in {"limites","controles_emetteur","taux_change","conversion_ancienne"}:
        return {"array"}
    if op=="score":
        return {"array"}
    return set()


class TangoAudit:
    def __init__(self):
        self.rows=[]
        self.conflicting_targets=set()

    def add(self, level, status, code, detail, line=None, **extra):
        self.rows.append({"niveau":level,"statut":status,"code":code,"ligne_excel":line.row if line else None,
                          "source":line.source if line else "", "cible":" ; ".join(line.targets) if line else "", "detail":detail,**extra})

    def structures(self, lines, source, target, limits, profile):
        for limit in limits:
            self.add("structure","A_VERIFIER","STRUCTURE_COMPLEXE",limit)
        targets=defaultdict(list)
        for line in lines:
            for note in line.notes:
                self.add("structure",note["statut"],note["code"],note["detail"],line)
            if line.operation=="couvert_par_groupe":
                self.add("structure","INFO","REGLE_COMPOSEE",f"Champ inclus dans la règle composée de la ligne {line.parameters['groupe']}.",line)
                continue
            if line.location=="headers":
                self.add("structure","A_VERIFIER" if line.operation=="decision_header" and profile.get("decisions",{}).get("event_type") is None else "OK",
                         "CONTRAT_HEADER", "Contrat de header tiré du mapping et de la documentation, hors du schéma JSON du corps.",line)
                continue
            if line.source and line.source not in source:
                self.add("structure","ERREUR","SOURCE_ABSENTE","Chemin source inexistant dans l'Avro.",line)
                continue
            if not line.targets:
                self.add("structure","A_VERIFIER","CIBLE_NON_RESOLUE","Pas de comparaison de valeurs possible sans une cible résolue.",line)
                continue
            for path in line.targets:
                targets[path].append(line)
                if path not in target:
                    self.add("structure","ERREUR","CIBLE_ABSENTE",f"Chemin cible inexistant : {path}",line)
            if line.operation in {"a_definir","contexte","date_a_confirmer"}:
                self.add("structure","A_VERIFIER","REGLE_A_COMPLETER",line.parameters.get("raison","Référence ou règle à fournir."),line)
                continue
            if line.operation in MONEY_OPS and profile.get("monnaie",{}).get("unite_source") is None:
                self.add("structure","A_VERIFIER","ECHELLE_MONETAIRE","Unité monétaire et, si nécessaire, exposants de devise à renseigner.",line)
            if line.source and line.presence.casefold()=="required" and "null" in source[line.source].types:
                self.add("structure","A_VERIFIER","PRESENCE_PLUS_STRICTE","L'Excel exige la donnée ; le schéma Avro autorise null. La présence métier sera vérifiée sur le message.",line)
            produced=produced_types(line,source)
            dst=target.get(line.targets[0])
            if dst and produced:
                accepted=dst.types|({"integer"} if "number" in dst.types else set())
                # A legacy conversion targets a leaf inside a list, but compares a projection of occurrences.
                if line.operation=="conversion_ancienne":
                    produced={"string"}
                if not produced <= accepted:
                    self.add("structure","ERREUR","TYPE_INCOMPATIBLE",f"Résultat de règle {sorted(produced)} ; type cible {sorted(dst.types)}.",line)
                    continue
                stages=line.parameters.get("etapes",[])
                values=list(stages[-1]["valeurs"].values()) if stages and stages[-1]["operation"]=="dictionnaire" else []
                if dst.enum is not None and any(value not in dst.enum for value in values):
                    self.add("structure","ERREUR","TRANSCODIFICATION_HORS_ENUM",f"Valeurs de mapping hors enum Swagger : {sorted({str(value) for value in values if value not in dst.enum})}.",line)
                    continue
                self.add("structure","OK","CHEMINS_ET_REGLE","Chemins résolus et types compatibles avec la règle déclarée.",line)
        for path,items in targets.items():
            if len(items)>1 and not all(item.operation in GROUPS or item.operation=="couvert_par_groupe" for item in items):
                self.conflicting_targets.add(path)
                self.add("structure","A_VERIFIER","PLUSIEURS_REGLES_CIBLE",f"Cible {path} alimentée aux lignes {[item.row for item in items]} ; priorité/consolidation à confirmer.",cible=path)

    def values(self, lines, incoming, outgoing, headers, profile, context):
        seen={}
        for line in lines:
            if line.operation=="couvert_par_groupe":
                continue
            if set(line.targets) & self.conflicting_targets:
                self.add("valeurs","A_VERIFIER","PRIORITE_NON_DEFINIE","Plusieurs sources alimentent la cible ; la priorité n'est pas définie dans les fichiers.",line)
                continue
            key=(line.operation,tuple(line.targets),line.parameters.get("code"))
            if line.operation in GROUPS and key in seen:
                self.add("valeurs","INFO","COUVERT_PAR_GROUPE",f"Contrôle composé effectué à la ligne {seen[key]}.",line)
                continue
            if line.operation in GROUPS:
                seen[key]=line.row
            try:
                expected=engine.expected(line,incoming,profile,context)
                actual=engine.observed(line,outgoing,headers)
                if expected is cm.MISSING and isinstance(actual,(dict,list)) and not actual and line.presence.casefold()!="required":
                    self.add("valeurs","A_VERIFIER","CONTENEUR_VIDE_OPTIONNEL",
                             "Source optionnelle absente, conteneur vide présent en sortie. Le Swagger l'autorise ; préciser la convention d'omission des conteneurs.",line,
                             attendu={"absent":True},obtenu=actual)
                    continue
                issues=engine.diff(expected,actual,line)
                if not issues:
                    self.add("valeurs","NON_APPLICABLE" if expected is cm.MISSING else "OK","ABSENCE_CONFORME" if expected is cm.MISSING else "VALEUR_CONFORME",
                             "Champ omis pour cette entrée conformément à la politique optionnelle." if expected is cm.MISSING else "Valeur conforme à la règle documentée.",line)
                else:
                    for issue in issues:
                        self.add("valeurs","ERREUR","ECART_MAPPING",issue.pop("motif"),line,**issue)
            except engine.Pending as exc:
                actual=cm.MISSING
                if line.targets and line.location!="headers":
                    try:
                        actual=engine.observed(line,outgoing,headers)
                    except (engine.Pending,ValueError,TypeError):
                        pass
                self.add("valeurs","A_VERIFIER","ATTENDU_NON_DETERMINABLE",str(exc),line,
                         obtenu=cm.visible(actual))
            except (ValueError,TypeError,ArithmeticError,KeyError) as exc:
                self.add("valeurs","ERREUR","DONNEE_OU_TRANSFORMATION",str(exc),line)


def validate_messages(audit, incoming, outgoing, schema, validator):
    try:
        validate_avro(incoming,schema,strict=True)
        audit.add("valeurs","OK","ENTREE_AVRO","Entrée conforme au schéma Avro fourni.")
    except (AvroValidationError,ValueError,TypeError) as exc:
        audit.add("valeurs","ERREUR","ENTREE_AVRO_INVALIDE",str(exc))
    errors=list(validator.iter_errors(outgoing))
    for error in errors:
        audit.add("valeurs","ERREUR","SORTIE_SWAGGER_INVALIDE",error.message,chemin=".".join(map(str,error.absolute_path)))
    if not errors:
        audit.add("valeurs","OK","SORTIE_SWAGGER","Corps de sortie conforme à IssAuthorFull.")


def check_spec(audit, spec, source):
    if not spec.get("fourni"):
        return
    current=""
    resolved=0
    differences=[]
    unresolved=[]
    for entry in spec["champs"]:
        name=entry["nom"].removesuffix("[]")
        path,_,_=tm.source_resolution(name,current,source)
        if not path:
            unresolved.append(entry["nom"])
            audit.add("specification","A_VERIFIER","CHAMP_WORD_NON_RETROUVE",f"Champ décrit dans le Word non retrouvé de manière unique dans l'Avro : {entry['nom']}")
            continue
        resolved+=1
        node=source[path]
        if node.types & {"object"}:
            current=path
        elif "array" in node.types and "object" in source.get(path+"[]",cm.Field()).types:
            current=path+"[]"
        else:
            current=path.rsplit(".",1)[0] if "." in path else ""
        declared={"int":"integer","long":"integer","string":"string","record":"object","array":"array"}.get(entry["type"].casefold())
        if declared and node.types-{"null"}!={declared}:
            differences.append({"source":path,"type_word":entry["type"],"types_avro":sorted(node.types)})
        if entry["presence"]=="M" and "null" in node.types:
            audit.add("specification","A_VERIFIER","PRESENCE_WORD_AVRO",f"{path} obligatoire dans le Word, nullable dans l'Avro.",source=path)
    for issue in differences:
        audit.add("specification","A_VERIFIER","TYPE_WORD_AVRO",str(issue),source=issue["source"])
    return {"lignes_decrites":len(spec["champs"]),"lignes_rapprochees":resolved,"champs_non_resolus":unresolved,"differences_types":differences}


def html_report(path, report):
    data=json.dumps(report,ensure_ascii=False,default=cm.visible).replace("<","\\u003c")
    template='''<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Contrôle SAE vers SID</title>
<style>body{font:15px system-ui,sans-serif;color:#192a3c;background:#f3f6fa;margin:0}main{max-width:1400px;margin:32px auto;padding:0 24px}h1{font-size:28px;margin-bottom:6px}h2{font-size:19px}.intro{color:#526579;max-width:1000px;line-height:1.6}.cards{display:flex;gap:12px;flex-wrap:wrap;margin:24px 0}.card{background:white;border:1px solid #dae2ec;border-radius:9px;padding:16px 22px;min-width:130px}.card strong{display:block;font-size:27px}.panel{background:white;border:1px solid #dae2ec;border-radius:10px;padding:20px;margin:20px 0}.controls{display:flex;gap:12px;flex-wrap:wrap;margin:14px 0}select,input{padding:10px;border:1px solid #bcc9d6;border-radius:6px;font:inherit}input{min-width:280px;flex:1}table{width:100%;border-collapse:collapse}th{text-align:left;color:#53677a;font-size:12px;text-transform:uppercase;border-bottom:2px solid #dae2ec}td,th{padding:11px 10px;vertical-align:top}td{border-bottom:1px solid #e9eef4;overflow-wrap:anywhere;font-size:13px}tbody tr:hover{background:#f6f9fc}.badge{font-size:11px;font-weight:650;padding:4px 7px;border-radius:5px;white-space:nowrap;display:inline-block}.ERREUR{color:#9b1c25;background:#ffebed}.A_VERIFIER{color:#835100;background:#fff1d4}.OK{color:#18613e;background:#e5f4eb}.INFO,.NON_APPLICABLE{color:#506176;background:#ecf0f5}.table{overflow:auto}code{font-size:12px}details{line-height:1.6}summary{cursor:pointer}.hint{font-size:13px;color:#596e82}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}li{margin-bottom:7px}@media(max-width:700px){main{padding:0 12px}td,th{min-width:120px}.card{min-width:90px;padding:12px}}</style>
<main><h1>Contrôle du mapping SAE vers SID</h1><p class="intro" id="summary"></p><div class="cards" id="cards"></div>
<section class="panel"><h2>Portée du contrôle</h2><p id="scope" class="intro"></p><p id="values" class="intro"></p><p id="breakdown" class="intro"></p><p class="hint">Les originaux sont lus sans modification. Les macros Excel ne sont pas exécutées. Un contrôle à vérifier empêche de conclure à une conformité complète.</p></section>
<section class="panel"><h2>Contrôles et écarts</h2><div class="controls"><select id="status"><option value="attention">Erreurs et points à vérifier</option><option value="all">Tous les statuts</option><option>ERREUR</option><option>A_VERIFIER</option><option>OK</option><option>INFO</option><option>NON_APPLICABLE</option></select><select id="level"><option value="all">Tous les niveaux</option><option>structure</option><option>valeurs</option><option>specification</option><option>preparation</option></select><input id="search" placeholder="Rechercher un champ, une ligne ou une règle" aria-label="Recherche"></div><p class="hint" id="count"></p><div class="table"><table><thead><tr><th>Statut</th><th>Ligne</th><th>Source</th><th>Cible</th><th>Constat</th></tr></thead><tbody id="rows"></tbody></table></div></section>
<section class="panel"><details><summary>Lecture des messages et enveloppes de types</summary><pre id="formats"></pre></details></section>
<section class="panel"><details><summary>Couverture et décisions</summary><pre id="coverage"></pre></details></section>
<section class="panel"><details><summary>Fichiers de référence et empreintes</summary><pre id="files"></pre></details></section></main>
<script id="data" type="application/json">__DATA__</script><script>const d=JSON.parse(document.getElementById('data').textContent);const el=id=>document.getElementById(id);el('summary').textContent=d.statut+' — '+d.mode;el('scope').textContent=d.portee;el('values').textContent=d.valeurs_executees?'Messages fournis : les valeurs ont été comparées.':'Aucune paire de messages fournie : les valeurs ne sont pas encore testées.';const levels=d.compteurs_par_niveau||{};el('breakdown').textContent=d.valeurs_executees?(levels.valeurs?.ERREUR||0)+' écarts sur les messages ; '+(levels.structure?.ERREUR||0)+' incohérences structurelles dans les références. Les cartes ci-dessous totalisent tous les niveaux.':'';el('formats').textContent=JSON.stringify(d.preparation_messages||{},null,2);for(const k of ['ERREUR','A_VERIFIER','OK','INFO']){let a=document.createElement('div');a.className='card';let b=document.createElement('strong');b.textContent=d.compteurs[k]||0;a.append(b,document.createTextNode(k.replaceAll('_',' ')));el('cards').append(a)}el('coverage').textContent=JSON.stringify({couverture:d.couverture,decisions:d.decisions},null,2);el('files').textContent=JSON.stringify(d.fichiers,null,2);function draw(){let q=el('search').value.toLocaleLowerCase();let s=el('status').value;let l=el('level').value;let rows=d.controles.filter(r=>(s==='all'||s==='attention'&&['ERREUR','A_VERIFIER'].includes(r.statut)||r.statut===s)&&(l==='all'||r.niveau===l)&&JSON.stringify(r).toLocaleLowerCase().includes(q));el('rows').replaceChildren();for(const r of rows){let tr=document.createElement('tr');for(const key of ['statut','ligne_excel','source','cible','detail']){let td=document.createElement('td');if(key==='statut'){let span=document.createElement('span');span.className='badge '+r.statut;span.textContent=r.statut;td.append(span)}else{td.textContent=r[key]??'';if(key==='detail'&&('attendu'in r||'obtenu'in r)){let p=document.createElement('pre');p.textContent=JSON.stringify({attendu:r.attendu,obtenu:r.obtenu},null,2);td.append(p)}}tr.append(td)}el('rows').append(tr)}el('count').textContent=rows.length+' contrôles affichés sur '+d.controles.length}for(const id of ['status','level','search'])el(id).addEventListener('input',draw);if(d.valeurs_executees)el('level').value='valeurs';draw();</script></html>'''
    path.write_text(template.replace("__DATA__",data),encoding="utf-8")


def args(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    for name,default in [("mapping","mapping.xlsm"),("avro","avro.json"),("swagger","swagger.yaml"),("specification","specification.docx")]:
        parser.add_argument("--"+name,type=Path,default=DATA/default)
    parser.add_argument("--profil",type=Path,default=ROOT/"profil_tango.json")
    parser.add_argument("--entree",type=Path)
    parser.add_argument("--sortie",type=Path)
    parser.add_argument("--headers-sortie",type=Path)
    parser.add_argument("--contexte",type=Path,help="Valeurs attendues d'enrichissement, indexées par chemin cible")
    parser.add_argument("--format-entree",choices=["auto","json","avro-json","audit-texte"],default="auto",
                        help="Détection du JSON décodé ou d'un audit texte TANGO ; avro-json à préciser pour les unions d'entrée")
    parser.add_argument("--format-sortie",choices=["auto","json","avro-json"],default="auto",
                        help="Détection des enveloppes typées connues ; json conserve le corps exactement tel que lu")
    parser.add_argument("--rapport",type=Path,default=ROOT/"rapports_tango/rapport.json")
    result=parser.parse_args(argv)
    if bool(result.entree)!=bool(result.sortie):
        parser.error("--entree et --sortie doivent être fournis ensemble")
    if result.headers_sortie and not result.sortie:
        parser.error("--headers-sortie nécessite la paire entrée/sortie")
    if result.rapport.suffix.lower()!=".json":
        parser.error("--rapport doit avoir une extension .json")
    protected=[getattr(result,key) for key in ("mapping","avro","swagger","specification","profil","entree","sortie","headers_sortie","contexte")]
    outputs={result.rapport.with_suffix(ext).resolve() for ext in (".json",".csv",".html")}
    if any(path and path.resolve() in outputs for path in protected):
        parser.error("Un rapport ne peut pas écraser un fichier d'entrée")
    return result


def main(argv=None):
    arguments=args(argv)
    try:
        profile=cm.load_document(arguments.profil)
        names={}
        schema=fastavro.parse_schema(cm.load_document(arguments.avro),named_schemas=names)
        source,source_limits=cm.avro_catalog(schema,names)
        document=cm.load_document(arguments.swagger)
        validator,selected=cm.make_output_validator(document,profile["schema_sortie"])
        target,target_limits=cm.swagger_catalog(document,selected)
        lines,meta=tm.import_mapping(arguments.mapping,source,target)
        configure(lines,profile,source,target)
        audit=TangoAudit()
        audit.structures(lines,source,target,source_limits+target_limits,profile)
        spec=tm.extract_specification(arguments.specification)
        spec_summary=check_spec(audit,spec,source)
        input_info={key:{"nom":path.name,"sha256":tm.sha256(path)} for key in ("mapping","avro","swagger","specification","profil") if (path:=getattr(arguments,key))}
        preparation={}
        if tm.sha256(arguments.mapping)!=profile.get("mapping_sha256_initial"):
            audit.add("structure","INFO","CLASSEUR_MODIFIE","Le classeur diffère de l'original ; les signatures des règles restent vérifiées individuellement.")
        export_version=tm.text(meta["sheets"].get("Export DICO ESTREEM",[(0,{})])[0][1].get("G"))
        audit.add("structure","INFO","VERSIONS_DICTIONNAIRE",f"Export du dictionnaire dans l'Excel : {export_version} ; Swagger : {document.get('info',{}).get('x-dictionary-version')}.")
        if arguments.entree:
            incoming,preparation["entree"]=formats.read_input(arguments.entree,schema,source,arguments.format_entree)
            outgoing=cm.load_document(arguments.sortie)
            headers=cm.load_document(arguments.headers_sortie) if arguments.headers_sortie else None
            if isinstance(outgoing,dict) and "body" in outgoing and set(outgoing)<={"body","headers"}:
                if headers is not None and "headers" in outgoing:
                    raise cm.ConfigurationError("Fournir les headers dans l'enveloppe ou dans un fichier séparé")
                headers=outgoing.get("headers",headers)
                outgoing=outgoing["body"]
                if isinstance(outgoing,str):
                    outgoing=cm.strict_json(outgoing)
            outgoing,preparation["sortie"]=formats.normalize_output(outgoing,document,selected,arguments.format_sortie)
            audit.add("preparation","INFO","FORMAT_ENTREE",f"Format d'entrée lu : {preparation['entree']['format']}.")
            if preparation["sortie"]["enveloppes_retirees"]:
                audit.add("preparation","INFO","FORMAT_SORTIE_AVRO_JSON",
                          f"{preparation['sortie']['enveloppes_retirees']} enveloppes de types connues retirées ; les valeurs sont conservées. Validation Swagger du corps logique.")
                audit.add("preparation","A_VERIFIER","SCHEMA_TRANSPORT_SORTIE_ABSENT",
                          "Le schéma Avro du transport de sortie n'est pas fourni. Seul le corps logique est validé contre le Swagger ; les alias de types lus figurent dans la préparation.")
            unknown=formats.unknown_input_paths(incoming,source)
            if unknown:
                audit.add("preparation","A_VERIFIER","CHAMPS_AUDIT_HORS_AVRO",
                          "Données de l'export sans chemin dans le schéma Avro fourni : "+", ".join(unknown)+". Elles restent conservées ; leur origine est à confirmer.")
                preparation["entree"]["champs_hors_schema"]=unknown
            if headers is not None and not isinstance(headers,dict):
                raise cm.ConfigurationError("Les headers doivent être un objet JSON")
            context=cm.load_document(arguments.contexte) if arguments.contexte else {}
            if not isinstance(context,dict):
                raise cm.ConfigurationError("Le contexte doit associer des chemins cibles à des valeurs attendues")
            validate_messages(audit,incoming,outgoing,schema,validator)
            audit.values(lines,incoming,outgoing,headers,profile,context)
            for key in ("entree","sortie","headers_sortie","contexte"):
                path=getattr(arguments,key)
                if path:
                    input_info[key]={"nom":path.name,"sha256":tm.sha256(path)}
        counts=Counter(row["statut"] for row in audit.rows)
        code=1 if counts["ERREUR"] else 3 if counts["A_VERIFIER"] else 0
        report={"statut":{0:"CONFORME_AUX_CONTROLES_EXECUTES",1:"ECARTS_DETECTES",3:"VERIFICATION_INCOMPLETE"}[code],"code_sortie":code,
                "mode":"structures_et_valeurs" if arguments.entree else "structures_uniquement","valeurs_executees":bool(arguments.entree),
                "portee":meta["perimetre"]+". Lecture des commentaires figée dans le profil ; les règles modifiées ou ambiguës restent à vérifier.",
                "compteurs":dict(counts),"compteurs_par_niveau":{level:dict(Counter(row["statut"] for row in audit.rows if row["niveau"]==level)) for level in sorted({row["niveau"] for row in audit.rows})},
                "fichiers":input_info,"decisions":profile.get("decisions",{}),"preparation_messages":preparation,
                "couverture":{"selection":meta["selection"],"lignes_actives":len(lines),"lignes_avec_source_resolue":sum(bool(line.source) for line in lines),
                              "lignes_avec_cible_resolue":sum(bool(line.targets) for line in lines),"lignes_hors_perimetre":len(meta["lignes_hors_perimetre"]),
                              "lignes_non_marquees_hors_perimetre":sum(not line["marked"] for line in meta["lignes_hors_perimetre"]),
                              "lignes_couvertes_par_groupe":sum(line.operation=="couvert_par_groupe" for line in lines),
                              "lignes_cibles_non_resolues":[line.row for line in lines if not line.targets and line.operation!="couvert_par_groupe"],
                              "regles_configurees":dict(Counter(line.operation for line in lines)),"specification":spec_summary,
                              "champs_obligatoires_swagger":[path for path,item in target.items() if path and item.required]},
                "controles":audit.rows,"mapping_resolu":[asdict(line) for line in lines],"hors_perimetre":meta["lignes_hors_perimetre"]}
        cm.write_report(arguments.rapport,report)
        html_report(arguments.rapport.with_suffix(".html"),report)
        print(json.dumps({"statut":report["statut"],"compteurs":report["compteurs"],"couverture":report["couverture"],"rapport":str(arguments.rapport)},ensure_ascii=False,indent=2))
        return code
    except Exception as exc:
        detail=f"{type(exc).__name__} : {exc}"
        error={"statut":"ERREUR_CONFIGURATION","mode":"controle_interrompu","valeurs_executees":False,"portee":"Le contrôle a été interrompu par une erreur de configuration.",
               "compteurs":{"ERREUR":1},"couverture":{},"decisions":{},"fichiers":{},"detail":detail,
               "controles":[{"niveau":"configuration","statut":"ERREUR","code":"ERREUR_CONFIGURATION","ligne_excel":None,"source":"","cible":"","detail":detail}]}
        try:
            cm.write_report(arguments.rapport,error)
            html_report(arguments.rapport.with_suffix(".html"),error)
        except OSError:
            pass
        print(error["detail"],file=sys.stderr)
        return 2


if __name__=="__main__":
    sys.exit(main())
