# Contrôle du mapping TANGO vers SID

Le script `controle_tango.py` lit directement le classeur fourni, ses références de dictionnaire, le schéma Avro, le Swagger et la table de format de la spécification Word. Il contrôle les structures et peut comparer les valeurs d'une paire de messages correspondant au même événement.

La décision prise dans ce chat est enregistrée : **ISOMTI pilote eventNature**, même si MTI contient une autre valeur. La paire d'exemples fournie le 25 octobre 2026 est incluse dans `examples_reels` et a été contrôlée.

## Relancer l'exemple fourni sur ton Mac

Le dossier installé est `/Users/bebsulo/Documents/ChatGPT/RISE-IAS`. Son environnement Python est déjà préparé. Double-cliquer sur `Lancer_controle_exemple.command`, ou utiliser le Terminal :

```sh
cd "/Users/bebsulo/Documents/ChatGPT/RISE-IAS"
./.venv/bin/python controle_tango.py \
  --entree examples_reels/audit_KAFKA.txt \
  --sortie examples_reels/Kafka_audit_sortie.txt \
  --rapport rapports_tango/exemple_reel.json
open rapports_tango/exemple_reel.html
```

Le code de sortie `1` signifie que des écarts ont été trouvés. Exécuter l'ouverture du rapport sur une ligne séparée pour l'ouvrir également dans ce cas.

La lecture détecte l'audit texte d'entrée et les enveloppes typées connues de la sortie. Le rapport conserve la trace des 268 enveloppes retirées, sans changer les valeurs. Les noms de types admis sont explicites dans le lecteur, en lien avec les chemins Swagger. Les objets vides sont conservés.

Le résultat de cette paire comporte **9 écarts sur les messages** (8 cibles absentes selon le mapping et 1 date invalide selon le Swagger), ainsi que **4 incohérences structurelles** des références. Les conversions de dates encore ambiguës, l'unité des montants, les headers absents et les enrichissements sans référence restent à vérifier. Ces nombres sont des constats de contrôle, pas un nombre de causes indépendantes.

L'export est compatible avec le schéma Avro d'entrée fourni. Le schéma Avro de sortie n'est pas fourni : la validation de sortie porte sur le corps logique après retrait des enveloppes, comparé au Swagger.

## Démarrer

Python 3.11 ou supérieur. Depuis le dossier extrait de l'archive :

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python controle_tango.py
```

Le dernier appel contrôle les structures. Il crée trois fichiers dans `rapports_tango` :

- `rapport.html` : rapport filtrable par statut, niveau et nom de champ ;
- `rapport.csv` : détail des constats, ouvrable dans Excel ;
- `rapport.json` : résultats, chemins résolus, couverture, décisions et empreintes des fichiers.

Le rapport structurel est déjà inclus dans l'archive. Son code de sortie `1` correspond aux incohérences détectées dans les documents fournis.

## Comparer des messages réels

```sh
python controle_tango.py \
  --entree evenement_sae.json \
  --sortie evenement_sid.json \
  --rapport rapports_tango/comparaison.json
```

L'entrée est le contenu décodé de l'événement Avro, avec les noms exacts de son schéma. La sortie peut être le corps JSON SID seul ou une enveloppe :

```json
{
  "headers": {"X-Original-Request-Id": "valeur-du-header"},
  "body": {"eventProcessingData": {"eventNature": "IAS_ONLINE_AUTH_AUTHORISATION"}}
}
```

Cet extrait illustre seulement le format du fichier, pas un message complet de référence. Les headers peuvent aussi être fournis dans un fichier JSON séparé, avec `--headers-sortie headers.json`.

Un fichier conteneur `.avro` contenant un seul événement est accepté en entrée. L'audit texte TANGO commençant par `Audit data:` est reconnu, y compris les dictionnaires et occurrences de tableaux. Toute ligne non reconnue interrompt le contrôle plutôt que d'être ignorée. Pour un export d'entrée utilisant l'encodage JSON officiel d'Avro et ses enveloppes d'unions, ajouter `--format-entree avro-json`. L'extension `.txt` est acceptée pour ces exports texte ou JSON.

En sortie, `--format-sortie auto` est le défaut. `--format-sortie json` permet de valider le corps tel que lu, sans retrait d'enveloppes. Un nom de type inconnu n'est jamais supprimé automatiquement. Les exports Kafka binaires avec en-tête Schema Registry doivent être décodés en amont. Le script travaille sur des fichiers et ne se connecte pas au broker.

## Périmètre du classeur

La sélection des données à comparer repose **uniquement sur la marque `x` dans la colonne B « Compteur données à mapper »** de l'onglet `Notification Forwarding`. Une ligne vide dans cette colonne n'est jamais ajoutée au contrôle de mapping, même si elle décrit une cible ou une règle. La sélection ne s'hérite pas d'un titre ou d'une ligne voisine.

Le dernier classeur fourni comporte **325 marques `x`**, dont les deux titres de conteneurs `payer*` (ligne 237) et `payee*` (ligne 251), sans cible propre. Cela représente **323 lignes de règles actives**. La ligne 492, `eventServiceCategory`, est maintenant marquée `x` dans ce classeur : elle est retenue pour cette raison. Il n'existe plus d'exception qui l'ajouterait si sa marque était supprimée.

Les **72 lignes non marquées avec une cible** sont conservées à titre d'inventaire, sans comparaison de mapping. Avec les deux titres marqués, cela donne 74 éléments hors du périmètre des règles. Le rapport expose le critère de sélection, les marques comptées et les titres exclus dans la couverture.

Les validations globales du message Avro et du corps Swagger restent présentées séparément des comparaisons de mapping. Les lignes non marquées peuvent servir à reconstruire les chemins et à lire le contexte du classeur, sans produire de règle de comparaison.

Neuf lignes sans cible propre sont rattachées aux règles composées des montants additionnels. Les chemins de sortie sont reconstruits depuis l'onglet `Iss-OA3_001 & Iss-OA3_002`, les références de dictionnaire et les noms effectifs du Swagger `IssAuthorFull`.

Les différences de noms restent visibles. Par exemple, `transUid` est rapproché du nom exact Avro `transUId`. Certaines correspondances proposées, comme `billingActualTransactionAmt` vers `billingActualTransactionAmount`, restent marquées à confirmer.

## Écarts structurels constatés

| Ligne Excel | Constat |
| --- | --- |
| 123 | La transcodification de `schemeTransId` produit `DISC`, `JCB0` ou `UPIC`, absents de l'enum Swagger de `transaction.additionalResponseData.uniqueTransactionIdNetwork`. |
| 125 | Les mêmes codes ne sont pas autorisés pour `transaction.originalUniqueIdNetwork`. |
| 194 | `originalTransactionData.merchantName`, référence `241112000185`, n'est pas retrouvé dans le Swagger fourni. Le script ne le remplace pas automatiquement par une autre donnée de nom proche. |
| 371 | La transcodification de `schemeCardProductId` produit `DISC` ou `UPIC`, absents de l'enum Swagger de `card.brand`. |

Ces constats comparent le contenu des règles du classeur au contrat de sortie fourni. Le rapport conserve la ligne Excel, le chemin Avro, le chemin Swagger et les paramètres utilisés.

## Règles et références à compléter

Les règles lisibles et non ambiguës sont implémentées, notamment les transcodifications de codes, les découpages de positions, la conversion booléenne documentée de `partialApprovalInd`, la présence d'`IASTechInfo`, la création des scores par `serviceId` et la réunion des listes de contrôles émetteur.

Les cas suivants restent explicitement **A_VERIFIER** lorsqu'ils sont nécessaires au contrôle :

- `X-Event-Type` : le classeur demande `iss-authorisation-processed`, tandis que la description du Swagger indique `DCMTransactionEvents`. La valeur demeure non décidée dans le profil.
- Montants : les fichiers ne déterminent pas de manière univoque l'échelle des valeurs source. Aucune division par 100 n'est supposée.
- Dates dont le format source ou la conversion n'est pas défini.
- `initialTransECAddtlData` : le commentaire décrit à la fois des positions fixes et des blocs absents décalant les positions.
- `additionalData` : les codes sont décrits, mais le découpage et les répétitions ne le sont pas suffisamment.
- Données issues de CALIAS et chiffrement PAN : une référence indépendante est nécessaire ; le script n'assimile pas automatiquement `cardToken` au PAN chiffré.
- Sources multiples vers une même cible lorsque la priorité n'est pas décrite.
- Sens incertain de certaines transcodifications et conversions de type sans règle explicite. Les tables des lignes 93, 317 et 327 ont été relues : elles établissent notamment `N → NFUS`, `11030 → V518` et `2 → CBLK`, ce qui est cohérent avec l'exemple fourni.

Le Swagger ne déclare aucun champ `required` dans les modèles du corps. La validation du schéma seule ne suffit donc pas à prouver la présence métier. Le script vérifie aussi les sources déclarées `required` par le mapping et signale les écarts de présence avec l'Avro et le Word.

## Paramétrer les décisions

Les décisions et les règles sont dans `profil_tango.json`. Le profil contient, pour chaque règle métier spécifique, une signature de la ligne d'origine. Si la ligne change, la règle ancienne est suspendue et signalée à vérifier. Le texte des cellules et les macros ne sont jamais exécutés.

Pour trancher le header après validation métier, renseigner `decisions.event_type` avec la valeur retenue. `decisions.event_nature_source` est déjà fixé à `ISOMTI`, conformément au choix exprimé dans ce chat.

Pour les montants, renseigner `monnaie.unite_source` avec `majeure` ou `mineure`. En unités mineures, fournir les exposants par code devise. `monnaie.unites_par_source` permet de définir une unité différente pour certains chemins. Exemple de syntaxe, à remplacer par la convention réellement appliquée :

```json
{
  "unite_source": "mineure",
  "exposants": {"978": 2},
  "unites_par_source": {"processingInfo.instantAvailableBalance": "majeure"}
}
```

Une unité ou une devise non paramétrée produit un contrôle à vérifier. Les calculs utilisent des décimaux exacts. Pour un montant calculé, `123.45` et `123.450` sont comparés comme la même valeur ; les identifiants et codes restent comparés exactement.

Le montant EMV autorisé est associé à `transCurrencyCode`, les montants de facturation à `billingCurrency`. `monnaie.devises_par_source` permet de préciser un autre chemin de devise pour une source après validation métier. La conversion du caractère VISA vers `persistentFxEligibleIndicator` exige aussi une correspondance booléenne explicite dans `booleens_taux_change`, par exemple `{"0":false,"1":true}` si cette convention est confirmée.

Pour une date dont la règle est validée, ajouter une entrée dans `formats_dates`, indexée par chemin Avro : `{"cheminSource":{"entree":"%Y%m%d","sortie":"%Y-%m-%d"}}`. Aucun fuseau horaire n'est ajouté implicitement. Une convention explicite `{"entree":"epoch-ms","sortie":"iso-utc-ms"}` permet les timestamps en millisecondes vers une date UTC avec trois décimales. Elle n'est pas activée dans le profil livré : les descriptions du mapping parlent de dates ISO, tandis que l'audit de `processingInfo.startDateTime` et `endDateTime` contient des nombres sous forme de chaînes.

Pour des enrichissements disposant de valeurs attendues indépendantes, utiliser `--contexte references.json`. Ce fichier associe des chemins cibles à leur valeur attendue, par exemple `{"cardholder.id":"identifiant-attendu"}`. Il ne doit pas être construit en recopiant la sortie que l'on cherche à tester.

## Champs optionnels et listes

Une source optionnelle absente ou `null` implique l'omission du champ cible, sauf règle explicite de constante, de défaut ou d'enrichissement. Un conteneur vide autorisé par le Swagger est signalé à vérifier lorsque la convention d'omission n'est pas documentée. Un `null` en sortie reste soumis au Swagger. Une source déclarée obligatoire dans le mapping ne peut pas être omise silencieusement.

Les scores sont rapprochés par `serviceId` et les identifiants dupliqués sont signalés. Les listes produites par regroupement sont comparées sans imposer un ordre que le classeur ne précise pas ; les doublons sont conservés. Les comparaisons directes de tableaux conservent leur ordre.

Les listes `ACResultList` et `IASTechInfo.ACResultList` sont réunies. L'ancien `code` est obtenu en retirant le suffixe après `_`, puis en limitant à 10 caractères ; `controlCode` conserve le nom complet. Les limites financières sont filtrées selon les identifiants documentés. Pour le montant minimal autorisable, la première occurrence 300/301/302 est retenue, conformément au commentaire de la ligne 461.

## Tester le fonctionnement

Les jeux `examples_tango` sont **fictifs**, construits à partir des schémas fournis. Ils ne sont pas des exports de production.

```sh
python controle_tango.py \
  --entree examples_tango/entree_fictive.json \
  --sortie examples_tango/sortie_fictive.json \
  --rapport rapports_tango/exemple_fictif.json
```

Les valeurs couvertes de cet exemple ne produisent pas d'erreur. Les incohérences structurelles et les règles en attente restent présentes. En remplaçant la sortie par `examples_tango/sortie_avec_3_ecarts.json`, trois différences supplémentaires sont détectées aux lignes 5, 31 et 75.

```sh
python -m unittest discover -s tests -v
```

La livraison est testée avec Python 3.12. Les tests comprennent le rapprochement des fichiers réels, les messages fictifs et la paire fournie, les tableaux et doublons de l'audit texte, ainsi que le retrait sélectif des enveloppes de sortie. Ajouter `eventNature` à une copie de la sortie supprime uniquement l'écart correspondant dans le test de comparaison.

## Statuts et intégrité des fichiers

- `OK` : contrôle exécuté sans écart ;
- `ERREUR` : incohérence ou différence détectée ;
- `A_VERIFIER` : attendu, règle ou référence non déterminable ;
- `NON_APPLICABLE` : absence conforme dans le cas testé ;
- `INFO` : correspondance, regroupement ou précision de périmètre.

Les codes de sortie sont `0` sans erreur ni contrôle incomplet, `1` si un écart est détecté, `2` si le contrôle est interrompu et `3` s'il reste seulement des vérifications incomplètes.

Les copies dans `donnees_tango` sont identiques aux quatre fichiers fournis. Les empreintes figurent dans `provenance.json` et dans le rapport. Le classeur d'origine et ses macros sont conservés ; aucune macro n'est lancée. La sortie contrôlée est le corps JSON défini par le Swagger, pas un XML ISO 20022 ni une certification de conformité à la norme.
