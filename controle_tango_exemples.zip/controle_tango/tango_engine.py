"""Exécution des règles TANGO documentées. Les règles incertaines restent explicites."""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import controle_mapping as cm


class Pending(ValueError):
    """Le contrat ou une référence ne permet pas de déterminer une valeur attendue."""


ABSENT = cm.MISSING


def absent(value):
    return value is ABSENT or value is None


def string(value):
    if isinstance(value, bytes):
        return value.decode("ascii")
    if not isinstance(value, str):
        raise ValueError("Une chaîne est attendue pour ce découpage/transcodage")
    return value


def cut(value, start, end):
    value = string(value)
    if start >= 0 and len(value) < start or end is not None and len(value) < end or start < 0 and len(value) < abs(start):
        raise ValueError(f"Champ trop court ({len(value)}) pour les positions {start}:{end}")
    return value[start:end]


def numeric(value):
    if isinstance(value, bool) or absent(value):
        raise ValueError("Montant numérique attendu")
    value = Decimal(str(value))
    if not value.is_finite():
        raise ValueError("Montant non fini")
    return value


def money(value, currency, profile, source_path):
    settings = profile.get("monnaie", {})
    unit = settings.get("unites_par_source", {}).get(source_path, settings.get("unite_source"))
    if unit not in {"majeure", "mineure"}:
        raise Pending(f"Unité monétaire à renseigner pour {source_path} (majeure ou mineure).")
    amount = numeric(value)
    if unit == "mineure":
        exponent = settings.get("exposants", {}).get(str(currency))
        if type(exponent) is not int or not 0 <= exponent <= 8:
            raise Pending(f"Exposant de devise non fourni pour {currency!r}.")
        amount = amount.scaleb(-exponent)
    return format(amount, "f")


def pipeline(value, parameters):
    for step in parameters.get("etapes", []):
        op = step["operation"]
        if op == "decoupage":
            try:
                value = cut(value, step["debut"], step.get("fin"))
            except ValueError:
                if "defaut" not in parameters:
                    raise
                value = parameters["defaut"]
            if value in parameters.get("omettre_valeurs", []):
                return ABSENT
        elif op == "dictionnaire":
            key = str(value)
            if key not in step["valeurs"]:
                if "defaut" not in step:
                    raise ValueError(f"Code {key!r} non couvert par la transcodification documentée")
                value = step["defaut"]
            else:
                value = step["valeurs"][key]
        elif op == "constante":
            value = step["valeur"]
        else:
            raise Pending(f"Étape non implémentée : {op}")
    return value


def packed_rate(value):
    value = string(value)
    if len(value) != 8 or not value.isdigit():
        raise ValueError("Le taux compact doit comporter exactement huit chiffres")
    return format(Decimal(value[1:]).scaleb(-int(value[0])), "f")


def exchange_rates(value, boolean_mapping=None):
    """Une occurrence, seule représentation non ambiguë du champ string Avro fourni."""
    value = string(value)
    if not value:
        return []
    if value[0] == "1":
        if len(value) != 85:
            raise Pending("Occurrence VISA attendue sur 85 positions ; répétition/délimiteur non défini par le schéma string.")
        provider, table, rate, eligible = value[1:71].rstrip(), value[71:76].rstrip(), value[76:84], value[84]
        result = {"network":"VISA", "exchangeRateOrigin":"ECBR" if "ECB" in provider else "SCHR"}
        if provider:
            result["exchangeRateProvider"] = provider
        if table:
            result["rateTableId"] = table
        if rate.strip():
            result["exchangeRate"] = packed_rate(rate)
        if eligible.strip():
            if not isinstance(boolean_mapping,dict) or eligible not in boolean_mapping or type(boolean_mapping[eligible]) is not bool:
                raise Pending("Conversion vers le booléen persistentFxEligibleIndicator non définie pour ce caractère.")
            result["persistentFxEligibleIndicator"] = boolean_mapping[eligible]
        return [result]
    if value[0] == "2":
        if len(value) != 16:
            raise Pending("Occurrence Mastercard attendue sur 16 positions.")
        result = {"network":"MACD", "exchangeRateOrigin":"ECBR"}
        if value[1:9].strip():
            result["exchangeRate"] = packed_rate(value[1:9])
        if value[9].strip():
            result["rateDiffSign"] = "CRDT" if value[9] == "C" else "DEBT"
        if value[10:16].strip():
            result["rateDiffPercent"] = value[10:16]
        return [result]
    raise ValueError("Nomenclature de taux différente de 1 (VISA) ou 2 (Mastercard)")


def expected(line, message, profile, context):
    op, p = line.operation, line.parameters
    value = cm.extract(message, line.source) if line.source else ABSENT
    if op == "decision_header":
        decided = profile.get("decisions", {}).get("event_type")
        if decided is None:
            raise Pending("X-Event-Type : Excel = iss-authorisation-processed ; Swagger = DCMTransactionEvents. Décision attendue.")
        return decided
    if op == "categorie_service":
        return "ISW_ONLINE_AUTH" if absent(value) else "IAS_ONLINE_AUTH"
    if op == "contexte":
        target = line.targets[0] if line.targets else ""
        if target not in context:
            raise Pending(f"Référence indépendante non fournie : {target}")
        return context[target]
    if op == "couvert_par_groupe":
        raise Pending("Champ couvert par la règle composée, sans comparaison séparée.")
    if absent(value) and op not in {"controles_emetteur", "minimum_disponible"}:
        if op=="conversion_ancienne":
            return []
        if line.presence.casefold() == "required" and ("." not in line.source or not absent(cm.extract(message, line.source.rsplit(".",1)[0]))):
            raise ValueError("Source déclarée obligatoire dans le mapping mais absente ou null")
        return ABSENT
    if p.get("condition"):
        test = p["condition"]
        if cm.extract(message, test["source"]) != test["egale"]:
            return ABSENT
    if p.get("condition_prefixe") and not string(value).startswith(p["condition_prefixe"]):
        return ABSENT
    if op == "copie":
        return value
    if op == "pipeline":
        return pipeline(value, p)
    if op == "event_nature":
        source_name = profile.get("decisions", {}).get("event_nature_source")
        if source_name not in {"MTI", "ISOMTI"}:
            raise Pending("Le champ pilotant eventNature n'est pas décidé")
        number = cm.extract(message, source_name)
        if type(number) is not int:
            raise ValueError(f"{source_name} doit être un entier non null pour eventNature")
        groups = {100:"AUTHORISATION",101:"AUTHORISATION",110:"AUTHORISATION",120:"ADVICE",121:"ADVICE",130:"ADVICE",
                  400:"REVERSAL",401:"REVERSAL",410:"REVERSAL",420:"REVERSAL ADVICE",421:"REVERSAL ADVICE",430:"REVERSAL ADVICE",
                  300:"FILE_REQUEST",301:"FILE_REQUEST",310:"FILE_REQUEST",320:"FILE_ADVICE",321:"FILE_ADVICE",330:"FILE_ADVICE"}
        if number not in groups:
            raise ValueError(f"ISOMTI/MTI non couvert par le mapping : {number}")
        return "IAS_ONLINE_AUTH_" + groups[number]
    if op == "adresse_verification":
        value = string(value)
        if len(value) != 2:
            raise ValueError("cardholderAddressCheckInfo doit avoir une nomenclature et un résultat")
        tables={"0":{"A":"PAFM","B":"PAPM","C":"PANM","D":"NPAD","R":"RTRY"},
                "1":{"A":"PAPM","N":"PANM","R":"RTRY","U":"NPAD","Y":"PAFM","Z":"PAPM"},
                "2":{"A":"PAPM","N":"PANM","R":"RTRY","S":"NPAD","U":"NPAD","W":"PAPM","X":"PAFM","Y":"PAFM","Z":"PAPM"}}
        try:
            return tables[value[0]][value[1]]
        except KeyError as exc:
            raise ValueError("Code adresse non couvert par le mapping") from exc
    if op == "champ_incorrect":
        value = string(value)
        if len(value) not in {4,6,8}:
            raise ValueError("ISO44incorrectField doit comporter 4, 6 ou 8 caractères")
        if p["partie"] == "numero":
            return value[:3]
        if p["partie"] == "sous_champ":
            return ABSENT if len(value)==4 else value[3:-1]
        return pipeline(value[-1], {"etapes":[{"operation":"dictionnaire","valeurs":{"1":"VAER","2":"FRER","3":"MMFI","4":"FRMT","5":"WRPF"}}]})
    if op == "montant":
        default_currency="transCurrencyCode" if line.targets and line.targets[0].startswith("transaction.authorisedAmount.") else "billingCurrency" if "billing" in line.source.casefold() else "currency"
        currency_path=profile.get("monnaie",{}).get("devises_par_source",{}).get(line.source,default_currency)
        currency = cm.extract(message,currency_path)
        return money(value,currency,profile,line.source)
    if op == "groupe_montant":
        if not isinstance(value,list):
            raise ValueError("additionalAmtList doit être un tableau")
        matches=[item for item in value if isinstance(item,dict) and item.get("amountType")==p["code"]]
        if not matches:
            return ABSENT
        if len(matches)!=1:
            raise Pending(f"Plusieurs montants de type {p['code']} : critère d'appairage accountType non documenté.")
        item=matches[0]
        if absent(item.get("value",ABSENT)) or absent(item.get("currencyCode",ABSENT)):
            raise ValueError("Montant composé sans value ou currencyCode")
        return {"amount":money(item["value"],item["currencyCode"],profile,"additionalAmtList[].value"),"currency":item["currencyCode"]}
    if op == "conversion_ancienne":
        return [string(value)[1:]] if string(value).startswith(p["reseau"]) else []
    if op == "taux_change":
        return exchange_rates(value,profile.get("booleens_taux_change"))
    if op == "score":
        return {"serviceId":p["code"],"serviceData":value}
    if op == "minimum_disponible":
        values=[cm.extract(message,path) for path in p["sources"]]
        if all(absent(item) for item in values):
            return ABSENT
        if any(absent(item) for item in values):
            raise Pending("La règle min nécessite les deux valeurs ; aucun repli n'est documenté.")
        currency=cm.extract(message,"currency")
        amounts=[numeric(money(item,currency,profile,path)) for item,path in zip(values,p["sources"])]
        return {"amount":format(min(amounts),"f"),"currency":currency}
    if op == "minimum_autorisable":
        matches=[item for item in value if item.get("limitId") in {300,301,302}]
        if not matches:
            return ABSENT
        amount=matches[0].get("minTransAmt",ABSENT)
        if absent(amount):
            raise ValueError("Première limite 300/301/302 sans minTransAmt")
        return {"amount":money(amount,cm.extract(message,"currency"),profile,"processingInfo.limitResultList[].minTransAmt")}
    if op == "limites":
        codes={22:"WGRD",23:"WNGD",27:"WNGI",28:"WGRI",30:"WTOT",31:"PDOM",32:"PINT",33:"PTOT"}
        currency=cm.extract(message,"currency")
        result=[]
        for item in value:
            if item.get("limitId") not in codes:
                continue
            category={10:"AMNT",20:"NUBR"}.get(item.get("limittype"))
            if category is None:
                raise Pending("limittype absent/inconnu pour une limite financière retenue")
            entry={"code":codes[item["limitId"]],"category":category}
            if not absent(item.get("maxTotalNbr",ABSENT)):
                entry["limitNumber"]=str(item["maxTotalNbr"])
            if not absent(item.get("maxTotalAmt",ABSENT)):
                entry["limitAmount"]={"amount":money(item["maxTotalAmt"],currency,profile,"processingInfo.limitResultList[].maxTotalAmt"),"currency":currency}
            if category=="AMNT" and not absent(item.get("newTotalAmt",ABSENT)):
                entry["amount"]={"amount":money(item["newTotalAmt"],currency,profile,"processingInfo.limitResultList[].newTotalAmt"),"currency":currency}
            result.append(entry)
        return result if result else ABSENT
    if op == "controles_emetteur":
        result=[]
        for path in p["sources"]:
            items=cm.extract(message,path)
            if absent(items):
                continue
            if not isinstance(items,list):
                raise ValueError(f"{path} doit être un tableau")
            for item in items:
                name,code=item.get("controlName"),item.get("resultCode")
                if not isinstance(name,str) or type(code) is not int:
                    raise ValueError("Un contrôle émetteur exige controlName et resultCode")
                result.append({"code":name.split("_",1)[0][:10],"controlCode":name,"responseCode":str(code)})
        return result if result else ABSENT
    if op == "date_a_confirmer":
        config=profile.get("formats_dates",{}).get(line.source)
        if not config:
            raise Pending(p.get("raison","Format de date source à confirmer"))
        if config.get("entree")=="epoch-ms":
            if config.get("sortie")!="iso-utc-ms":
                raise Pending("Une date epoch-ms exige le format de sortie explicite iso-utc-ms")
            if not re.fullmatch(r"-?[0-9]+",string(value)):
                raise ValueError("Timestamp en millisecondes entier attendu")
            instant=datetime(1970,1,1,tzinfo=timezone.utc)+timedelta(milliseconds=int(value))
            return instant.isoformat(timespec="milliseconds").replace("+00:00","Z")
        return datetime.strptime(string(value),config["entree"]).strftime(config["sortie"])
    raise Pending(p.get("raison",f"Règle non définie : {op}"))


def observed(line, body, headers):
    if line.location=="headers":
        if headers is None:
            raise Pending("Headers de sortie non fournis")
        return {key.casefold():value for key,value in headers.items()}.get(line.targets[0].casefold(),ABSENT)
    if not line.targets:
        raise Pending("Cible non résolue")
    if line.operation=="conversion_ancienne":
        items=cm.extract(body,"transaction.conversionRateList")
        if absent(items):
            return []
        if not isinstance(items,list):
            raise ValueError("conversionRateList doit être un tableau")
        return [item[line.parameters["attribut"]] for item in items if line.parameters["attribut"] in item]
    if line.operation=="score":
        items=cm.extract(body,"riskScoringList")
        if absent(items):
            return ABSENT
        if not isinstance(items,list):
            raise ValueError("riskScoringList doit être un tableau")
        matches=[item for item in items if isinstance(item,dict) and item.get("serviceId")==line.parameters["code"]]
        if len(matches)>1:
            raise ValueError("Plusieurs scores portent le même serviceId")
        return matches[0] if matches else ABSENT
    return cm.extract(body,line.targets[0])


def diff(expected_value, actual, line):
    if expected_value is ABSENT:
        return [] if actual is ABSENT else [{"motif":"Champ/occurrence à omettre pour cette entrée","attendu":{"absent":True},"obtenu":cm.visible(actual)}]
    if line.operation in {"controles_emetteur","limites","taux_change"} and isinstance(expected_value,list) and isinstance(actual,list):
        # The mapping states concatenation/creation of occurrences, without specifying output order.
        sort=lambda rows:sorted(rows,key=lambda item:json.dumps(item,sort_keys=True,ensure_ascii=False,default=cm.visible))
        expected_value,actual=sort(expected_value),sort(actual)
    if line.operation in {"montant","groupe_montant","minimum_disponible","minimum_autorisable","limites"}:
        def normalize(value,key=""):
            if isinstance(value,dict):
                return {name:normalize(child,name) for name,child in value.items()}
            if isinstance(value,list):
                return [normalize(child) for child in value]
            if key=="amount" and isinstance(value,str):
                return numeric(value)
            return value
        if line.operation=="montant" and isinstance(expected_value,str) and isinstance(actual,str):
            expected_value,actual=numeric(expected_value),numeric(actual)
        else:
            expected_value,actual=normalize(expected_value),normalize(actual)
    return cm.differences(expected_value,actual,Decimal(0),line.targets[0] if line.targets else "")
