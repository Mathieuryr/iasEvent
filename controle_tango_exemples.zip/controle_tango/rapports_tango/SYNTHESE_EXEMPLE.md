# Contrôle de la paire d'exemples fournie le 25 octobre 2026

L'entrée `audit_KAFKA.txt` contient un bloc d'audit TANGO. La sortie `Kafka_audit_sortie.txt` contient du JSON avec des enveloppes de types Avro. L'identifiant `transUId` correspond à `transaction.identification.endToEndTransId` dans la sortie.

Les données à comparer sont sélectionnées uniquement par la marque `x` en colonne B « Compteur données à mapper ». Le dernier classeur fourni contient 325 marques, dont deux titres de conteneurs sans cible propre, soit 323 lignes de règles actives. Aucune ligne non marquée n'est ajoutée au contrôle de mapping. La ligne 492 est incluse parce qu'elle est marquée dans ce fichier.

Le contrôle relève **9 écarts sur les messages**, ainsi que **4 incohérences structurelles des références**. Les règles non déterminables restent à vérifier. Les nombres comptent des constats, pas des causes indépendantes. Les validations de schéma Avro et Swagger sont des contrôles globaux distincts de la sélection des règles de mapping.

## Écarts sur les messages

| Ligne Excel | Cible de sortie | Constat |
| --- | --- | --- |
| 5 | `eventProcessingData.eventNature` | Absente. Avec ISOMTI = 100, le mapping attend `IAS_ONLINE_AUTH_AUTHORISATION`. |
| 19 | `card.maskedPrimaryAccountNumber` | Absente alors que `maskedPAN` est présent en entrée. |
| 52 | `transaction.additionalResponseData.respondingMachineId` | Absente alors que `context.serverIdent` est présent en entrée. |
| 65 | `transaction.accountFromUsage` | Absente. Le code de traitement fourni conduit à `PWNF`. |
| 121 | `terminal.cardReadingCapabilities` | Absente. Le code POS fourni conduit à `ICCR`. |
| 160 | `originalTransaction.responseCode` | Absente. La ligne du mapping demande de reprendre `responseCode`, ici `00`. |
| 374 | `transaction.issuerProcessingData.fraudResponseCode` | Absente alors que le résultat de fraude source est `0`. |
| 375 | `transaction.issuerProcessingData.fraudScore` | Absente alors que le score source est `20`. |
| Validation Swagger | `transaction.eMV.terminalTransactionDate` | La valeur `140801` ne respecte pas le format `date` du Swagger, qui attend une date complète de la forme `AAAA-MM-JJ`. |

Ces écarts expriment une différence avec le mapping ou le Swagger fournis. Ils ne permettent pas, à eux seuls, d'attribuer chaque cause à l'application : une référence obsolète peut aussi nécessiter une correction.

## Résultats et limites

- Le contenu reconstitué de l'entrée est valide selon le schéma Avro fourni. Les 391 lignes de l'audit ont été lues : 43 champs racine et 58 occurrences de tableaux. Aucun champ n'a été complété pour faire passer cette validation.
- La lecture de sortie a retiré 268 enveloppes typées connues, en conservant les valeurs et les objets vides. Le schéma Avro de ce transport de sortie n'a pas été fourni. La validation de sortie porte sur le corps logique décrit par le Swagger.
- Les tables du mapping des lignes 93, 317 et 327 donnent bien `N → NFUS`, `11030 → V518` et `2 → CBLK`. La sortie est cohérente avec ces tables.
- Les deux listes de contrôles émetteur sont réunies et comparées en conservant les doublons. Le contrôle composé est conforme pour cet exemple.
- Les dates de traitement ressemblent à des timestamps en millisecondes : sous cette hypothèse, elles correspondent aux dates UTC de sortie. La convention reste à confirmer, car le mapping décrit une source ISO. Cette hypothèse n'a pas été activée dans le profil.
- Les champs `transLocalDateTime` et `transmitDateTime` n'ont pas d'année dans l'export. Les cibles correspondantes sont absentes. La transformation reste à préciser.
- L'échelle des montants, les headers Kafka/HTTP et les références indépendantes d'enrichissement restent nécessaires pour terminer leurs contrôles.
- `originalTransaction.authenticationAmount` est présent sous forme d'objet vide malgré une source absente. Le Swagger autorise cet objet vide. La convention d'omission est à préciser.

Les quatre incohérences de structure déjà constatées concernent les lignes 123, 125 et 371 (codes hors enum Swagger), ainsi que la ligne 194 (cible absente du Swagger).

Le détail complet, les valeurs attendues et obtenues, les décisions et les empreintes des fichiers se trouvent dans `exemple_reel.html`, `exemple_reel.csv` et `exemple_reel.json`.
